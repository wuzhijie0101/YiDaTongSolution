'use strict'
// 模板版本: 1.3.1
// 查看文档请访问 http://vuejs-templates.github.io/webpack

const path = require('path')

module.exports = {
  dev: {

    // 路径配置
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {},

    // 开发服务器配置项
    host: 'localhost', // 可以被 process.env.HOST 环境变量覆盖
    port: 8080, // 可以被 process.env.PORT 环境变量覆盖,如果端口被占用会自动使用其他空闲端口
    autoOpenBrowser: false,
    errorOverlay: true,
    notifyOnErrors: true,
    poll: false, // 详见 https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

    
    /**
     * Source Maps 配置
     */

    // https://webpack.js.org/configuration/devtool/#development
    devtool: 'cheap-module-eval-source-map',

    // 如果在开发工具中调试 vue 文件时遇到问题
    // 可以将此项设置为 false - 这可能会有帮助
    // https://vue-loader.vuejs.org/en/options.html#cachebusting
    cacheBusting: true,

    cssSourceMap: true
  },

  build: {
    // index.html 的模板文件路径
    index: path.resolve(__dirname, '../dist/index.html'),

    // 构建输出路径配置
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',

    /**
     * Source Maps 配置
     */

    productionSourceMap: true,
    // https://webpack.js.org/configuration/devtool/#production
    devtool: '#source-map',

    // 默认不开启 Gzip 压缩,因为许多流行的静态资源托管服务
    // 比如 Surge 或者 Netlify 已经为所有静态资源开启了 gzip 压缩。
    // 在设置为 true 之前,请确保安装了相关依赖:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],

    // 运行构建命令时使用额外参数来查看打包分析报告:
    // `npm run build --report`
    // 设置为 true 或 false 可以永久打开或关闭它
    bundleAnalyzerReport: process.env.npm_config_report
  }
}
