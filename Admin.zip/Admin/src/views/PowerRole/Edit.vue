<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid hc_form-pc" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row">
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>名称</div>
                    <validation-provider tag="div" name="名称" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <input class="hc_text" v-model="objData.Name" placeholder="请输入" autocomplete="off" style="width: 200px;" />     
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">备注</div>
                    <div class="form-item-bd">
                        <input class="hc_text" v-model="objData.Remark" placeholder="请输入" autocomplete="off" style="width: 80%;" />                        
                    </div>
                    <div class="form-item-ft"></div>
                </div> 

                <div class="col-240 form-item">
                    <div class="form-item-hd" style="align-self:flex-start;">APP端功能权限设置：</div>
                    <div class="form-item-bd">
                        <div v-for="(objItem1,i) in arrPowerModuleAPP" style="margin-bottom: 15px;">
                            <div style="font-weight: bold; font-size: 16px;">{{objItem1.Name}}[模块]：</div>
                            <template v-if="objItem1.HasPage">
                                <div v-for="objItem3 in objItem1.Children" v-if="objItem3.Type==3" style="margin-top: 10px; margin-left: 20px;">
                                    <label class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem3.Id" /> <span>{{objItem3.Name}}：</span></label>                                    
                                    <label v-for="objItem4 in objItem3.Children" class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem4.Id" /> <span>{{objItem4.Name}}</span></label>
                                </div>
                            </template>

                            <template v-for="objItem2 in objItem1.Children" v-if="objItem2.Type==2">
                                <div style="font-weight: bold; font-size: 16px; color: #999; margin-top: 10px; margin-left: 20px;">{{objItem2.Name}}[层级]：</div>
                                <div v-for="objItem3 in objItem2.Children" style="margin-top: 10px; margin-left: 40px;">
                                    <label class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem3.Id" /> <span>{{objItem3.Name}}：</span></label>                                    
                                    <label v-for="objItem4 in objItem3.Children" class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem4.Id" /> <span>{{objItem4.Name}}</span></label>
                                </div>
                            </template>                                                        
                        </div>
                        
                    </div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd" style="align-self:flex-start;">PC端功能权限设置：</div>
                    <div class="form-item-bd">
                        <div v-for="(objItem1,i) in arrPowerModulePC" style="margin-bottom: 15px;">
                            <div style="font-weight: bold; font-size: 16px;">{{objItem1.Name}}[模块]：</div>
                            <template v-if="objItem1.HasPage">
                                <div v-for="objItem3 in objItem1.Children" v-if="objItem3.Type==3" style="margin-top: 10px; margin-left: 20px;">
                                    <label class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem3.Id" /> <span>{{objItem3.Name}}：</span></label>                                    
                                    <label v-for="objItem4 in objItem3.Children" class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem4.Id" /> <span>{{objItem4.Name}}</span></label>
                                </div>
                            </template>

                            <template v-for="objItem2 in objItem1.Children" v-if="objItem2.Type==2">
                                <div style="font-weight: bold; font-size: 16px; color: #999; margin-top: 10px; margin-left: 20px;">{{objItem2.Name}}[层级]：</div>
                                <div v-for="objItem3 in objItem2.Children" style="margin-top: 10px; margin-left: 40px;">
                                    <label class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem3.Id" /> <span>{{objItem3.Name}}：</span></label>                                    
                                    <label v-for="objItem4 in objItem3.Children" class="hc_checkbox"><input type="checkbox" v-model="objData.PM_IdList" :value="objItem4.Id" /> <span>{{objItem4.Name}}</span></label>
                                </div>
                            </template>                                                        
                        </div>
                        
                    </div>
                </div>

            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{           
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            objData: {                                
                Id: this.Id,
                System: 1,
                Name: "",
                PM_IdList: [],                
                Remark: ""
            },
            arrPowerModulePC:[],
            arrPowerModuleAPP:[],
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {             
        var objWhere = {
            "System": { "strField": "System", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            "Enable": { "strField": "Enable", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" }            
        }
        this.$ajax.get('/SYS/PowerModule/Get', { Field: "*", Where:objWhere, OrderBy:"Sort desc,Id asc" }).then(objResult => {
            var arrData = objResult.data.filter((objItem, nIndex, arrSource)=>{                
                return objItem.Client==1;
            });

            var arrTemp = this.$lib.Common.getTreeData(arrData);
            for(var i = 0; i < arrTemp.length; i++){
                arrTemp[i].HasPage = false;    // 是否有页面类型的子级
                for(var j = 0; j < arrData.length; j++){
                    if(arrTemp[i].Id == arrData[j].ParentId && arrData[j].Type == 3){
                        arrTemp[i].HasPage = true;
                        break;
                    }
                }
            }            
            this.arrPowerModulePC = arrTemp;

            arrData = objResult.data.filter((objItem, nIndex, arrSource)=>{                
                return objItem.Client==2;
            });

            arrTemp = this.$lib.Common.getTreeData(arrData);
            for(var i = 0; i < arrTemp.length; i++){
                arrTemp[i].HasPage = false;    // 是否有页面类型的子级
                for(var j = 0; j < arrData.length; j++){
                    if(arrTemp[i].Id == arrData[j].ParentId && arrData[j].Type == 3){
                        arrTemp[i].HasPage = true;
                        break;
                    }
                }
            }            
            this.arrPowerModuleAPP = arrTemp;            
        });
        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){       
            if(this.objData.Id == null){
                this.startWatch(); 
            }
            else{
                this.$ajax.get('/SYS/PowerRole/GetById?Id=' + this.objData.Id).done(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }

                    for (var strKey in this.objData) {
                        switch (strKey) {        
                            case "PM_IdList":
                                this.objData[strKey] = this.$lib.Common.split(objResult.data[0][strKey], ",", true);
                                break;                    
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }
                    
                    this.startWatch(); 
                });
            }                             
        },
        save: function () {
            if(this.objData.Id==null){
                this.$lib.CURD.insert(this, "/SYS/PowerRole/Insert");
            }
            else{
                this.$lib.CURD.update(this, "/SYS/PowerRole/Update");
            }     
        },
    }
}
</script>

<style scoped>    
.form-item-hd{width: 120px;}
.form-item-bd{ width:calc(100% - 120px);} 
</style>
