<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">                
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">
                <el-table-column prop="Id" label="编号" width="60"></el-table-column>
                
                <el-table-column prop="Title" label="标题" width="100"></el-table-column>
                <el-table-column prop="ViewCount" label="查看次数" width="75" align="right"></el-table-column>
                <el-table-column prop="UpdateTime" label="更新时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                <el-table-column prop="CreateTime" label="创建时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>

                <el-table-column label="操作" width="80" fixed="right">
                    <template slot-scope="scope">
                        <span v-show="$lib.Sys.hasPower(PM_Id,2)" class="hc_button-text" @click="edit(scope.row.Id);">编辑</span>                        
                    </template>
                </el-table-column>
                
            </el-table>
            <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
        </div>
    </div>    
</template>

<script>
import PageEdit from '@/views/Page/Edit.vue';

export default {
    data: function() {
        return{
            PM_Id: 121,

            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Id desc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {                                             
                    },
                    OrderBy: "Id desc"
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
            return "";
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){            
            this.search();            
        },

        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            if (blnIsReload != true) {
                this.ctrTable.objParam.Page = 1;
            }            

            this.$ajax.get('/Admin/Page/GetPage', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == true) {
                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                    if (this.ctrTable.nTotal > 0) {
                        this.$refs.tblList.setCurrentRow(this.ctrTable.arrData[0]);
                    }
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });
        },

        edit:function(nId){ // 新增或编辑     
            this.$layer.iframe({
                content: {
                    content: PageEdit,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['60%','80%'],
                shadeClose: false,
                title: (nId==null?'新增':'编辑')
            });
        },

        ctrTable_sortChange: function (objSort) {   // 表格排序
            this.$lib.Element.Table.sortChange(objSort, this);
        },
        ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
            this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
        },
        ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
            this.$lib.Element.Table.selectionChange(selection, this);
        },
        ctrTable_filterChange: function (objFilters) {    // 列过滤
            this.$lib.Element.Table.filterChange(objFilters, this);            
        },

        ctrPage_sizeChange: function (nValue) { // 页码改变
            this.$lib.Element.Page.sizeChange(nValue, this);         
        },
        ctrPage_currentChange: function (nValue) {  // 当前页改变 
            this.$lib.Element.Page.currentChange(nValue, this);
        }
    }
}

</script>

<style scoped>

</style>
