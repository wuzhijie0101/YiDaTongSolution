<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div">
        <div class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row hc_form form-size-small">
                <div class="col-240 form-item">
                    <div class="form-item-hd">类型：</div>
                    <div class="form-item-bd">       
                        <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.PowerModule_Type">
                            <input type="radio" v-model="objData.Type" :value="parseInt(objItem.Value)" /><span>{{objItem.Name}}</span>
                        </label>
                    </div> 
                </div>
                <div class="col-240 form-item">   
                    <div class="form-item-hd">客户端：</div>
                    <div class="form-item-bd">                     
                        <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.PowerModule_Client">
                            <input type="radio" v-model="objData.Client" :value="parseInt(objItem.Value)" /><span>{{objItem.Name}}</span>
                        </label>
                    </div>         
                </div>
                <!-- <div class="col-240 form-item" v-if="objData.Type==2">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule1" v-model="objData.ParentId" :props="{emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" v-validate="{ required:true }" clearable style="width: 300px;"></el-cascader>
                        <div class="form-error" v-show="errors.has('所属父级')">{{errors.first('所属父级')}}</div>
                    </div>
                </div>
                <div class="col-240 form-item" v-else-if="objData.Type==3">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule2" v-model="objData.ParentId" :props="{checkStrictly:true,emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" v-validate="{ required:true }" clearable style="width: 300px;"></el-cascader>                        
                        <div class="form-error" v-show="errors.has('所属父级')">{{errors.first('所属父级')}}</div>
                    </div>
                </div>
                <div class="col-240 form-item" v-else-if="objData.Type==4">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule3" v-model="objData.ParentId" :props="{emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" v-validate="{ required:true }" clearable style="width: 300px;"></el-cascader>
                        <div class="form-error" v-show="errors.has('所属父级')">{{errors.first('所属父级')}}</div>
                    </div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>名称：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.Name" class="hc_text" name="名称" v-validate="{ required:true }" placeholder="请输入" style="max-width: 300px;" autocomplete="off" />
                        <div class="form-error" v-show="errors.has('名称')">{{errors.first('名称')}}</div>
                    </div>
                </div> -->
                <div class="col-240 form-item" v-if="objData.Type==2">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule1" v-model="objData.ParentId" :props="{emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" clearable style="width: 300px;"></el-cascader>                        
                    </div>
                </div>
                <div class="col-240 form-item" v-else-if="objData.Type==3">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule2" v-model="objData.ParentId" :props="{checkStrictly:true,emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" clearable style="width: 300px;"></el-cascader>                                                
                    </div>
                </div>
                <div class="col-240 form-item" v-else-if="objData.Type==4">
                    <div class="form-item-hd"><span class="form-required">*</span>所属父级：</div>
                    <div class="form-item-bd">       
                        <el-cascader expand-trigger="hover" :options="getPowerModule3" v-model="objData.ParentId" :props="{emitPath:false,value:'Id',label:'Name',children:'Children'}" name="所属父级" clearable style="width: 300px;"></el-cascader>                        
                    </div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>名称：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.Name" class="hc_text" name="名称" placeholder="请输入" style="max-width: 300px;" autocomplete="off" />                        
                    </div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">图标：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.Icon" class="hc_text" placeholder="请输入" style="max-width: 300px;" />                        
                    </div>
                </div>
                <!-- <div class="col-240 form-item">
                    <div class="form-item-hd">图标APP：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.IconAPP" class="hc_text" placeholder="请输入" style="max-width: 300px;" />                        
                    </div>
                </div> -->
                <div v-show="objData.Type==3" class="col-240 form-item">
                    <div class="form-item-hd">超链接：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.Link" class="hc_text" placeholder="请输入" />                        
                    </div>
                </div>
                <!-- <div v-show="objData.Type==3" class="col-240 form-item">
                    <div class="form-item-hd">超链接APP：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.LinkAPP" class="hc_text" placeholder="请输入" />                        
                    </div>
                </div> -->
                <div v-show="objData.Type==3" class="col-240 form-item">
                    <div class="form-item-hd">JSON参数：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.BizParam" class="hc_text" placeholder="请输入" />                        
                    </div>
                </div>
                <!-- <div v-show="objData.Type==3" class="col-240 form-item">
                    <div class="form-item-hd">JSON参数APP：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.BizParamAPP" class="hc_text" placeholder="请输入" />                        
                    </div>
                </div> -->
                <div v-show="objData.Type==4" class="col-240 form-item">
                    <div class="form-item-hd">操作：</div>
                    <div class="form-item-bd">       
                        <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.PowerModule_Operate">
                            <input type="radio" v-model="objData.Operate" :value="parseInt(objItem.Value)" /><span>{{objItem.Name}}</span>
                        </label>
                        <span class="hc_button-text" @click="objData.Operate = null;">清空</span>
                    </div> 
                </div>
                                   
                <div class="col-240 form-item">
                    <div class="form-item-hd">排序：</div>
                    <div class="form-item-bd">
                        <el-input-number v-model="objData.Sort" :min="1"></el-input-number>            
                    </div>
                </div>
                <div class="col-240 form-item">   
                    <div class="form-item-hd">启用：</div>
                    <div class="form-item-bd">                     
                        <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.Enable">
                            <input type="radio" v-model="objData.Enable" :value="parseInt(objItem.Value)" /><span>{{objItem.Name}}</span>
                        </label>
                    </div>         
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">备注：</div>
                    <div class="form-item-bd">
                        <input v-model="objData.Remark" class="hc_text" placeholder="请输入" />                        
                    </div>
                </div>
            </div>
        </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },        
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            objData: {                                
                Id: this.Id,
                System: 1,
                Type: null,
                Client: null,
                ParentId: null,
                Name: "",
                Link: "",
                LinkAPP: "",
                Icon: "",
                IconAPP: "",
                Operate: null,
                BizParam: "{}",
                BizParamAPP: "",
                Sort: null,
                Remark: "",
                Enable: null
            }            
        }
    },    
    computed: {
        getPowerModule1(){
            var arrTemp = this.$parent.arrPowerModule.filter((objItem, nIndex, arrSource)=>{                
                return objItem.ParentId==null && objItem.Client==this.objData.Client;
            });            
            return arrTemp;
        },
        getPowerModule2(){
            var arrTemp = this.$parent.arrPowerModule.filter((objItem, nIndex, arrSource)=>{                
                return objItem.ParentId==null && objItem.Client==this.objData.Client;
            });
            arrTemp = JSON.parse(JSON.stringify(arrTemp));
            for(var i = 0; i < arrTemp.length; i++){
                arrTemp[i].Children = new Array();
            }

            for(var i = 0; i < arrTemp.length; i++){
                for(var j = 0; j < this.$parent.arrPowerModule.length; j++){
                    if(arrTemp[i].Id == this.$parent.arrPowerModule[j].ParentId){
                        arrTemp[i].Children.push(this.$parent.arrPowerModule[j]);
                    }
                }
            }
            return arrTemp;            
        },
        getPowerModule3(){
            var arrTemp = this.$parent.arrPowerModule.filter((objItem, nIndex, arrSource)=>{                
                return objItem.Client==this.objData.Client;
            });

            var arrData = this.$lib.Common.getTreeData(arrTemp);  
            // var arrData = this.$lib.Common.getTreeData(this.$parent.arrPowerModule);            

            // var arrTemp = this.$parent.arrPowerModule.filter(function(objItem, nIndex, arrSource){                
            //     return objItem.ParentId==null;
            // });
            // arrTemp = JSON.parse(JSON.stringify(arrTemp));
            // for(var i = 0; i < arrTemp.length; i++){
            //     arrTemp[i].Children = new Array();
            // }

            // for(var i = 0; i < arrTemp.length; i++){
            //     for(var j = 0; j < this.$parent.arrPowerModule.length; j++){
            //         if(arrTemp[i].Id == this.$parent.arrPowerModule[j].ParentId){
            //             arrTemp[i].Children.push(this.$parent.arrPowerModule[j]);
            //         }
            //     }
            // }
            return arrData;            
        }
    },
    watch: {
        "objData.Type": function (nNew, nOld) {     
            if(this.ctrForm.blnStartWatch==false) return;

            this.objData.ParentId = null;
            this.objData.Icon = "";
            // this.objData.IconAPP = "";
            this.objData.Link = "";
            // this.objData.LinkAPP = "";
            this.objData.BizParam = "{}";
            // this.objData.BizParamAPP = "";
            this.objData.Operate = null;
        },
        "objData.Operate": function (nNew, nOld) {     
            if(this.ctrForm.blnStartWatch==false) return;

            // this.objData.Name = this.$lib.Common.getValueByList(this.$store.state.Dictionary.objMapKey["PowerModule_Operate"], "Value", this.objData.Operate, "Name");
            this.objData.Name = this.$lib.Store.getValFromDic('PowerModule_Operate', this.objData.Operate);
        }
    },
    created: function() {              
        this.initPage();
    },
    mounted: function(){
        // this.$watch('objData.Type', function (nNew) {                        
        // });
        // // this.$lib.Vue.getById(this.$store.state.BaseArea.objMapping,scope.row.FromProvince)

        // setTimeout(()=>{
        //     this.$validator.reset();
        // },200);
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){       
            if(this.objData.Id == null){
                this.objData.Type = 1;
                this.objData.Client = 1;
                this.objData.Sort = 1;
                this.objData.Enable = 1;
                
                this.startWatch(); 
            }
            else{
                // this.$ajax.get('/API/SupplierVerify/GetById?Id=' + this.objData.Id, {}, {async:false}).done(objResult=> {
                this.$ajax.get('/SYS/PowerModule/GetById?Id=' + this.objData.Id).then(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }
                    
                    for (var strKey in this.objData) {
                        switch (strKey) {
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }

                    this.startWatch(); 
                });    
            }                             
        },
        save: function () {
            // this.ctrForm.blnSubmit = true;        
            
            if(this.objData.Id==null){
                this.$lib.CURD.insert(this, "/SYS/PowerModule/Insert?GetId=true", objResult =>{
                    this.objData.Name = "";
                    this.objData.Link = "";
                    this.objData.LinkAPP = "";
                    this.objData.BizParam = "{}";
                    this.objData.BizParamAPP = "";
                    this.ctrForm.blnSubmit = false;  
                    // this.objData.Id = objResult.data;
                    // this.$parent.editCallback(1, this.objData);
                    // this.$layer.close(this.layerid);
                });
            }
            else{   
                this.$lib.CURD.update(this, "/SYS/PowerModule/Update", objResult =>{
                    // this.$parent.editCallback(2, this.objData);
                    this.$parent.search();
                    this.$layer.close(this.layerid);
                });
            }            
        },
        
    }
}
</script>

<style scoped>
    .form-item-hd{width: 120px;}
    .form-item-bd{ width:calc(100% - 120px);} 
</style>
