

<template>
    <div class="hc_container-fluid hc-bg_gray" style="padding:10px 10px 10px 10px; height:100%;">
        <div class="row" style="height: 100%;">
            <div style="width:250px; height: 100%; background: #fff;">
                <el-input placeholder="请输入客户姓名关键字" size="small" v-model="ctrTree.strFilterName" style="padding:10px 10px;" clearable></el-input>
                <el-tree :data="ctrTree.arrData" ref="treList" style="height: calc(100% - 53px); overflow-y: auto;" node-key="C_Id" :props="ctrTree.objDefaultProps" :filter-node-method="$lib.Element.Tree.filterNode" @current-change="ctrTree_currentChange">
                    <div slot-scope="{ node, data }">
                        {{data.Name}}<span class='highlight'>({{data.Count}}个订单)</span>
                    </div>
                </el-tree>
            </div>
            <div class="col" style="height: 100%; margin-left: 10px;">            
                <div class="row" style="background: #fff; padding: 10px;">
                    <div class="col search_mini">
                        <el-button v-if="$lib.Common.powerVaild(1207)" type="success" size="mini" icon="el-icon-search" @click="search();">查询</el-button>
                    </div>
                    <div style="width: auto;">
                        <el-button type="success" icon="el-icon-circle-plus-outline" @click="edit(null);">新增</el-button>
                    </div>
                </div>
                <div class="row" style="height: calc(100% - 62px); margin-top: 10px;">        
                    <div class="col-60" style="height: 100%;">
                        <div style="width:100%; height: 100%; float: left;">
                            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">                
                                <el-table-column prop="Id" label="编号" width="70" sortable="custom"></el-table-column>                    
                                <el-table-column prop="Type" label="类型" width="70" column-key="PowerModule_Type" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('PowerModule_Type')" filter-placement="bottom-end"></el-table-column>                            
                                <el-table-column prop="Name" label="名称" width="200"></el-table-column>
                                <el-table-column prop="Link" label="链接" width="200"></el-table-column>
                                <el-table-column prop="Icon" label="图标" width="100"></el-table-column>
                                <el-table-column prop="Operate" label="类型" width="70" column-key="PowerModule_Operate" :formatter="$lib.Element.Table.formatter"></el-table-column>
                                <el-table-column prop="BizParam" label="JSON参数" width="200"></el-table-column>
    
                                <el-table-column prop="Sort" label="排序" width="70" sortable="custom"></el-table-column>
                                <el-table-column prop="Enable" label="启用" width="60" column-key="Enable" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Enable')" filter-placement="bottom-end"></el-table-column>
                                <el-table-column prop="Remark" label="备注" min-width="100%" show-overflow-tooltip></el-table-column>
                                <el-table-column prop="UpdateTime" label="更新时间" width="150" sortable="custom" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                                <el-table-column prop="CreateTime" label="创建时间" width="150" :formatter="$lib.Element.Table.fmtTime"></el-table-column> 
                                <el-table-column label="操作" width="180" fixed="right">
                                    <template slot-scope="scope">                        
                                        <span class="hc_button-text" @click="edit(scope.row.Id);">编辑</span>
                                        <span class="hc_button-text" @click="deleteData(scope.row.Id);">删除</span>
                                    </template>
                                </el-table-column>
                            </el-table>
                            <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>                        
                        </div>
                    </div>
                </div> 
            </div>
        </div>    
    </div>
    
    </template>
    
    <script>
    import Edit from '@/views/Employee/Edit.vue';
    
    export default {
        data: function() {
            return{ 
                ctrTree: {
                    strFilterName: '',
                    objDefaultProps: {
                        label: 'Name',
                        children: 'Children'
                    },                
                    arrData: []
                },
    
    
                ctrTable: {
                    arrData: [],    // 表行数据
                    nTotal: 0,
                    strPrefix: "",
                    OrderByOld: "Sort desc,Id asc",  // 用于排序回到原值
                    objParam: {
                        Page: 1,
                        Size: 20,
                        Table: "",
                        Field: "*",
                        Where: {    
                            "ParentId": { "strField": "ParentId", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                            "Enable": { "strField": "Enable", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] },
                            "Type": { "strField": "Type", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] }
                        },
                        OrderBy: "Sort desc,Id asc"
                    },
                    objCurrentRow: {},          // 当前点击行
                    arrMultipleSelection:[]     // 复选框多选行
                }
            }
        },
        computed: {
            ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
                return this.ctrTable.objParam.Where.ParentId.strValue + this.ctrTable.objParam.Where.Enable.arrValue + this.ctrTable.objParam.Where.Type.arrValue;
            }
        },
        watch: {
            "ctrTree.strFilterName": function (strValue) {
                this.$refs.treList.filter(strValue);
            },
            ctrTable_autoSearch: function (strValue) {  // 监控计算属性
                this.search();
            },
        },
        created: function() {           
            this.initPage();
        },
        mounted: function(){   
            
        },
        destroyed: function() {},
        methods:{    
            initPage:function(){
                this.search();                
            },                
            search: function (blnIsReload) {
                if (this.$lib.Common.powerVaild(1207) == false) {
                    return;
                }
                if (blnIsReload != true) {
                    this.ctrTable.objParam.Page = 1;
                }
                this.ctrTable.objParam.Where.Enable.strValue = "" + this.ctrTable.objParam.Where.Enable.arrValue;
                this.ctrTable.objParam.Where.Type.strValue = "" + this.ctrTable.objParam.Where.Type.arrValue;
    
                this.$ajax.get('/JDY/PowerModule/GetPage', this.ctrTable.objParam).then(objResult=> {       
                    if (objResult.success == false) {
                        this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                        return;   
                    }
    
                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                });
            },
            edit:function(nId){ // 新增或编辑   
                this.$layer.iframe({
                    content: {
                        content: Edit,
                        parent: this,
                        data:{ Id:nId } 
                    },
                    area:['80%','80%'],
                    shadeClose: false,
                    title: (nId==null?'新增':'编辑')
                });
            },
            deleteData: function (nId) { // 删除,函数不取名为delete是因为vue的@click绑定函数名称不能为关键字,而delete为关键字                   
                this.$lib.Vue.delete(this, "/JDY/PowerModule/Delete?Id=" + nId, objResult => {
                    for(var i = 0; i < this.ctrTable.arrData.length; i++){
                        if(this.ctrTable.arrData[i].Id == nId){
                            this.ctrTable.arrData.splice(i,1);
                            break;
                        }
                    }
                });
            },
           
            
            ctrTable_sortChange: function (objSort) {   // 表格排序
                this.$lib.Element.Table.sortChange(objSort, this);
            },
            ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
                this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
            },
            ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
                this.$lib.Element.Table.selectionChange(selection, this);
            },
            ctrTable_filterChange: function (objFilters) {    // 列过滤
                this.$lib.Element.Table.filterChange(objFilters, this);            
            },
    
            ctrPage_sizeChange: function (nValue) { // 页码改变
                this.$lib.Element.Page.sizeChange(nValue, this);         
            },
            ctrPage_currentChange: function (nValue) {  // 当前页改变 
                this.$lib.Element.Page.currentChange(nValue, this);
            },
    
            
    
            ctrTree_currentChange: function (newData, newNode) {    // 树当前项变化事件        
                this.searchItem(newData.C_Id);
            },
            searchItem: function(C_Id){
                this.$ajax.get('/API/Report/GetCustomerPOItem?C_Id=' + C_Id, {}).then(objResult=> {                
                    if (objResult.success == false) {
                        this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                        return;   
                    }
                    
                    this.ctrTable.arrData = objResult.data;                
                });
            }
        }
    }
    
    </script>
    
    <style scoped>
    
    </style>
    