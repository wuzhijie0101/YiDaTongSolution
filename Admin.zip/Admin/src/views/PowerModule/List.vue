<template>
<div class="hc_container-fluid hc-bg_gray" style="padding:10px 10px 10px 10px; height:100%;">
    <div class="row" style="height: inherit;">
        <div class="col-30" style="height: inherit; background: #fff;">
            <el-input placeholder="请输入客户姓名关键字" size="small" v-model="ctrTree.strFilterName" style="padding:10px 10px;" clearable></el-input>
            <el-tree :data="ctrTree.arrData" ref="treList" style="height: calc(100% - 53px); overflow-y: auto;" node-key="C_Id" :props="ctrTree.objDefaultProps" :expand-on-click-node="false" :filter-node-method="$lib.Element.Tree.filterNode" @current-change="ctrTree_currentChange">
                <div slot-scope="{ node, data }">
                    {{data.Client + data.Name + '[' + $lib.Store.getValFromDic("PowerModule_Type", data.Type)}}]
                </div>
            </el-tree>
        </div>
        <div class="col-210" style="height: inherit; padding-left: 10px;">
            <div class="row" style="background: #fff; padding: 10px;">
                <div class="col">
                    <el-button type="success" icon="el-icon-search" @click="search();">查询</el-button>
                </div>
                <div style="width: auto;">
                    <el-button type="success" icon="el-icon-circle-plus-outline" @click="edit(null);">新增</el-button>
                </div>
            </div>

            <div class="row" style="height: calc(100% - 62px); margin-top: 10px;">        
                <div class="col-240" style="height: 100%; background: #fff;">
                    <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">                
                        <el-table-column prop="Id" label="编号" width="70" sortable="custom"></el-table-column>                    
                        <el-table-column prop="Type" label="类型" width="70" column-key="PowerModule_Type" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('PowerModule_Type')" filter-placement="bottom-end"></el-table-column>                            
                        <!-- <el-table-column prop="ParentId" label="父级" width="200" :formatter="$lib.Element.Table.fmtPowerModuleName"></el-table-column> -->
                        <el-table-column prop="ParentId" label="父级Id" width="70"></el-table-column>
                        <el-table-column prop="Client" label="类型" width="70" column-key="PowerModule_Client" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('PowerModule_Client')" filter-placement="bottom-end"></el-table-column>                            
                        <el-table-column prop="Name" label="名称" width="200"></el-table-column>
                        <el-table-column prop="Link" label="链接" width="200"></el-table-column>
                        <el-table-column prop="Icon" label="图标" width="130"></el-table-column>
                        <el-table-column prop="Operate" label="类型" width="70" column-key="PowerModule_Operate" :formatter="$lib.Element.Table.formatter"></el-table-column>
                        <el-table-column prop="BizParam" label="JSON参数" width="200"></el-table-column>

                        <el-table-column prop="Sort" label="排序" width="70" sortable="custom"></el-table-column>
                        <el-table-column prop="Enable" label="启用" width="60" column-key="Enable" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Enable')" filter-placement="bottom-end"></el-table-column>
                        <el-table-column prop="Remark" label="备注" min-width="100%" show-overflow-tooltip></el-table-column>
                        <el-table-column prop="UpdateTime" label="更新时间" width="150" sortable="custom" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                        <el-table-column prop="CreateTime" label="创建时间" width="150" :formatter="$lib.Element.Table.fmtTime"></el-table-column> 

                        <el-table-column label="操作" width="80" fixed="right">
                            <template slot-scope="scope">                        
                                <span class="hc_button-text" @click="edit(scope.row.Id);">编辑</span>
                                <span class="hc_button-text" @click="deleteData(scope.row.Id);">删除</span>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
                </div>
            </div>
        </div>        
    </div>            
</div>

</template>

<script>
import Edit from '@/views/PowerModule/Edit.vue';

export default {
    data: function() {
        return{ 
            arrPowerModule:[],
            ctrTree: {
                strFilterName: '',
                objDefaultProps: {
                    label: 'Name',
                    children: 'Children'
                },                
                arrData: []
            },

            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Sort desc,Id desc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {    
                        "System": { "strField": "System", "strCondition": "=", "strValue": "1", "strSingleQuotes": "" },
                        "ParentId": { "strField": "ParentId", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "Enable": { "strField": "Enable", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] },
                        "Type": { "strField": "Type", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] }
                    },
                    OrderBy: "Sort desc,Id desc"
                },
                objCurrentRow: {},          // 当前点击行
                arrMultipleSelection:[]     // 复选框多选行
            }
        }
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
            return this.ctrTable.objParam.Where.ParentId.strValue + this.ctrTable.objParam.Where.Enable.arrValue + this.ctrTable.objParam.Where.Type.arrValue;
        }
    },
    watch: {
        "ctrTree.strFilterName": function (strValue) {
            this.$refs.treList.filter(strValue);
        },
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        },
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){   
        
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){
            this.$ajax.get('/SYS/PowerModule/Get', { Field: "*", Where:{
                "Type": { "strField": "Type", "strCondition": "in", "strValue": "1,2,3", "strSingleQuotes": "" },
                "System": { "strField": "System", "strCondition": "=", "strValue": "1", "strSingleQuotes": "" },
            }, OrderBy:"Sort desc,Id asc" }).then(objResult => {                
                this.arrPowerModule = objResult.data;
                var arrTemp = this.$lib.Common.getTreeData(this.arrPowerModule);            
                arrTemp.unshift({ Id: 0, Name: "所有数据", Type:"" });                
                this.ctrTree.arrData = arrTemp;
            });

            this.search();
        },        
        search: function (blnIsReload) {
            if (blnIsReload != true) {
                this.ctrTable.objParam.Page = 1;
            }
            this.ctrTable.objParam.Where.Enable.strValue = "" + this.ctrTable.objParam.Where.Enable.arrValue;
            this.ctrTable.objParam.Where.Type.strValue = "" + this.ctrTable.objParam.Where.Type.arrValue;

            this.$ajax.get('/SYS/PowerModule/GetPage', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == false) {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                    return;   
                }

                this.ctrTable.arrData = objResult.data;
                this.ctrTable.nTotal = objResult.extData;
            });
        },        
        edit:function(nId){ // 新增或编辑   
            this.$layer.iframe({
                content: {
                    content: Edit,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['60%','70%'],
                shadeClose: false,
                title: (nId==null?'新增':'编辑')
            });
        },
        deleteData: function (nId) { // 删除,函数不取名为delete是因为vue的@click绑定函数名称不能为关键字,而delete为关键字                   
            this.$lib.CURD.delete(this, "/SYS/PowerModule/Delete?Id=" + nId, objResult => {
                if(objResult.success == false){
                    this.$alert(objResult.message, '错误提示', { type: 'error' });
                    return;
                }

                var nodeCurrent = this.$refs['treList'].getCurrentNode();
                this.$refs['treList'].remove(nId);
                if(nodeCurrent.Id == nId){
                    this.$refs['treList'].setCurrentKey((nodeCurrent.ParentId==null?0:nodeCurrent.ParentId));
                }
                
                for(var i = 0; i < this.arrPowerModule.length; i++){
                    if(this.arrPowerModule[i].Id == nId){
                        this.arrPowerModule.splice(i,1);
                        break;
                    }
                }
                this.search();

            });
        },
        editCallback: function(nOperate, objData){
            if(objData.Type==4) {
                this.search();
                return;
            }

            if(nOperate == 1){
                this.$refs["treList"].append({ Id: objData.Id, Name: objData.Name, ParentId: objData.ParentId, Type: objData.Type}, (objData.ParentId == null ? "" : objData.ParentId));                    
                this.arrPowerModule.push(objData);
            }   
            else{
                this.$refs["treList"].getNode(objData.Id).data.Name = objData.Name;
                
                for(var i = 0; i < this.arrPowerModule.length; i++){
                    if(this.arrPowerModule[i].Id == this.objData.Id){                    
                        this.arrPowerModule.splice(i,1,this.objData);
                        break;
                    }
                }
            }
            this.search();
        },
        
        ctrTable_sortChange: function (objSort) {   // 表格排序
            this.$lib.Element.Table.sortChange(objSort, this);
        },
        ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
            this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
        },
        ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
            this.$lib.Element.Table.selectionChange(selection, this);
        },
        ctrTable_filterChange: function (objFilters) {    // 列过滤
            this.$lib.Element.Table.filterChange(objFilters, this);            
        },

        ctrPage_sizeChange: function (nValue) { // 页码改变
            this.$lib.Element.Page.sizeChange(nValue, this);         
        },
        ctrPage_currentChange: function (nValue) {  // 当前页改变 
            this.$lib.Element.Page.currentChange(nValue, this);
        },

        ctrTree_currentChange: function (newData, newNode) {    // 树当前项变化事件
            if (newData.Id != this.ctrTable.objParam.Where.ParentId.strValue) {
                this.ctrTable.objParam.Where.ParentId.strValue = (newData.Id == 0 ? "" : newData.Id);
            }
        },
        // ctrTree_currentChange: function (newData, newNode) {    // 树当前项变化事件        
        //     this.searchItem(newData.C_Id);
        // },
        // searchItem: function(C_Id){
        //     this.$ajax.get('/API/Report/GetCustomerPOItem?C_Id=' + C_Id, {}).then(objResult=> {                
        //         if (objResult.success == false) {
        //             this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
        //             return;   
        //         }
                
        //         this.ctrTable.arrData = objResult.data;                
        //     });
        // }
    }
}

</script>

<style scoped>

</style>


