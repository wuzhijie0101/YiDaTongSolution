<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">
                
                <div class="col-240 form-item">
                    <div class="form-item-hd">尺寸导入</div>                    
                    <div class="form-item-bd">                        
                        <file-pond ref="upImport" @processfile="handleProcessFile" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportForKFSize'" label-idle="点击导入数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 clr-text3" style="margin-top: 10px;">
                    备注：会排除掉已车辆放行的货运单
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">关 闭</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{    
        layerid: {
            type: String,
            default: ""
        } 
    },
    data: function() {
        return{         
            // arrFlight:[],  
            // objData:{
            //     AL_Id: 1000,
            //     F_Id: null,
            //     E_Id: this.$store.state.jobjUser.E_Id
            // }
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){    
        },
        handleProcessFile: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upImport"].removeFile(file.id);                
            }
        },
        
    }
}
</script>

<style scoped>

</style>
