<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">                
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>空运单号</div>
                    <validation-provider tag="div" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <label class="hc_checkbox" v-for="objItem in arrOrder" style="display: block; margin-bottom: 10px;">
                            <input type="checkbox" v-model="objData.OO_Ids" :value="objItem.Id" name="空运单号" /> <span>{{(objItem.Number==''?objItem.VirNumber:objItem.Number)}} {{objItem.DeliveryAddress}}</span>                                            
                        </label>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 0px;">{{errors[0]}}</div>
                    </validation-provider>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"></div>
                    <div class="form-item-bd clr-text2">备注:未选中的货运单会进入前置仓</div>                    
                    <div class="form-item-ft"></div>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        AL_Id:{
            type: Number,
            default: null
        },
        CarNumber:{
            type: String,
            default: ""
        },
        layerid: {
            type: String,
            default: ""
        }        
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            arrOrder: [],
            objData:{
                AL_Id: this.AL_Id,
                CarNumber: this.CarNumber,
                OldState: 2,
                ToState: 31,
                OO_Ids:[],
                // OO_IdQZCs:""                        
            }         
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {   
        var objWhere = {
            // "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },                    
            "State": { "strField": "State", "strCondition": "=", "strValue": 2, "strSingleQuotes": "" },
            "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
            "CarNumber": { "strField": "CarNumber", "strCondition": "=", "strValue": this.objData.CarNumber, "strSingleQuotes": "'" }
        }
        this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Number,VirNumber,CarNumber,DeliveryAddress", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {
            this.arrOrder = objResult.data;
            for(var i = 0; i < objResult.data.length; i++){
                this.objData.OO_Ids.push(objResult.data[i].Id);
            }
        });           
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){                                
        },
        save: function(){
            if(this.objData.OO_Ids.length == 0){                                
                this.$alert("请先选择进监管仓的空运单号后再提交", '系统提示', { type: 'error' }); 
                return;
            }

            Lib.CURD.update(this, "/Admin/OutOrder/GroundUpdateStateByCar", objResult =>{                
                this.$parent.refreshList();
                this.$layer.close(this.layerid);
            }, true);
        }
    }
}
</script>

<style scoped>

</style>
