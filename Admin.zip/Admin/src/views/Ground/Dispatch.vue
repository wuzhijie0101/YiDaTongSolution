<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%; overflow-y: auto;">  
        <div style="position: sticky; top: 0px; z-index: 1;">     
            <div style="display: flex; background: #fff; align-items: center; padding: 10px; border-bottom: 1px solid #ddd;">
                <div style="text-align: right; flex-grow: 1;">
                    <input type="tel" v-model="strFilter" class="hc_text-mini" @click="$event.currentTarget.select();" placeholder="空运单号" style="background: #fff; width: 100px;" /><span class="hc_button-text" @click="strFilter='';">清除</span>
                    <span>{{nRefresh}}秒后</span><span class="hc_button-text" @click="loadOrder();loadTask();">刷新数据</span>
                </div>
            </div>
            <div class="scrollbar1 chd_dis-flight" style="border-bottom: 1px solid #ddd;">  
                <span v-for="(arrItem,strKey) in objAirLine" :class="objFlight.AL_Id==arrItem[0].AL_Id?'on':''" @click="objFlight=arrItem[0];loadOrder();loadTask();" style="cursor: pointer;">{{arrItem[0].Number}}</span>            
            </div>
        </div>


        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">客服</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',1)}}【客服车队】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="openGroundStartDrive(objFlight.AL_Id);">发车</span></div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==1" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_1'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',2)}}【地面办公室】</div>
                <div v-for="objItem in objCar['2']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" style="font-size: 1.3rem;"><span class="hc_button-text" @click="updateStateByCar(objItem.CarNumber,2,20,objFlight.AL_Id)">进前置仓</span>|<span class="hc_button-text" @click="openGroundUpdateStateByCar(objFlight.AL_Id,objItem.CarNumber)">进监管仓</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',3)}}【地面现场】</div>
                <div v-for="objItem in objCar['3']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>
                </div>
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">前置仓</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',21)}}【客服】</div>                
                <div v-for="objItem in arrOrder" v-if="objItem.State==21" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_21'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><a class="hc_button-text" :href="$lib.Config.Url_WeChat+'/OutOrder/DetailUnload?Id='+objItem.Id" target="_blank">数据对比</a> | <span class="hc_button-text" @click="updateState(objItem.Id,22)">已确认</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',22)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==22" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_22'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundUpdateState(objItem.Id,22,23);">确认发货</span></div>
                </div>
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">跨境电商</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">  
            <div class="row chd_dis-item" >
                <div class="col-240 title">跨境电商流程中【客服】</div>
                <template v-for="(arrItem, strKey) in objCarOrder['14']">
                    <div class="col-240"><div class="subTitle">{{strKey}}:</div></div>
                    <div v-for="objItem in arrItem" v-show="objItem.Number.indexOf(strFilter)>-1" class="col-80 body" style="text-align: center;">
                        <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}{{objItem.Volume>0?"_已录":""}}</div>
                        <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,1);">完善数据</span></div>
                    </div>
                </template>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',30)}}-已上锁离场【客服】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="updateStateBat(31,OO_Ids30);">批量已完成</span></div>
                <template v-for="(arrItem, strKey) in objCarOrder['30']">
                    <div class="col-240"><div class="subTitle">{{strKey}}:</div></div>
                    <div v-for="objItem in arrItem" v-show="objItem.Number.indexOf(strFilter)>-1" class="col-80 body" style="text-align: center;">
                        <div><span @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}{{objItem.Volume>0?"_已录":""}}</span> <label v-show="objItem.Volume>0" class="hc_checkbox"><input type="checkbox" v-model="OO_Ids30" :value="objItem.Id" name="OO_Ids30" /></label></div>
                        <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,1);">完善数据</span> | <span class="hc_button-text" @click="updateState(objItem.Id,31)">已完成</span></div>
                    </div>
                </template>
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">地面</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">                        
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',31)}}【地面现场】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==31" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_31'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',32)}}【客服】</div>                
                <div v-for="objItem in arrOrder" v-if="objItem.State==32" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_32'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div><a v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" :href="$lib.Config.Url_WeChat+'/OutOrder/DetailUnload?Id='+objItem.Id" target="_blank">数据对比</a> | <span class="hc_button-text"  @click="updateState(objItem.Id,33)">已确认</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',33)}}【地面办公室】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="updateStateBat(34,OO_Ids33);">批量已录预配</span></div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==33" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_33'" class="col-80 body" style="text-align: center;">
                    <div><span @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</span> <label class="hc_checkbox"><input type="checkbox" v-model="OO_Ids33" :value="objItem.Id" name="OO_Ids33" /></label></div>
                    <div><span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" @click="updateState(objItem.Id,(objItem.Type==2?35:34));">已录预配</span></div>
                    <!-- <div><span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" @click="openGroundUpdateState(objItem.Id,33,(objItem.Type==2?35:34));">已录预配</span></div> -->
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',34)}}【客服】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="updateStateBat(35,OO_Ids34);">批量已审结</span></div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==34" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_34'" class="col-80 body" style="text-align: center;">
                    <div><span @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</span> <label class="hc_checkbox"><input type="checkbox" v-model="OO_Ids34" :value="objItem.Id" name="OO_Ids34" /></label></div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,35);">已审结</span></div>
                </div>
            </div>
            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',35)}}【地面办公室】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="updateStateBat(38,OO_Ids35);">批量已放行</span></div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==35" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_35'" class="col-80 body" style="text-align: center;">
                    <div><span @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</span> <label class="hc_checkbox"><input type="checkbox" v-model="OO_Ids35" :value="objItem.Id" name="OO_Ids35" /></label></div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" v-show="objItem.Type!=2" @click="updateState(objItem.Id,36)">查验</span> <span class="hc_button-text" @click="updateState(objItem.Id,38)">放行</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',36)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==36" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_36'" class="col-120 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,38)">放行</span> | <span class="hc_button-text" @click="updateState(objItem.Id,37)">重申报</span> | <span class="hc_button-text" @click="cancelOrder(objItem.Id)">退货</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',37)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==37" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_37'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,2)">原单重申报</span> | <span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,3)">新单重申报</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',38)}}【客服】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="updateStateBat(39,OO_Ids38);">批量已拿或已盖</span></div>

                <div v-for="objItem in arrOrder" v-if="objItem.State==38" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_38'" class="col-80 body" style="text-align: center;">
                    <div><span @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</span> <label class="hc_checkbox"><input type="checkbox" v-model="OO_Ids38" :value="objItem.Id" name="OO_Ids38" /></label></div>
                    <div v-show="objItem.Type==1 && $store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,39)">已拿放行条</span></div>
                    <div v-show="objItem.Type==2 && $store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,39)">已盖放行章</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',39)}}【地面现场】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==39" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_39'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,50,false,0)">过安检</span></div>
                    <!-- <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,50,false,1)">退件过</span> | <span class="hc_button-text" @click="updateState(objItem.Id,50,false,0)">过安检</span></div> -->
                </div>
            </div>
        </div>



        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; margin-bottom: 10px; padding: 0px 10px;">
            <div class="row chd_dis-item" >
                <div class="col-240 title">待删除处理【地面办公室】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>
                <div v-for="objItem in arrTask" v-if="objItem.Type==4 || objItem.Type==5" :key="objItem.Id" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.BizId);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" v-show="objItem.ToDo1==1" @click="updateToDo(objItem.Id,'ToDo1')">已撤关</span> <span class="hc_button-text" v-show="objItem.ToDo2==1" @click="updateToDo(objItem.Id,'ToDo2')">| 已删运抵</span> <span class="hc_button-text" v-show="objItem.ToDo3==1" @click="updateToDo(objItem.Id,'ToDo3')">| 已删预配</span> <span class="hc_button-text" v-show="objItem.ToDo5==1" @click="updateToDo(objItem.Id,'ToDo5')">| 已安检退货</span> <span class="hc_button-text" v-show="objItem.ToDo4==1" @click="updateToDo(objItem.Id,'ToDo4')">| 已退货物</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">待退件处理【地面办公室】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>
                <div v-for="objItem in arrTask" v-if="objItem.Type==3" :key="objItem.Id" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.BizId);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openLogisticsOrderEdit(3,objItem.BizId);">录快递</span> | <span class="hc_button-text" @click="updateToDo(objItem.Id,'ToDo1')">已处理</span></div>
                </div>
            </div>   
        </div>

        <div style="height: 20px;"></div>
    </div>
</template>

<script>
import OutOrderEdit from '@/views/OutOrder/Edit.vue';
import OutOrderDetail from '@/views/OutOrder/Detail.vue';

import GroundUpdateStateByCar from '@/views/Ground/UpdateStateByCar.vue';
import GroundUpdateState from '@/views/Ground/UpdateState.vue';
// import GroundUpdateData from '@/views/Ground/UpdateData.vue';
import LogisticsOrderEdit from '@/views/LogisticsOrder/Edit.vue';
import GroundStartDrive from '@/views/Ground/StartDrive.vue';

export default {
    data: function() {
        return{
            PM_Id: 212,
            nRefresh: 120,

            strFilter: "",          // 空运单号关键字
            objFlight: null,    // 当前选中的航班
            objAirLine:{},

            arrOrder: [],
            objCar: {"2":[],"3":[]},
            arrTask: [],

            objCarOrder: {"14":{},"30":{}},

            OO_Ids30:[],
            OO_Ids33:[],
            OO_Ids34:[],
            OO_Ids35:[],
            OO_Ids38:[],
            
        }
    },
    props:{    
        BizParam:{
            type: Object,
            default: null
        }
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        var objWhere = {
            "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
        }
        this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc,AL_Id asc" }).then(objResult => {
            for(var i = 0; i < objResult.data.length; i++){
                if(this.objAirLine.hasOwnProperty(objResult.data[i].AL_Id) == false){
                    this.objAirLine[objResult.data[i].AL_Id] = [];
                }
                this.objAirLine[objResult.data[i].AL_Id].push(objResult.data[i]);
                if(objResult.data[i].AL_Id==1000){
                    this.objFlight = objResult.data[i];
                }
            }
            if(this.objFlight == null){
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].AL_Id==1001){
                        this.objFlight = objResult.data[i];
                    }
                }
                if(this.objFlight == null){
                    this.objFlight = objResult.data[0];
                }
            }
            this.loadOrder();
            this.loadTask();
            // this.$forceUpdate();
        });

        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){
            this.refreshTime();
        },
        refreshTime: function(){
            this.nRefresh -= 1;
            if(this.nRefresh < 1){
                this.nRefresh = 120;
                this.loadOrder();
            }
            setTimeout(()=>{this.refreshTime();}, 1000);
        },


        loadOrder: function(){                    
            var objWhere = {
                "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },
                // "State": { "strField": "State", "strCondition": ">=", "strValue": 10, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "<", "strValue": 50, "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objFlight.AL_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,AL_Id,F_Id,State,Type,Number,VirNumber,CarNumber,Volume", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                     
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].State == 20 || objResult.data[i].State == 23){
                        objResult.data.splice(i,1);
                    }
                    // objResult.data[i].Number = objResult.data[i].Number.substr(4);
                }
                this.arrOrder = objResult.data;

                this.objCar = {"2":[],"3":[]};
                var strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State==2){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['2'].push({F_Id:objResult.data[i].F_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }                                
                    }
                }

                strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State==3){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['3'].push({F_Id:objResult.data[i].F_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }                                
                    }
                }

                this.objCarOrder = {"14":{},"30":{}};
                for(var i = 0; i < this.arrOrder.length; i++){                            
                    // strKey = "" + this.arrOrder[i].State;
                    if(this.arrOrder[i].State>=10 && this.arrOrder[i].State<20){
                        if(this.objCarOrder["14"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                            this.objCarOrder["14"][this.arrOrder[i].CarNumber] = [];
                        }
                        this.objCarOrder["14"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                    }
                    else if(this.arrOrder[i].State==30){
                        if(this.objCarOrder["30"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                            this.objCarOrder["30"][this.arrOrder[i].CarNumber] = [];
                        }
                        this.objCarOrder["30"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                    }
                }

            });
        },
        loadTask: function(){                    
            var objWhere = {
                "Type": { "strField": "Type", "strCondition": "in", "strValue": "3,4,5", "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objFlight.AL_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrderTask/Get', { Field: "*", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                        
                this.arrTask = objResult.data;
            });
        },
        

        refreshList: function(){
            this.loadOrder();
        },
        refreshListItem: function(nId, nToState){    
            for(var i = 0; i < this.arrOrder.length; i++){
                if(this.arrOrder[i].Id == nId){
                    this.arrOrder[i].State = nToState;
                    break;
                }
            }  
        },
        updateStateByCar: function(CarNumber,OldState,ToState,AL_Id){ // 仅用在“运输中”和“待车辆放行”两个状态
            var strConfirm = (OldState==2?"确定该车辆进前置仓吗？":"确定该车辆已从岗亭放行吗？");

            this.$confirm(strConfirm, '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/GroundUpdateStateByCar?AL_Id="+AL_Id+"&CarNumber="+CarNumber+"&OldState="+OldState+"&ToState=" + ToState).then(objResult=> {
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});                    
                    this.loadOrder();
                });
            }).catch(function () {
            });
        },
        updateState: function(nId,nToState, blnLoad, nDetain){
            this.$confirm("确定执行该操作吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/GroundUpdateState",{Id:nId, ToState: nToState, Detain: nDetain}).then(objResult=> {
                    if(objResult.success == false){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});
                    if(blnLoad==true){
                        this.loadOrder();
                    }
                    else{
                        if(nToState == 31){
                            for(var i = 0; i < this.arrOrder.length; i++){
                                if(this.arrOrder[i].Id == nId){
                                    for(var j = 0; j < this.objCarOrder["30"][this.arrOrder[i].CarNumber].length; j++){
                                        if(this.objCarOrder["30"][this.arrOrder[i].CarNumber][j].Id == nId){
                                            this.objCarOrder["30"][this.arrOrder[i].CarNumber].splice(j,1);
                                            break;
                                        }
                                    }
                                    this.arrOrder[i].State = nToState;
                                    break;
                                }
                            }
                        }
                        else{
                            for(var i = 0; i < this.arrOrder.length; i++){
                                if(this.arrOrder[i].Id == nId){
                                    this.arrOrder[i].State = nToState;
                                    break;
                                }
                            }
                        }
                    }
                    
                });
            }).catch(function () {
            });
        },
        updateStateBat: function(nToState,arrOO_Ids){
            if(arrOO_Ids.length == 0){
                return;
            }
            this.$confirm("确定执行该批量操作吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/GroundUpdateStateBat",{ToState: nToState, OO_Ids: arrOO_Ids}).then(objResult=> {
                    if(objResult.success == false){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }

                    this.OO_Ids30 = [];
                    this.OO_Ids33 = [];
                    this.OO_Ids34 = [];
                    this.OO_Ids35 = [];
                    this.OO_Ids38 = [];
                    this.$message({message: '提交成功',type: 'success'});
                    this.loadOrder();
                });
            }).catch(function () {
            });
        },
        updateToDo: function(nId, strToDo){
            this.$confirm("确定将该项工作标记为已处理吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrderTask/UpdateToDo?Id=" + nId + "&ToDo=" + strToDo).then(objResult=> {                      
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                      
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});        
                    this.loadTask();
                });
            }).catch(function () {
            });
        },
        cancelOrder: function(nId){
            this.$confirm("确定取消该货运单吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/CancelOrder?Id=" + nId).then(objResult=> {                      
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                      
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});        
                    for(var i = 0; i < this.arrOrder.length; i++){
                        if(this.arrOrder[i].Id == nId){
                            this.arrOrder.splice(i,1);
                            break;
                        }
                    }
                    this.loadTask();
                });
            }).catch(function () {
            });
        },

        
        openOutOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: OutOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['800px','90%'],
                shadeClose: false,
                title: '货运单详情'
            });
        },
        openOutOrderEdit:function(nId,nMode){ // 新增或编辑     
            var strTitle= "";
            switch(nMode){
                case 1: strTitle="完善货运单数据";break;
                case 2: strTitle="原单号重申报";break;
                case 3: strTitle="新单号重申报";break;
            }
            this.$layer.iframe({
                content: {
                    content: OutOrderEdit,
                    parent: this,
                    data:{ Id:nId,C_Id:(this.$store.state.AirLine.objMapping[this.objFlight.AL_Id].PrimaryCode=='071'?1001:1004),Mode:nMode } 
                },
                area:['80%','90%'],
                shadeClose: false,
                title: strTitle
            });
        },
        openGroundStartDrive:function(nAL_Id){
            this.$layer.iframe({
                content: {
                    content: GroundStartDrive,
                    parent: this,
                    data:{ AL_Id:nAL_Id } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '发车'
            });
        },
        openGroundUpdateStateByCar:function(nAL_Id,CarNumber){     
            this.$layer.iframe({
                content: {
                    content: GroundUpdateStateByCar,
                    parent: this,
                    data:{ AL_Id:nAL_Id, CarNumber: CarNumber } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '进监管仓'
            });
        },
        openGroundUpdateState:function(Id,OldState,ToState){     
            this.$layer.iframe({
                content: {
                    content: GroundUpdateState,
                    parent: this,
                    data:{ Id:Id, OldState: OldState,ToState:ToState } 
                },
                area:['800px','400px'],
                shadeClose: false,
                title: this.$lib.Store.getValFromDic("OutOrder_State", OldState)
            });
            
        },
        // openGroundUpdateData:function(Id,Option){     
        //     this.$layer.iframe({
        //         content: {
        //             content: GroundUpdateData,
        //             parent: this,
        //             data:{ Id:Id, Option:Option } 
        //         },
        //         area:['800px','400px'],
        //         shadeClose: false,
        //         title: "编辑"
        //     });
            
        // },
        
        openLogisticsOrderEdit:function(Type,OO_Id){     
            this.$layer.iframe({
                content: {
                    content: LogisticsOrderEdit,
                    parent: this,
                    data:{ Type:Type, BizId: OO_Id } 
                },
                area:['800px','300px'],
                shadeClose: false,
                title: "录快递"
            });            
        },                 
    }
}

</script>

<style scoped>

</style>
