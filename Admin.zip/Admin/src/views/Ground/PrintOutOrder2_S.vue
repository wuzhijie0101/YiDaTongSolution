<template>    
    <div class="hc_container-fluid" style="height:100%;">       
        <div class="row" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="col-240">
                <select @change="loadData($event.target.value)" class="hc_select hc_form-small" style="width: 105px;">
                    <option :value='0'>主单</option>
                    <option v-for="(objItem,i) in arrOutOrderItem" :value='objItem.Id'>分单{{i+1}}</option>
                </select>
            </div>

            <div class="col-240" id="divPrint" style="width: 842px;">
                <!-- <div>NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.83); width: 120%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 10px; background: red;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.75); width: 133%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 6px;-webkit-text-size-adjust:none;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.66); width: 150%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 6px;-webkit-text-size-adjust:none;">NOT</div>
                
                <div style="font-size: 12px; -webkit-transform: scale(0.83); display: inline-block; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 10px; background: red;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.66); display: inline-block; transform-origin: 0 0; background: green;">NOT</div> -->
                
                <div class="hc_container-fluid">
                    <div class="row print-height">
                        <div class="col-12" style="line-height: 40px; text-align: center; font-weight: bold; font-size: 16px;">369</div>
                        <div class="col-12 bd-left" style="line-height: 40px; text-align: center; font-weight: bold; font-size: 16px;">CSX</div>
                        <div class="col-40 bd-left" style="line-height: 40px; text-align: center; font-weight: bold; font-size: 16px;">86911930</div>                        
                        <div class="col-120"></div>
                        <div class="col-56" style="line-height: 40px; text-align: center; font-weight: bold; font-size: 16px;">369<span style="margin-left: 20px;">86911930</span></div>                        
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 120px;">
                            <div class="row print-height">
                                <div class="col-120"><span class="font-10px">Shipper's Name and Address</span></div>
                                <div class="col-120 bd-left bd-bottom"><span class="font-10px">Exporter's Account Number</span></div>
                            </div>
                            <div style="padding: 5px; margin-top: -10px; line-height: 1.2;">
                                ZHUJI CITY SAIHE TRADE CO., LTD<br />
                                No. 179, Hefeng Natural Village, Tangshan Village, Taozhu Street, Zhuji City, Shaoxing City, Zhejiang Province 311800<br />
                                TEL:TEL:0755-28346906<br />
                                91330681MAC8U9UJ0D
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 120px;">
                            <div>
                                <div class="font-10px">Not Negotiation</div>
                                <div class="font-16px" style="padding: 0px 5px; line-height: 1;">Air Waybill</div>
                                <div class="font-10px">Issued by</div>
                            </div>
                            <div style="font-weight: bold; text-align: center;">
                                SHENZHEN JIUFANG E-COMMERCE LOGISTICS LTD
                            </div>
                            <div class="font-10px bd-top" style="position: absolute; bottom: 0px;">Copise 1,2and 3 of this Air Waybill are originals and have the same validity</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 120px;">
                            <div class="row print-height">
                                <div class="col-120"><span class="font-10px">Consignee's Name and Address</span></div>
                                <div class="col-120 bd-left bd-bottom"><span class="font-10px">Consignee's Account Number</span></div>
                            </div>
                            <div style="padding: 5px; margin-top: -10px; line-height: 1.2;">
                                FULLJOY MARKETING INC<br />
                                881 BAXTER DRIVE STE 100 SOUTH JORDAN, UT 84095<br />
                                TEL:626-669-5709<br />
                                EIN NO.:87-3226222
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 120px;">
                            <div class="font-10px" style="line-height: 1.3;">
                                It is agreed that the goods described herein are accepted in apperent good order and condition (except as noted)for carriage SUBJECT TO THE CONDITIONS AND OF CONTRACT ON THE REVERSE  HEREOF,THE SHIPPER'S ATTENTION IS DRAWN ON THE TO THE NOTICE CONCERNING CARRIERS LIMITATION  OF LIABILITY IN RESPECT OF DELAY, LOSS OF OR DAMAGE TO GOODS.Shipper may increase such limation of liability by declaring a higher value for carriage and paying a suppiemental charge if required.
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 120px;">
                            <div class="font-10px">Issuing Carrier's Agent Name and City</div>
                            <div style="text-align: center; margin-top: 10px;">ZWY/CSX</div>

                            <div class="row print-height" style="position: absolute; bottom: 0px; width: 100%;">
                                <div class="col-120 bd-top"><span class="font-10px">Agent's IATA Code</span></div>
                                <div class="col-120 bd-top bd-left"><span class="font-10px">Account No.</span></div>
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 120px;">
                            <div class="font-10px">Accounting Information</div>
                            <div style="text-align: center; margin-top: 10px;">FRIGHT PREPAID </div>
                        </div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-120">
                            <div class="font-10px">Airport of Departure</div>
                            <div style="padding-left: 5px;">CSX</div>
                        </div>
                        <div class="col-50 bd-left"><div class="font-10px" style="text-align: center;">Reference Number</div></div>
                        <div class="col-40 bd-left"><div class="font-10px" style="text-align: center;">Optional Shipping Information</div></div>
                        <div class="col-30 bd-left"></div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-12">
                            <div class="font-10px">To</div>
                            <div class="print-content">JFK</div>
                        </div>
                        <div class="col-60 bd-left">
                            <div class="font-10px">By First Carrier</div>
                            <div class="print-content" style="text-align: center;">5Y</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">to</div>
                            <div class="print-content">ADD</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">by</div>
                            <div class="print-content">ET</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">to</div>                            
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">by</div>                            
                        </div>


                        <div class="col-14 bd-left">
                            <div class="font-10px" style="padding-left: 2px;">Currency</div>
                            <div class="print-content" style="text-align: center;">CNY</div>
                        </div>
                        <div class="col-8 bd-left">
                            <div class="font-8px">CHGS Code</div>                            
                        </div>
                        <div class="col-14 bd-left">
                            <div class="font-10px" style="text-align: center; padding-top: 2px;">WT/VAL</div>
                            <div class="row bd-top" style="height: calc(100% - 14px);">
                                <div class="col-120">
                                    <div class="font-8px">PPD</div>
                                    <div style="margin-top: -5px; text-align: center;">PP</div>
                                </div>
                                <div class="col-120 bd-left">
                                    <div class="font-8px">COLL</div>
                                    <div class="print-content"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-14 bd-left">
                            <div class="font-10px" style="text-align: center; padding-top: 2px;">Other</div>
                            <div class="row bd-top" style="height: calc(100% - 14px);">
                                <div class="col-120">
                                    <div class="font-8px">PPD</div>
                                    <div style="margin-top: -5px; text-align: center;">PP</div>
                                </div>
                                <div class="col-120 bd-left">
                                    <div class="font-8px">COLL</div>
                                    <div class="print-content"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-40 bd-left">
                            <div class="font-10px" style="padding: 5px 0px 0px 2px;">Declared Value for Carriage</div>
                            <div style="text-align: center;">N.V.D</div>
                        </div>
                        <div class="col-30 bd-left">
                            <div class="font-10px">Declared Comtoms</div>
                            <div style="text-align: center; font-size: 12px;">AS PER HAWB</div>
                        </div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-60">
                            <div class="font-10px">Airport of Destination</div>
                            <div style="text-align: center;">New York</div>
                        </div>
                        <div class="col-60 bd-left">
                            <div style="text-align: center;">
                                <div class="bd-all" style="display: inline-block; border-top: none;">
                                    <span class="font-10px2" style="margin-left: 15px;">Flight/Date</span>
                                </div>                                
                            </div>
                            <div class="row" style="height: calc(100% - 14px);">
                                <div class="col-120" style="text-align: center; padding-top: 5px;">5Y8796</div>
                                <div class="col-120 bd-left" style="text-align: center; padding-top: 5px;">2023-08-08 </div>
                            </div>
                        </div>

                        <div class="col-36 bd-left">
                            <div class="font-10px">Amount of insurance</div>
                            <div style="text-align: center;">NIL</div>
                        </div>
                        <div class="col-79 bd-left">
                            <div class="font-8px" style="padding: 5px 5px 0px 5px; position: absolute;">INSURANCE:If Carrier offers insurance,and such insurance is requested in accordance with the conditions thereof,indicate amount to be insured in figures in box marked Amount of insurance.</div>                            
                        </div>
                        <div class="col-5 bd-left">
                            <div class="font-10px" style="padding-left: 2px;">TC</div>
                        </div>
                    </div>

                    <div class="row" style="height: 80px;">
                        <div class="col-210">
                            <div class="font-10px">Handling Information</div>
                            <div style="padding: 5px; margin-top: -5px; line-height: 1.2;">
                                FULLJOY MARKETING INC<br />
                                881 BAXTER DRIVE STE 100 SOUTH JORDAN, UT 84095<br />
                                TEL:626-669-5709
                            </div>
                        </div>
                        <div class="col-30">
                            <div style="height: 40px;"></div>
                            <div class="bd-left bd-top" style="height: 40px;">
                                <div class="font-10px" style="text-align: center;">SCI</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row print-height">
                        <div class="col-12 bd-bottom">
                            <div class="font-10px" style="text-align: center;">No. of Pieces RCP</div>
                        </div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Gross<br />Weight</div>
                        </div>
                        <div class="col-4 bd-left bd-bottom">
                            <div class="font-9px" style="padding-top: 5px;">kg<br /><br />lb</div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20">
                            <div class="font-10px" style="text-align: center; margin-left: -15px;">Rate Class</div>
                            <div class="bd-left bd-top bd-bottom" style="position: absolute; bottom: 0px;">
                                <div class="font-10px" style="text-align: center; padding: 0px;">Commodity Item No.</div>
                            </div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Chargeable Weight</div>
                        </div>
                    
                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Rage/Charge</div>
                        </div>


                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Total</div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Nature and Quantity Goods<br />(incl.Dimensions or Volume)</div>
                        </div>
                    </div>
                    <div class="row" style="height: 200px; position: relative;">
                        <div style="position: absolute; left: 5px; top:40px; width: 45%; z-index: 50; line-height: 1.3;">test 森岛帆高森岛帆高水电费水电费水电费水电费水电费三个水电费水电费十多个公司大发</div>
                        <div class="col-12 bd-bottom"><div style="text-align: center; margin-top: 10px;">232</div></div>
                        <div class="col-24 bd-left bd-bottom"><div style="text-align: center; margin-top: 10px;">1084.0</div></div>
                        <div class="col-4 bd-left"><div style="text-align: center; margin-top: 10px; position: absolute; z-index: 1;">KQ</div></div>
                        
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20 bd-left"></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;">2263.0</div></div>
                    
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;">57.14</div></div>


                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-bottom"><div style="text-align: center; margin-top: 10px;">129307.82</div></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left" style="padding: 10px 5px 0px 5px;">
                            <div>CONSOLIDATION</div>
                            <div style="margin-top: 5px;">DIMS：</div>
                            <div style="position: absolute;">
                                <div style="margin-top: 5px;">
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                </div>
                                <div>CARTONS</div>
                                <div style="margin-top: 5px;">VOL：13.58CBM</div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="row print-height">
                        <div class="col-12"><div style="text-align: center; margin-top: 10px;">232</div></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;">1084.0</div></div>
                        <div class="col-4 bd-left"></div>
                        
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20 bd-left"></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"></div>
                    
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"></div>


                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left"><div style="text-align: center; margin-top: 10px;">129307.82</div></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left">                            
                        </div>
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row print-height bd-bottom">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 20px; z-index: 10;">
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;">Prepaid</div>
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;">Weight Charge</div>
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;">Collect</div>
                            </div>
                            
                            <div class="row print-height">
                                <div class="col-120" style="text-align: center; padding-top: 19px;">129307.82</div>
                                <div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left">
                            <div class="font-10px">Other Charges</div>
                            <div style="position: absolute; z-index: 10; left: 5px; line-height: 1.2;">
                                AWC：50<br />
                                MYC：36208.00<br />
                                MSC：3394.5
                            </div>
                        </div>                        
                    </div>
                    <div class="row print-height bd-bottom">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 27px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;">Valuation Charge</div>                                
                            </div>                            
                            <div class="row print-height">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left"></div>
                    </div>
                    <div class="row print-height">
                        <div class="col-92 bd-left bd-bottom" style="background-color: #f56c6c;">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 7px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #f56c6c;">Tax</div>                                
                            </div>                            
                            <div class="row print-height">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left bd-bottom"></div>
                    </div>

                    <div class="row print-height">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 32px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;">Total Other Charges Due Agent</div>                                
                            </div>              
                            <div class="row print-height bd-bottom">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left">
                            <div class="font-10px" style="position: absolute; line-height: 1.1;">
                                Shipper certifies that the particulars on the face hereof are correct and that insofar as any part of the consignment contains restricted articles,such part is properly described by name and is in proper condition for carriage by air acording to the International Air Transport Association's Restricted Articles Regulations.
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-92 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 32px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;background-color: #fff;">Total Other Charges Due Carrier</div>                                
                            </div>
                            <div class="row print-height">
                                <div class="col-120" style="text-align: center; padding-top: 19px;">129307.82</div>
                                <div class="col-120 bd-left"></div>
                            </div>
                            
                        </div>
                        <div class="col-148 bd-left" style="text-align: center; padding: 10px 10px 0px 10px;">
                            SHENZHEN JIUFANG E-COMMERCE LOGISTICS LTD
                        </div>
                    </div>

                    <div class="row print-height bd-left">
                        <div class="col-46 bd-top bd-bottom" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-top bd-bottom" style="background-color: #f56c6c;"></div>
                        <div class="col-148 bd-left bd-bottom">
                            <div class="font-10px" style="position: absolute; bottom: 2px; text-align: center;">Signature of Shipper or his Agent</div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 17px;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Prepaid</div>                                
                            </div>
                            <div style="text-align: center; padding-top: 19px;">129307.82</div>
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 17px;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Collect</div>                                
                            </div>                            
                        </div>
                        <div class="col-148 bd-left">              
                            <div class="row" style="padding-top: 13px;">
                                <div class="col-120" style="text-align: center;">2023/06/15</div>
                                <div class="col-120" style="text-align: center;">071 94859483</div>
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 119%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 5px; border-top: none;">Currency Conversion Rates</div>                                
                            </div>                            
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 120%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 5px; border-top: none;">CC Charges in Dest.Currency</div>                                
                            </div>
                        </div>
                        <div class="col-148 bd-left bd-bottom">              
                            <div class="bd-top" style="position: absolute; bottom: 0px; width: 100%; border-top-style: dashed;">
                                <div class="font-10px">Executed on <span style="margin-left: 60px;">(Date)</span> <span style="margin-left: 60px;">at</span> <span style="margin-left: 60px;">(Place)</span></div>
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">                            
                            <div class="font-10px" style="text-align: center;">For Carriers Use Only Of at Destination</div>
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 117%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Charges at Destination</div>
                            </div>
                        </div>
                        <div class="col-46 bd-left bd-bottom bd-right">
                            <div style="position: absolute; text-align: center; width: 117%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Collect Charges</div>                                
                            </div>                            
                        </div>
                    </div>
                </div>
                               
            </div>
        </div>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">            
            <el-button size="small" type="success" icon="el-icon-printer" onclick="printJS({printable:'divPrint',type:'html',css:'/static/script/hcui.css'})">打 印</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>
</template>

<script>

export default {
    data: function() {
        return{
            arrSelect: [],

            arrOutOrderSize:[],
            arrOutOrderItem:[],
            objAirLine: null,
            objPost:{

            },
            objData:{
                Id: this.Id,
            }
        }
    },
    props:{    
        Id:{
            type: Number,
            default: null
        },        
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {        
    },
    watch: {
    },
    created: function() {       
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){            
            this.$ajax.get('/Admin/OutOrder/GetDetail?Id=' + this.objData.Id, null,{async:false}).done(objResult=> {                
                this.objData = objResult.data[0];                
                this.objAirLine = this.$store.state.AirLine.objMapping[this.objData.AL_Id];

                // if(this.objData.DirectOrder==1){
                //     this.arrSelect.push[{Type:1,OO_Id:this.objData.Id,OOI_Id:null,}]
                // }


                if(this.objData.DirectOrder==1 || this.objData.IsEnterSize==0){
                    for(var i = 0; i < objResult.extData.arrOutOrderSize.length; i++){
                        this.arrOutOrderSize.push(objResult.extData.arrOutOrderSize[i]);
                    }
                }

                if(this.objData.DirectOrder==2){
                    var nIndex;
                    for(var i = 0; i < objResult.extData.arrOutOrderItem.length; i++){
                        this.arrOutOrderItem.push(objResult.extData.arrOutOrderItem[i]);

                        nIndex = this.arrOutOrderItem.length - 1;
                        this.arrOutOrderItem[nIndex].strSizeFormat = "";
                        this.arrOutOrderItem[nIndex].arrOutOrderSize = [];  
                        if(this.objData.IsEnterSize==1){                                                                                          
                            for(var j = 0; j < objResult.extData.arrOutOrderSize.length; j++){                                    
                                if(objResult.extData.arrOutOrderItem[i].Id == objResult.extData.arrOutOrderSize[j].OOI_Id){                                                                                
                                    this.arrOutOrderItem[nIndex].arrOutOrderSize.push(objResult.extData.arrOutOrderSize[j]);
                                }
                            }
                        }
                    }

                    if(this.objData.IsEnterSize==1){
                        var blnHas = false;

                        this.arrOutOrderSize = [];
                        for(var i = 0; i < this.arrOutOrderItem.length; i++){                        
                            for(var j = 0; j < this.arrOutOrderItem[i].arrOutOrderSize.length; j++){
                                blnHas = false;
                                if(this.arrOutOrderItem[i].arrOutOrderSize[j].Piece == null){                                
                                    continue;
                                }
                                for(var m = 0; m < this.arrOutOrderSize.length; m++){
                                    if(this.arrOutOrderItem[i].arrOutOrderSize[j].Long == this.arrOutOrderSize[m].Long && this.arrOutOrderItem[i].arrOutOrderSize[j].Width == this.arrOutOrderSize[m].Width && this.arrOutOrderItem[i].arrOutOrderSize[j].Height == this.arrOutOrderSize[m].Height){
                                        this.arrOutOrderSize[m].Piece += this.arrOutOrderItem[i].arrOutOrderSize[j].Piece;
                                        blnHas = true;
                                    }
                                }
                                if(blnHas == false){
                                    this.arrOutOrderSize.push(JSON.parse(JSON.stringify(this.arrOutOrderItem[i].arrOutOrderSize[j])));
                                    this.arrOutOrderSize[this.arrOutOrderSize.length-1].Id = null;
                                }
                            }
                        }
                    }
                }
            });
        }
    }
}

</script>

<style scoped>

</styl>
