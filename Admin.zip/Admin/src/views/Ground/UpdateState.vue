<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div v-if="objData.OldState==22" class="row form-item-hd-left">
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航线</div>                    
                    <div class="form-item-bd">{{$store.state.AirLine.objMapping[objData.AL_Id].Name}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>航班号</div>                    
                    <validation-provider tag="div" class="form-item-bd" name="航班号" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.F_Id" filterable placeholder="请选择" clearable style="width: 300px;">
                            <el-option v-for="objItem in arrFlight" :key="objItem.Id" :label="objItem.Number" :value="objItem.Id"></el-option>
                        </el-select>

                        <!-- <hc-popup-radio v-model="objData.F_Id" :data="arrFlight" name-key="Number" position="bottom" :mode="1" :filter="false"></hc-popup-radio> -->
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>
                    
                </div>
                <hc-text-item class="col-240" type="tel" v-model="objData.Number" validate="required" name="空运单号"></hc-text-item>
                <hc-text-item class="col-240" v-model="objData.ToCityCode" validate="required" name="目的港三字码"></hc-text-item>

            </div>
            <div v-else-if="objData.OldState==33" class="row form-item-hd-left">
                <div class="col-240 form-item">
                    <div class="form-item-hd">空运单号</div>                    
                    <div class="form-item-bd">{{objData.Number}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属客户</div>                    
                    <validation-provider tag="div" class="form-item-bd" name="所属客户" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.CC_IdDM" filterable placeholder="请选择" style="width: 300px;">
                            <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(1004)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <!-- <hc-popup-radio v-model="objData.CC_IdDM" :data="$lib.Common.getArrByField($store.state.CompanyCustomer.arrData,'C_Id',1004)" position="bottom" :mode="1" :filter="false"></hc-popup-radio> -->
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        OldState:{
            type: Number,
            default: null
        },
        ToState:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }        
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
   
            arrFlight:[],
            objData:{
                Id: this.Id,
                ToState: this.ToState,
                OldState: this.OldState,
                Number: "",
                
                /* OldState=22,ToState=23 */
                AL_Id: null,
                F_Id: null,
                Number: "",
                ToCityCode: "",

                /* OldState=33,ToState=34,35 */
                CC_IdDM: null,

            }       
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {                   
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
            this.$ajax.get('/Admin/OutOrder/GetById?Id=' + this.objData.Id, null,{async:false}).then(objResult=> {                  
                if(objResult.success == false){                    
                    this.$alert(objResult.message, '系统提示', { type: 'error' });
                    return;
                }
                                        
                for (var strKey in this.objData) {
                    switch (strKey) {             
                        case "ToState":
                        case "OldState":
                            break;
                        default:
                            this.objData[strKey] = objResult.data[0][strKey];
                            break;
                    }
                }

                if(this.objData.ToState == 23){
                    this.loadFlight(objResult.data[0]["AL_Id"]);
                }
            });                            
        },
        loadFlight: function(AL_Id){
            var objWhere = {
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": AL_Id, "strSingleQuotes": "" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                    objResult.data[i].Number = objResult.data[i].Date + "_" + objResult.data[i].Number;
                }
                this.arrFlight = objResult.data;                                                
            });
        },


        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;
            
            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/GroundUpdateState', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$parent.refreshListItem(this.objData.Id,this.objData.ToState);
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>

</style>
