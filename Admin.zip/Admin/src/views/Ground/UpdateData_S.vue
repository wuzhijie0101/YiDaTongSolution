<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="col-240 form-item">
                <div class="form-item-hd">单号</div>                    
                <div class="form-item-bd">{{objData.Number}}</div>
                <div class="form-item-ft"></div>
            </div>
            <div v-if="Option=='GroundRemark'" class="row form-item-hd-left">
                <hc-text-item class="col-240" v-model="objData.GroundRemark" name="地面备注"></hc-text-item>
            </div>

        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        Option: {
            type: String,
            default: ""
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
   
            objData:{
                Id: this.Id,
                Number: "",
                
                /* Option=GroundRemark */
                GroundRemark: "",
            }       
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {                   
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
            this.$ajax.get('/Admin/OutOrder/GetById?Id=' + this.objData.Id, null,{async:false}).then(objResult=> {                  
                if(objResult.success == false){                    
                    this.$alert(objResult.message, '系统提示', { type: 'error' });
                    return;
                }
                                        
                for (var strKey in this.objData) {
                    switch (strKey) {             
                        default:
                            this.objData[strKey] = objResult.data[0][strKey];
                            break;
                    }
                }
            });                            
        },
        
        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/UpdateData?FromPage=GroundRemark', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>

</style>
