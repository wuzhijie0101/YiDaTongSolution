<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">  
        <div style="position: sticky; top: 0px; z-index: 1;">     
            <div style="display: flex; background: #fff; align-items: center; padding: 10px; border-bottom: 1px solid #ddd;">
                <div>
                    <select @change="loadFlight($event.target.value)" class="hc_select hc_form-small" style="width: 105px;">
                        <option v-for="strItem in arrDate" :value='strItem'>{{strItem}}</option>                    
                    </select>
                </div>
                <div style="text-align: right; flex-grow: 1;">
                    <input type="tel" v-model="strFilter" class="hc_text-mini" @click="$event.currentTarget.select();" placeholder="空运单号关键字" style="background: #fff; width: 120px;" /> <span class="hc_button-text" @click="strFilter='';">清除</span>
                    <span class="hc_button-text" @click="loadOrder(objFlight.AL_Id,objFlight.Id);loadOrderByAL();">刷新数据</span>
                </div>
            </div>
            <div class="scrollbar1 chd_dis-flight" style="border-bottom: 1px solid #ddd;">            
                <span v-for="objItem in arrFlight" :class="objFlight.Id==objItem.Id?'on':''" @click="objFlight=objItem;loadOrder(objItem.AL_Id,objItem.Id);loadOrderByAL();" style="cursor: pointer;">{{objItem.Number}}</span>            
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">客服</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',1)}}【客服车队】<span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" style="float: right;" @click="openGroundStartDrive(objFlight.Id);">发车</span></div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==1" :key="objItem.Id+'_1'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',2)}}【地面办公室】</div>
                <div v-for="objItem in objCar['2']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>
                    <!-- <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" style="font-size: 1.3rem;"><span class="hc_button-text" @click="updateStateByCar(objItem.CarNumber,2,20)">进前置仓</span>|<span class="hc_button-text" @click="openGroundUpdateStateByCar(objFlight.Id,objItem.CarNumber)">进监管仓</span></div> -->
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',3)}}【地面现场】</div>
                <div v-for="objItem in objCar['3']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>
                </div>
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">前置仓</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',21)}}【客服】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>                
                <div v-for="objItem in arrOrderAL" v-if="objItem.State==21" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_21'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><a v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" :href="$lib.Config.Url_WeChat+'/OutOrder/DetailUnload?Id='+objItem.Id" target="_blank">数据对比</a> | <span class="hc_button-text" @click="updateState(objItem.Id,22)">已确认</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',22)}}【客服】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>
                <div v-for="objItem in arrOrderAL" v-if="objItem.State==22" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_22'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{(objItem.VirNumber==''?objItem.Number:objItem.VirNumber)}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundUpdateState(objItem.Id,22,23);">确认发货</span></div>
                </div>
            </div>
        </div>

        <!-- <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">跨境电商</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">  
            <div class="row chd_dis-item" >
                <div class="col-240 title">离场前【客服】</div>
                
                <div v-for="objItem in arrOrder" v-if="objItem.State>=10 && objItem.State<=14" :key="objItem.Id+'_14'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,1);">完善数据</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',30)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==30" :key="objItem.Id+'_30'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,1);">完善数据</span> | <span class="hc_button-text" @click="updateState(objItem.Id,31)">已完成</span></div>
                </div>
            </div>
        </div> -->

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">地面</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">                        
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',31)}}【地面现场】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==31" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_31'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',32)}}【客服】</div>                
                <div v-for="objItem in arrOrder" v-if="objItem.State==32" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_32'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div><a v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" :href="$lib.Config.Url_WeChat+'/OutOrder/DetailUnload?Id='+objItem.Id" target="_blank">数据对比</a> | <span class="hc_button-text"  @click="updateState(objItem.Id,33)">已确认</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',33)}}【地面办公室】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==33" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_33'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',34)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==34" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_34'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,35);">已审结</span></div>
                </div>
            </div>
            
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',35)}}【地面办公室】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==35" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_35'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',36)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==36" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_36'" class="col-120 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',37)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==37" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_37'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,2)">原单重申报</span> | <span class="hc_button-text" @click="openOutOrderEdit(objItem.Id,3)">新单重申报</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',38)}}【客服】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==38" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_38'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <!-- <div v-show="objItem.Type==1 && $store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundUpdateState(objItem.Id,38,39);">已拿放行条</span></div> -->
                    <div v-show="objItem.Type==1 && $store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,39)">已拿放行条</span></div>
                    <div v-show="objItem.Type==2 && $store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="updateState(objItem.Id,39)">已盖放行章</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">{{$lib.Store.getValFromDic('OutOrder_State',39)}}【地面现场】</div>
                <div v-for="objItem in arrOrder" v-if="objItem.State==39" v-show="objItem.Number.indexOf(strFilter)>-1" :key="objItem.Id+'_39'" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}</div>
                    <div></div>
                </div>
            </div>
        </div>


        <!-- <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; margin-bottom: 10px; padding: 0px 10px;">
            <div class="row chd_dis-item" >
                <div class="col-240 title">待删除处理【地面办公室】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>
                <div v-for="objItem in arrTask" v-if="objItem.Type==4 || objItem.Type==5" :key="objItem.Id" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.BizId);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" v-show="objItem.ToDo1==1" @click="updateToDo(objItem.Id,'ToDo1')">已撤关</span> <span class="hc_button-text" v-show="objItem.ToDo2==1" @click="updateToDo(objItem.Id,'ToDo2')">| 已删运抵</span> <span class="hc_button-text" v-show="objItem.ToDo3==1" @click="updateToDo(objItem.Id,'ToDo3')">| 已删预配</span> <span class="hc_button-text" v-show="objItem.ToDo5==1" @click="updateToDo(objItem.Id,'ToDo5')">| 已安检退货</span> <span class="hc_button-text" v-show="objItem.ToDo4==1" @click="updateToDo(objItem.Id,'ToDo4')">| 已退货物</span></div>
                </div>
            </div>
            <div class="row chd_dis-item" >
                <div class="col-240 title">待退件处理【地面办公室】<span class="clr-text3" style="font-size: 1.4rem;">航线级别</span></div>
                <div v-for="objItem in arrTask" v-if="objItem.Type==3" :key="objItem.Id" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.BizId);">{{objItem.Number}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openLogisticsOrderEdit(3,objItem.BizId);">录快递</span> | <span class="hc_button-text" @click="updateToDo(objItem.Id,'ToDo1')">已处理</span></div>
                </div>
            </div>   
        </div> -->

        <div style="height: 20px;"></div>
    </div>
</template>

<script>
import OutOrderEdit from '@/views/OutOrder/Edit.vue';
import OutOrderDetail from '@/views/OutOrder/Detail.vue';

import GroundUpdateStateByCar from '@/views/Ground/UpdateStateByCar.vue';
import GroundUpdateState from '@/views/Ground/UpdateState.vue';
// import GroundUpdateData from '@/views/Ground/UpdateData.vue';
import LogisticsOrderEdit from '@/views/LogisticsOrder/Edit.vue';
import GroundStartDrive from '@/views/Ground/StartDrive.vue';

export default {
    data: function() {
        return{
            PM_Id: 305,

            arrDate:[],         // 航班日期列表
            arrFlight:[],       // 当前航班日期下的所有航班
            arrAllFlight:[],    // 一个月内所有未结束的航班   
            objFlight: null,    // 当前选中的航班

            strFilter: "",          // 空运单号关键字
            arrOrder: [],
            arrOrderAL: [],
            objCar: {"2":[],"3":[]},
            
            arrTask: []
        }
    },
    props:{    
        BizParam:{
            type: Object,
            default: null
        }
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        var objWhere = {
            "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
        }
        this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc,AL_Id asc" }).then(objResult => {
            for(var i = 0; i < objResult.data.length; i++){
                objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
            }
            this.arrAllFlight = objResult.data;

            var strDate = ",";
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(strDate.indexOf(','+this.arrAllFlight[i].Date+',') == -1){
                    this.arrDate.push(this.arrAllFlight[i].Date);
                    strDate += this.arrAllFlight[i].Date + ",";
                }
            }

            if(this.arrAllFlight.length>1){
                this.loadFlight(this.arrAllFlight[0].Date);
            }
        });

        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                        
        },

        loadFlight: function(strDate){                    
            this.arrFlight = [];
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(this.arrAllFlight[i].Date == strDate){
                    this.arrFlight.push(this.arrAllFlight[i]);
                }
            }
            this.objFlight = this.arrFlight[0];

            this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
            this.loadOrderByAL();
            this.loadTask();
        },
        loadOrder: function(nAL_Id, nF_Id){                    
            var objWhere = {
                "C_Id": { "strField": "C_IdKF", "strCondition": "=", "strValue": 1001, "strSingleQuotes": "" },
                // "State": { "strField": "State", "strCondition": ">=", "strValue": 10, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "<", "strValue": 50, "strSingleQuotes": "" },
                "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": nF_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Type,Number,VirNumber,CT_Id,CarNumber", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                        
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].State == 20 || objResult.data[i].State == 23){
                        objResult.data.splice(i,1);
                    }
                    objResult.data[i].Number = objResult.data[i].Number.substr(4);
                }
                this.arrOrder = objResult.data;

                this.objCar = {"2":[],"3":[]};
                var strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State==2){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['2'].push({CT_Id:objResult.data[i].CT_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }                                
                    }
                }

                strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State==3){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['3'].push({CT_Id:objResult.data[i].CT_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }                                
                    }
                }

                // this.objCross = {"14":{},"30":{}};

                // // var strKey = "";
                // for(var i = 0; i < this.arrOrder.length; i++){                            
                //     // strKey = "" + this.arrOrder[i].State;
                //     if(this.arrOrder[i].State>10 && this.arrOrder[i].State<20){
                //         if(this.objCross["14"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                //             this.objCross["14"][this.arrOrder[i].CarNumber] = [];
                //         }
                //         this.objCross["14"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                //     }
                //     else if(this.arrOrder[i].State==30){
                //         if(this.objCross["30"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                //             this.objCross["30"][this.arrOrder[i].CarNumber] = [];
                //         }
                //         this.objCross["30"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                //     }
                // }
            });
        },
        loadOrderByAL: function(){                    
            var objWhere = {
                "C_Id": { "strField": "C_IdKF", "strCondition": "=", "strValue": 1001, "strSingleQuotes": "" },
                // "State": { "strField": "State", "strCondition": ">=", "strValue": 10, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "in", "strValue": "21,22", "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objFlight.AL_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Type,Number,VirNumber,CT_Id,CarNumber", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                        
                this.arrOrderAL = objResult.data;                                                                             
            });                    
        },
        loadTask: function(){       
            return;             
            var objWhere = {
                "Type": { "strField": "Type", "strCondition": "in", "strValue": "3,4,5", "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objFlight.AL_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrderTask/Get', { Field: "*", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                        
                this.arrTask = objResult.data;
            });
        },
        

        refreshList: function(){
            this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
        },
        refreshListItem: function(nId, nToState){    
            if(nToState==23){
                for(var i = 0; i < this.arrOrderAL.length; i++){
                    if(this.arrOrderAL[i].Id == nId){
                        this.arrOrderAL[i].State = nToState;
                        break;
                    }
                }
            }
            else{
                for(var i = 0; i < this.arrOrder.length; i++){
                    if(this.arrOrder[i].Id == nId){
                        this.arrOrder[i].State = nToState;
                        break;
                    }
                }
            }   
        },
        updateStateByCar: function(CarNumber,OldState,ToState){ // 仅用在“运输中”和“待车辆放行”两个状态
            var strConfirm = (OldState==2?"确定该车辆进前置仓吗？":"确定该车辆已从岗亭放行吗？");

            this.$confirm(strConfirm, '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/GroundUpdateStateByCar?F_Id="+this.objFlight.Id+"&CarNumber="+CarNumber+"&OldState="+OldState+"&ToState=" + ToState).then(objResult=> {
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});                    
                    this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
                    this.loadOrderByAL();
                });
            }).catch(function () {
            });
        },
        updateState: function(nId,nToState, blnLoad){
            this.$confirm("确定执行该操作吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/GroundUpdateState",{Id:nId, ToState: nToState}).then(objResult=> {
                    if(objResult.success == false){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});
                    if(blnLoad==true){
                        this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
                    }
                    else{
                        if(nToState == 22){
                            for(var i = 0; i < this.arrOrderAL.length; i++){
                                if(this.arrOrderAL[i].Id == nId){
                                    this.arrOrderAL[i].State = nToState;
                                    break;
                                }
                            }
                        }
                        else{
                            for(var i = 0; i < this.arrOrder.length; i++){
                                if(this.arrOrder[i].Id == nId){
                                    this.arrOrder[i].State = nToState;
                                    break;
                                }
                            }
                        }
                    }
                    
                });
            }).catch(function () {
            });
        },
        updateToDo: function(nId, strToDo){
            this.$confirm("确定将该项工作标记为已处理吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrderTask/UpdateToDo?Id=" + nId + "&ToDo=" + strToDo).then(objResult=> {                      
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                      
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});        
                    this.loadTask();
                });
            }).catch(function () {
            });
        },


        
        openOutOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: OutOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['800px','90%'],
                shadeClose: false,
                title: '货运单详情'
            });
        },
        openOutOrderEdit:function(nId,nMode){ // 新增或编辑     
            var strTitle= "";
            switch(nMode){
                case 1: strTitle="完善货运单数据";break;
                case 2: strTitle="原单号重申报";break;
                case 3: strTitle="新单号重申报";break;
            }
            this.$layer.iframe({
                content: {
                    content: OutOrderEdit,
                    parent: this,
                    data:{ Id:nId,C_Id:(this.$store.state.AirLine.objMapping[this.objFlight.AL_Id].PrimaryCode=='071'?1001:1004),Mode:nMode } 
                },
                area:['80%','90%'],
                shadeClose: false,
                title: strTitle
            });
        },
        openGroundStartDrive:function(nF_Id){
            this.$layer.iframe({
                content: {
                    content: GroundStartDrive,
                    parent: this,
                    data:{ F_Id:nF_Id } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '发车'
            });
        },
        openGroundUpdateStateByCar:function(nF_Id,CarNumber){     
            this.$layer.iframe({
                content: {
                    content: GroundUpdateStateByCar,
                    parent: this,
                    data:{ F_Id:nF_Id, CarNumber: CarNumber } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '进监管仓'
            });
        },
        openGroundUpdateState:function(Id,OldState,ToState){     
            this.$layer.iframe({
                content: {
                    content: GroundUpdateState,
                    parent: this,
                    data:{ Id:Id, OldState: OldState,ToState:ToState } 
                },
                area:['800px','400px'],
                shadeClose: false,
                title: this.$lib.Store.getValFromDic("OutOrder_State", OldState)
            });
            
        },

        openLogisticsOrderEdit:function(Type,OO_Id){     
            this.$layer.iframe({
                content: {
                    content: LogisticsOrderEdit,
                    parent: this,
                    data:{ Type:Type, BizId: OO_Id } 
                },
                area:['800px','300px'],
                shadeClose: false,
                title: "录快递"
            });            
        },                 
    }
}

</script>

<style scoped>

</style>
