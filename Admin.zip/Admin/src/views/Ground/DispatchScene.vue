<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="display: flex; background: #fff; align-items: center; padding: 10px; border-bottom: 1px solid #ddd;">
            <div>
                <select @change="loadFlight($event.target.value)" class="hc_select hc_form-small" style="width: 105px;">
                    <option v-for="strItem in arrDate" :value='strItem'>{{strItem}}</option>                    
                </select>
            </div>
            <div style="text-align: right; flex-grow: 1;">
                <span class="hc_button-text" @click="loadOrder(objFlight.AL_Id,objFlight.Id);loadOrderByScan();">刷新数据</span>
            </div>
        </div>
        <div class="scrollbar1 chd_dis-flight" style="border-bottom: 1px solid #ddd;">            
            <span v-for="objItem in arrFlight" :class="objFlight.Id==objItem.Id?'on':''" @click="objFlight=objItem;loadOrder(objItem.AL_Id,objItem.Id);loadOrderByScan();" style="cursor: pointer;">{{objItem.Number}}</span>            
        </div>

        <!-- <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">地面</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">
            <div class="row chd_dis-item" >
                <div class="col-240 title">待货车到达 - 待车辆放行</div>
                <div v-for="objItem in objCar['3']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>    
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundPrintCar(objFlight.Id,objItem.CarNumber)">打印清单</span></div>     
                </div>
            </div>
        </div>

        <div style="font-size: 1.6rem; font-weight: bold; margin-top: 10px; margin-left: 10px;">跨境电商</div>
        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">  
            <div class="row chd_dis-item" >
                <div class="col-240 title">待货车到达 - 待货车卸货</div>
                <div v-for="objItem in objCar['30']" class="col-80 body" style="text-align: center;">
                    <div>{{objItem.CarNumber}}</div>    
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundPrintCar(objFlight.Id,objItem.CarNumber,'Cross')">打印清单</span></div>     
                </div>
            </div>
        </div> -->


        <div class="hc_container-fluid" style="background: #fff; margin-top: 10px; padding: 0px 10px;">
            <div class="row chd_dis-item" >
                <div class="col-240 title">未上传扫描件 <span v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower" class="hc_button-text" @click="openGroundUploadScan(null,'');">上传</span></div>
                <div v-for="objItem in arrOrderScan" class="col-80 body" style="text-align: center;">
                    <div @click="openOutOrderDetail(objItem.Id);">{{objItem.Number}}_{{objItem.FlightDate}}</div>
                    <div v-show="$store.state.TabMenu.objMapping[PM_Id].HasPower"><span class="hc_button-text" @click="openGroundUploadScan(objItem.Id,objItem.Number)">上传扫描件</span></div>     
                </div>
            </div>
        </div>

        <div style="height: 20px;"></div>
    </div>
</template>

<script>
// import GroundPrintCar from '@/views/Ground/PrintCar.vue';
import OutOrderDetail from '@/views/OutOrder/Detail.vue';
import GroundUploadScan from '@/views/Ground/UploadScan.vue';

export default {
    data: function() {
        return{
            PM_Id: 321,

            arrDate:[],         // 航班日期列表
            arrFlight:[],       // 当前航班日期下的所有航班
            arrAllFlight:[],    // 一个月内所有未结束的航班   
            objFlight: null,    // 当前选中的航班

            arrOrder: [],
            arrOrderAL: [],
            arrOrderScan: [],   // 未上传提单扫描件
            objCar: {"3":[],"30":[]},
        }
    },
    props:{    
        BizParam:{
            type: Object,
            default: null
        }    
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        var objWhere = {
            "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
        }
        this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc,AL_Id asc" }).then(objResult => {
            for(var i = 0; i < objResult.data.length; i++){
                objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
            }
            this.arrAllFlight = objResult.data;

            var strDate = ",";
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(strDate.indexOf(','+this.arrAllFlight[i].Date+',') == -1){
                    this.arrDate.push(this.arrAllFlight[i].Date);
                    strDate += this.arrAllFlight[i].Date + ",";
                }
            }

            if(this.arrAllFlight.length>1){
                this.loadFlight(this.arrAllFlight[0].Date);
            }
        });

        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                        
        },

        loadFlight: function(strDate){                    
            this.arrFlight = [];
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(this.arrAllFlight[i].Date == strDate){
                    this.arrFlight.push(this.arrAllFlight[i]);
                }
            }
            this.objFlight = this.arrFlight[0];

            this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
            this.loadOrderByScan();
        },
        loadOrder: function(nAL_Id, nF_Id){                    
            var objWhere = {
                "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },
                // "State": { "strField": "State", "strCondition": ">=", "strValue": 10, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "<", "strValue": 50, "strSingleQuotes": "" },
                "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": nF_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Type,Number,VirNumber,CT_Id,CarNumber,C_IdKJ", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                        
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].State == 10 || objResult.data[i].State == 20 || objResult.data[i].State == 23){
                        objResult.data.splice(i,1);
                    }
                }
                this.arrOrder = objResult.data;

                var strCarNumber = "";
                this.objCar = {"3":[],"30":[]};
                strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State==2 || objResult.data[i].State==3){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['3'].push({CT_Id:objResult.data[i].CT_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }
                    }
                }

                strCarNumber = ",";
                for(var i = 0; i < objResult.data.length; i++){                            
                    if(objResult.data[i].State>10 && objResult.data[i].State<=31 && objResult.data[i].C_IdKJ==1002){
                        if(strCarNumber.indexOf(','+objResult.data[i].CarNumber+',') == -1){
                            this.objCar['30'].push({CT_Id:objResult.data[i].CT_Id, CarNumber:objResult.data[i].CarNumber});
                            strCarNumber += (objResult.data[i].CarNumber + ",");
                        }
                    }
                }

                // this.objCross = {"14":{},"30":{}};

                // // var strKey = "";
                // for(var i = 0; i < this.arrOrder.length; i++){                            
                //     // strKey = "" + this.arrOrder[i].State;
                //     if(this.arrOrder[i].State>10 && this.arrOrder[i].State<20){
                //         if(this.objCross["14"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                //             this.objCross["14"][this.arrOrder[i].CarNumber] = [];
                //         }
                //         this.objCross["14"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                //     }
                //     else if(this.arrOrder[i].State==30){
                //         if(this.objCross["30"].hasOwnProperty(this.arrOrder[i].CarNumber) == false){
                //             this.objCross["30"][this.arrOrder[i].CarNumber] = [];
                //         }
                //         this.objCross["30"][this.arrOrder[i].CarNumber].push(this.arrOrder[i]);
                //     }
                // }
            });
        },
        loadOrderByScan: function(){                    
            var objWhere = {
                "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "<", "strValue": "60", "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objFlight.AL_Id, "strSingleQuotes": "" },
                "OrderVoucher": { "strField": "OrderVoucher", "strCondition": "==", "strValue": "", "strSingleQuotes": "'" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Type,Number,FlightDate", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {    
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].FlightDate = this.$lib.Format.fmtDate(objResult.data[i].FlightDate);
                }                    
                this.arrOrderScan = objResult.data;                                                                             
            });
        },

        refreshList: function(){
            this.loadOrder(this.objFlight.AL_Id, this.objFlight.Id);
        },
        refreshListItem: function(nId, nToState){    
            for(var i = 0; i < this.arrOrder.length; i++){
                if(this.arrOrder[i].Id == nId){
                    this.arrOrder[i].State = nToState;
                    break;
                }
            }
        },
        openOutOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: OutOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['800px','90%'],
                shadeClose: false,
                title: '货运单详情'
            });
        },
        // openGroundPrintCar:function(nF_Id, CarNumber, strOption){     
        //     this.$layer.iframe({
        //         content: {
        //             content: GroundPrintCar,
        //             parent: this,
        //             data:{ Option:strOption, F_Id:nF_Id, CarNumber: CarNumber } 
        //         },
        //         area:['862px','80%'],
        //         shadeClose: false,
        //         title: '打印办卡清单'
        //     });
        // },
        openGroundUploadScan:function(nOO_Id, strNumber){
            this.$layer.iframe({
                content: {
                    content: GroundUploadScan,
                    parent: this,
                    data:{ AL_Id: this.objFlight.AL_Id, OO_Id: nOO_Id, Number: strNumber } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '上传扫描件'
            });
        }
                    
    }
}

</script>

<style scoped>

</style>
