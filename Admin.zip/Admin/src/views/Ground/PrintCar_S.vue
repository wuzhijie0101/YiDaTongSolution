<template>
    <div class="hc_container-fluid" style="height:100%;">       
        <div class="row" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div id="divPrint" style="width: 842px;">
                <table class="hc-table_print" style="width: 100%;">
                    <tr>
                        <td style="font-size: 2rem; font-weight: bold; text-align: center; padding: 10px 0px;">货物清单</td>
                    </tr>
                </table>
                
                <table class="hc-table_print" style="width: 100%; border-top:none;">
                    <thead>
                        <tr>
                            <td colspan="4">车牌：{{arrOrder[0].CarNumber}}</td>
                            <td colspan="3">日期：{{$dayjs().format("YYYY-MM-DD")}}</td>
                        </tr>
                        <tr>
                            <th style="width: 50px;">序号</th>
                            <th style="width: 100px;">航班日期</th>
                            <th style="width: 100px;">航班号</th>
                            <th style="width: 200px;">空运单号</th>
                            <th style="width: 100px;">件数</th>
                            <th style="width: 100px;">重量</th>
                            <th style="width: 150px;">备注</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(objItem,i) in arrOrder">
                            <td style="text-align: center;">{{i+1}}</td>
                            <td style="text-align: center;">{{i==0?objItem.FlightDate:""}}</td>
                            <td style="text-align: center;">{{i==0?objItem.FlightNumber:""}}</td>
                            <td style="text-align: center;">{{$store.state.AirLine.objMapping[objItem.AL_Id].PrimaryCode + "-" + objItem.Number}}</td>
                            <td style="text-align: center;">{{objItem.PrePiece}}</td>
                            <td style="text-align: center;">{{objItem.PreWeight}}</td>
                            <td></td>
                        </tr>
                        <tr v-for="i in (15-arrOrder.length)">
                            <td style="text-align: center;">{{arrOrder.length+i}}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <!-- <tr>
                            <td colspan="4" style="text-align: right;">合计：</td>
                            <td style="text-align: center;">{{nTotalPiece}}</td>
                            <td style="text-align: center;">{{nTotalWeight}}</td>
                            <td></td>
                        </tr> -->
                        <!-- <tr>
                            <td colspan="4" style="text-align: right; border-right: none; border-bottom: none;">交货员签字：</td>
                            <td colspan="3"></td>                            
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align: right; border-right: none; border-bottom: none;">卡口员签字：</td>
                            <td colspan="3"></td>                            
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align: right; border-right: none; border-bottom: none;">收运员签字：</td>
                            <td colspan="3"></td>                            
                        </tr> -->
                    </tbody>
                </table>

                <table class="hc-table_print" style="width: 100%; border:none; margin-top: 5px;">
                    <tbody>
                        <tr>
                            <td style="width: 450px;text-align: right; border-right: none; border-bottom: none;"></td>
                            <td style="width: 100px; border-right: none; border-bottom: none;">{{nTotalPiece}}</td>
                            <td style="width: 100px; border-right: none; border-bottom: none;">{{nTotalWeight}}</td>
                            <td style="width: 150px; border-right: none; border-bottom: none;"></td>
                        </tr>
                        <tr>
                            <td style="width: 450px;text-align: right; border-right: none; border-bottom: none;">交货员签字：</td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 150px; border-right: none; border-bottom: none;"></td>                        
                        </tr>
                        <tr>
                            <td style="width: 450px;text-align: right; border-right: none; border-bottom: none;">卡口员签字：</td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 150px; border-right: none; border-bottom: none;"></td>                             
                        </tr>
                        <tr>
                            <td style="width: 450px;text-align: right; border-right: none; border-bottom: none;">收运员签字：</td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 100px; border-right: none; border-bottom: none;"></td>
                            <td style="width: 150px; border-right: none; border-bottom: none;"></td>                         
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">            
            <el-button size="small" type="success" icon="el-icon-printer" onclick="printJS({printable:'divPrint',type:'html',css:'/static/script/hcui.css'})">打 印</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>
</template>

<script>

export default {
    data: function() {
        return{
            arrOrder: [],
            nTotalPiece: 0,
            nTotalWeight: 0
        }
    },
    props:{   
        Option: {
            type: String,
            default: ""
        },
        F_Id:{
            type: Number,
            default: null
        },
        CarNumber: {
            type: String,
            default: ""
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {        
    },
    watch: {
    },
    created: function() {       
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){       
            var objWhere = {};

            switch(this.Option){
                case "Cross":
                    objWhere = {
                        // "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },  
                        "State": { "strField": "State", "strCondition": ">", "strValue": 10, "strSingleQuotes": "" },                  
                        "State": { "strField": "State", "strCondition": "<=", "strValue": 31, "strSingleQuotes": "" },
                        "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": this.F_Id, "strSingleQuotes": "" },
                        "CarNumber": { "strField": "CarNumber", "strCondition": "=", "strValue": this.CarNumber, "strSingleQuotes": "'" },
                    }
                    break;
                default:
                    objWhere = {
                        // "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },                    
                        "State": { "strField": "State", "strCondition": "in", "strValue": "2,3", "strSingleQuotes": "" },
                        "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": this.F_Id, "strSingleQuotes": "" },
                        "CarNumber": { "strField": "CarNumber", "strCondition": "=", "strValue": this.CarNumber, "strSingleQuotes": "'" },
                    }
                    break;
            }
            
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Number,AL_Id,FlightDate,FlightNumber,PrePiece,PreWeight,CT_Id,CarNumber", Where:objWhere, OrderBy:"Id asc" },{async:false}).done(objResult=> {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].FlightDate = this.$lib.Format.fmtDate(objResult.data[i].FlightDate);
                    this.nTotalPiece += objResult.data[i].PrePiece;
                    this.nTotalWeight += objResult.data[i].PreWeight;
                }
                this.arrOrder = objResult.data;
            });
        }
    }
}

</script>

<style scoped>

</style>
