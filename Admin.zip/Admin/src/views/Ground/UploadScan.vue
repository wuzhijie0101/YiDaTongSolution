<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <template v-if="objData.OO_Id == null">
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航线</div>                    
                    <div class="form-item-bd">{{$store.state.AirLine.objMapping[objData.AL_Id].Name}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>航班号</div>                    
                    <validation-provider tag="div" class="form-item-bd" name="航班号" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.F_Id" filterable placeholder="请选择" clearable style="width: 300px;">
                            <el-option v-for="objItem in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>
                </div>
            </template>
            <template v-else>
                <div class="col-240 form-item">
                    <div class="form-item-hd">单号</div>                    
                    <div class="form-item-bd">{{this.Number}}</div>
                    <div class="form-item-ft"></div>
                </div>
            </template>
            
            <div class="row form-item-hd-left">
                <div class="col-240 form-item">
                    <div class="form-item-hd">扫描件</div>
                    <div class="form-item-bd">
                        <file-pond ref="upOrderVoucher" :allow-multiple="true" max-files="25" allow-drop="true" max-file-size="3MB" :server="$lib.Config.Url_ApiUpload + '/Open/FileUpload/UploadScan'" label-idle="点击上传" accepted-file-types="application/pdf"></file-pond> 
                    </div>
                </div>
                <div class="col-240 clr-text3" style="margin-top: 10px;">
                    分开格式：1750主单、1750分单、1750舱单、1750安全声明；<br />
                    合起格式：1850主单
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        AL_Id:{
            type: Number,
            default: null
        },
        OO_Id: {
            type: Number,
            default: null
        },
        Number: {
            type: String,
            default: ""
        },
        layerid: {
            type: String,
            default: ""
        }        
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
   
            arrFlight: [],
            objData:{
                OO_Id: this.OO_Id,  // 按单号导入

                AL_Id: this.AL_Id,  // 按航班导入
                F_Id: null,
                ItemCount: 0,
            }       
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {   
        if(this.objData.OO_Id == null){
            this.loadFlight(this.AL_Id);  
        }
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
                                      
        },
        loadFlight: function(AL_Id){
            var objWhere = {
                // "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": AL_Id, "strSingleQuotes": "" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;                                                
            });
        },
        
        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.objData.ItemCount=0;
            var objTemp;
            var strPath = "";
            var arrFiles = this.$refs.upOrderVoucher.getFiles(); 
            for(var i = 0; i < arrFiles.length; i++){
                if(arrFiles[i].status == 5){                                
                    objTemp = JSON.parse(arrFiles[i].serverId);    
                    console.log(objTemp);
                    this.objData["FileUrl" + this.objData.ItemCount] = objTemp.data;
                    this.objData["FileName" + this.objData.ItemCount] = objTemp.extData.strFileName;

                    this.objData.ItemCount += 1;
                }
            }
            
            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/'+(this.objData.OO_Id==null?'GroundUploadScan':'GroundUploadScanById'), this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$parent.loadOrderByScan();
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>
    .filepond--item { width: 48%; }
</style>
