<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">
                <hc-text-item class="col-240" v-model="objData.CarNumber" validate="required" name="车牌号"></hc-text-item>
                <hc-number-item class="col-240" v-model="objData.CarWeight" validate="numeric" name="货车重量"></hc-number-item>
                <hc-text-item class="col-240" v-model="objData.DriverName" name="司机"></hc-text-item>
                <hc-text-item class="col-240" type="tel" v-model="objData.DriverIdCard" name="身份证"></hc-text-item>
                <hc-text-item class="col-240" type="tel" v-model="objData.DriverMobile" validate="mobile:true" name="手机号"></hc-text-item>

                <div class="col-240 row">
                    <div class="col-240" style="margin-bottom: 5px; margin-top: 5px;">
                        <input type="tel" v-model="strFilter" class="hc_text-mini" @click="$event.currentTarget.select();" placeholder="空运单号关键字" style="background: #fff; width: 150px;" />
                        <span class="hc_button-text" @click="strFilter='';">清除</span>
                    </div>
                    <validation-provider tag="div" class="col-240 row" rules="required" v-slot="{ errors }">
                        <div v-for="objItem in arrOrder" v-show="objItem.Number.indexOf(strFilter)>-1" class="col-80">
                            <label class="hc_checkbox" style="display: block; margin-bottom: 10px;">
                                <input type="checkbox" v-model="objData.OO_Ids" :value="objItem.Id" name="空运单号" /> <span>{{(objItem.Number==''?objItem.VirNumber:objItem.Number)}}</span>                                            
                            </label>
                        </div>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 0px; bottom: 0px;">{{errors[0]}}</div>
                    </validation-provider>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交发车</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        AL_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            
            strFilter: "",
            arrOrder: [],
            objData:{
                CT_Id: null,
                CarNumber: "",
                CarWeight: null,

                // CD_Id: null,
                DriverName: "",
                DriverIdCard: "",
                DriverMobile: "",

                CL_Id: null,
                OO_Ids:[],
            },      
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {       
        this.loadOutOrder();            
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
        },
        loadOutOrder: function(){
            var objWhere = {
                // "C_Id": { "strField": "C_IdDM", "strCondition": "=", "strValue": 1004, "strSingleQuotes": "" },                    
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.AL_Id, "strSingleQuotes": "" }
            }
            this.$ajax.get('/Admin/OutOrder/Get', { Field: "Id,State,Number,VirNumber,CarNumber", Where:objWhere, OrderBy:"Id asc" }).then(objResult => {                                        
                this.arrOrder = objResult.data;
            });
        },
        
        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/GroundStartDrive', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$parent.refreshList();
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>

</style>
