<template>    
    <div class="hc_container-fluid" style="height:100%;">  
        <validation-observer ref="form" tag="div" class="row" style="padding: 10px;">
            <div class="col-60 form-item" style="padding: 0px; min-height: auto; border-bottom: none;">
                <div class="form-item-hd">运价</div>
                <validation-provider tag="div" name="运价" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }">
                    <hc-number type="text" v-model="objPost.UnitPrice" class="hc_text-mini" placeholder="请输入"></hc-number>
                    <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                </validation-provider>
            </div>
            <div class="col-240 form-item" style="padding: 0px; min-height: auto; border-bottom: none; margin-top: 5px;">
                <div class="form-item-hd">航司其他费用</div>
                <div class="form-item-bd">
                    <div v-for="(objItem,i) in arrACOtherChargePost" style="display: inline-block; margin-right: 10px; margin-bottom: 4px;">
                        <input type="text" class="hc_text-mini" v-model="objItem.Name" placeholder="费用名称" style="width: 50px;" /> :
                        <validation-provider tag="div" :name="'费用'+i" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }" style="display: inline-block;">                                
                            <input type="text" class="hc_text-mini" v-model="objItem.Value" placeholder="费用" style="width: 70px;" />
                            <!-- <hc-number v-model="objItem.Value" class="hc_text-mini" placeholder="费用" style="width: 70px;"></hc-number> -->
                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                        </validation-provider>
                        <span class="hc_button-text" @click="objItem.Value=(parseFloat(objItem.Value)*objData.Weight).toFixed(2)">乘货重</span>&nbsp;&nbsp;<span class="hc_button-text" @click="removeItem(i);">删除</span>&nbsp;&nbsp;
                    </div>
                    <span class="hc_button hc_button-primary hc_button-small" @click="addItem();">增加</span>
                </div>
            </div>
            <div class="col-240" style="text-align: center; margin-top: 5px;">
                <span class="hc_button hc_button-small" @click="save();">提交更新费用</span>
            </div>
        </validation-observer>

        <div class="row" style="padding: 10px;">
            <div class="col-240" style="margin-bottom: 10px; margin-top: 10px;">
                <select @change="changeItem($event.target.value)" class="hc_select hc_form-small" style="width: 105px;">
                    <option :value='0'>主单</option>
                    <option v-for="(objItem,i) in arrOutOrderItem" :value='objItem.Id'>分单{{i+1}}</option>
                </select>                     
                <div style="display: inline-block;">
                    <span>分单是否录尺寸：{{$lib.Store.getValFromDic('Is',objData.IsEnterSize)}}</span>
                    <span style="margin-left: 10px;">计费自填：{{$lib.Store.getValFromDic('Is',objData.IsSelfCharge)}}</span>
                    <span style="margin-left: 10px;">公务货：{{$lib.Store.getValFromDic('Is',objData.IsOfficeGoods)}}</span>
                </div>
                <div v-if="objChooseItem!=null" style="display: inline-block; margin-left: 10px;">
                    <span>录预配运抵：{{$lib.Store.getValFromDic('Is',objChooseItem.IsInputPreplan)}}</span>
                    <span style="margin-left: 10px;">提单打印：{{$lib.Store.getValFromDic('OutOrderItem_BLPrint',objChooseItem.BLPrint)}}</span>
                    <span style="margin-left: 10px;">虚拟分单：{{$lib.Store.getValFromDic('Is',objChooseItem.IsVirtually)}}</span>
                </div>
            </div>
        </div>
        
        <div class="row" style="overflow:auto; padding: 10px; width: 840px;">
            

            <div :class="'col-240 ' + ((objChooseItem==null || objChooseItem.BLPrint==1)?'master-print':'')" id="divPrint" style="width: 842px; padding: 36px 30px 0px 45px;">
            <!-- <div class="col-240" id="divPrint" style="width: 800px;"> -->
                <!-- <div>NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.83); width: 120%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 10px; background: red;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.75); width: 133%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 6px;-webkit-text-size-adjust:none;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.66); width: 150%; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 6px;-webkit-text-size-adjust:none;">NOT</div>
                
                <div style="font-size: 12px; -webkit-transform: scale(0.83); display: inline-block; transform-origin: 0 0; background: green;">NOT</div>
                <div style="font-size: 10px; background: red;">NOT</div>
                <div style="font-size: 12px; -webkit-transform: scale(0.66); display: inline-block; transform-origin: 0 0; background: green;">NOT</div> -->
                
                <div class="hc_container-fluid">
                    <div class="row" style="height:65px;">&nbsp;</div>
                    <div class="row print-height print-lineHeight">
                        <div class="col-14" style="text-align: center; font-weight: bold; font-size: 16px;"><span>{{objData.PrimaryCode}}</span></div>
                        <div class="col-12 bd-left" style="text-align: center; font-weight: bold; font-size: 16px;"><span>CSX</span></div>
                        <div class="col-38 bd-left" style="text-align: center; font-weight: bold; font-size: 16px;"><span>{{objData.Number}}</span></div>                        
                        <div class="col-120"></div>
                        <div v-if="objChooseItem==null" class="col-56" style="text-align: center; font-weight: bold; font-size: 16px;">{{objData.PrimaryCode}}<span style="margin-left: 20px;">{{objData.Number}}</span></div>
                        <div v-else class="col-56" style="text-align: center; font-weight: bold; font-size: 16px;">{{objChooseItem.Number}}</div>
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 95px; position: relative;">
                            <div class="row print-height">
                                <div class="col-120"><span class="font-10px">Shipper's Name and Address</span></div>
                                <div class="col-120 bd-left bd-bottom" style=""><span class="font-10px">Exporter's Account Number</span></div>
                            </div>
                            <div class="font-11px" style="position: absolute; top: 12px; line-height: 1.2; font-size: 12px; white-space:normal; word-wrap: break-word;">                                
                                <div v-html="(objChooseItem==null?objData.FromAddress:objChooseItem.FromAddress).replace(/\n/g,'<br />')"></div>
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 95px;">
                            <div>
                                <div class="font-10px">Not Negotiation</div>
                                <div class="font-16px" style="padding: 0px 5px; line-height: 1;">Air Waybill</div>
                                <div class="font-10px">Issued by</div>
                            </div>
                            <div style="font-weight: bold; text-align: center;">
                                {{objAirLine.FullName}}
                            </div>
                            <div class="font-10px bd-top" style="position: absolute; bottom: 0px;">Copise 1,2and 3 of this Air Waybill are originals and have the same validity</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 95px; position: relative;">
                            <div class="row print-height">
                                <div class="col-120"><span class="font-10px">Consignee's Name and Address</span></div>
                                <div class="col-120 bd-left bd-bottom"><span class="font-10px">Consignee's Account Number</span></div>
                            </div>
                            <div class="font-11px" style="position: absolute; top: 12px; line-height: 1.2; font-size: 12px; white-space:normal; word-wrap: break-word;">
                                <div v-html="(objChooseItem==null?objData.ToAddress:objChooseItem.ToAddress).replace(/\n/g,'<br />')"></div>                                
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 95px;">
                            <div class="font-10px" style="line-height: 1.2;">
                                It is agreed that the goods described herein are accepted in apperent good order and condition (except as noted)for carriage SUBJECT TO THE CONDITIONS AND OF CONTRACT ON THE REVERSE  HEREOF,THE SHIPPER'S ATTENTION IS DRAWN ON THE TO THE NOTICE CONCERNING CARRIERS LIMITATION  OF LIABILITY IN RESPECT OF DELAY, LOSS OF OR DAMAGE TO GOODS.Shipper may increase such limation of liability by declaring a higher value for carriage and paying a suppiemental charge if required.
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-120 bd-bottom" style="height: 95px;">
                            <div class="font-10px">Issuing Carrier's Agent Name and City</div>
                            <div style="text-align: center; margin-top: 10px;">{{objData.AgentName}}/CSX</div>

                            <div class="row print-height" style="position: absolute; bottom: 0px; width: 100%;">
                                <div class="col-120 bd-top"><span class="font-10px">Agent's IATA Code</span></div>
                                <div class="col-120 bd-top bd-left"><span class="font-10px">Account No.</span></div>
                            </div>
                        </div>
                        <div class="col-120 bd-left bd-bottom" style="height: 95px;">
                            <div class="font-10px">Accounting Information</div>
                            <div style="text-align: center; margin-top: 10px;">{{objData.ACAccountInfor}}</div>
                        </div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-120">
                            <div class="font-10px">Airport of Departure</div>
                            <div style="padding-left: 5px;">CSX</div>
                        </div>
                        <div class="col-50 bd-left"><div class="font-10px" style="text-align: center;">Reference Number</div></div>
                        <div class="col-40 bd-left"><div class="font-10px" style="text-align: center;">Optional Shipping Information</div></div>
                        <div class="col-30 bd-left"></div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-12">
                            <div class="font-10px">To</div>
                            <div class="print-content">{{objData.ToCityCode}}</div>
                        </div>
                        <div class="col-60 bd-left">
                            <div class="font-10px">By First Carrier</div>
                            <div class="print-content" style="text-align: center;">{{objAirLine.Code}}</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">to</div>
                            <div class="print-content">{{objData.ChangeToCityCode}}</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">by</div>
                            <div class="print-content">{{objData.ChangeACCode}}</div>
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">to</div>                            
                        </div>
                        <div class="col-12 bd-left">
                            <div class="font-10px">by</div>                            
                        </div>


                        <div class="col-14 bd-left">
                            <div class="font-10px" style="padding-left: 2px;">Currency</div>
                            <div class="print-content" style="text-align: center;">{{$lib.Store.getValFromDic('Currency',objData.Currency)}}</div>
                        </div>
                        <div class="col-8 bd-left">
                            <div class="font-8px">CHGS Code</div>                            
                        </div>
                        <div class="col-14 bd-left">
                            <div class="font-10px" style="text-align: center; padding-top: 2px;">WT/VAL</div>
                            <div class="row bd-top" style="height: calc(100% - 14px);">
                                <div class="col-120">
                                    <div class="font-8px">PPD</div>
                                    <div style="margin-top: -7px; text-align: center; font-size: 12px;">{{objData.WeightChargePayMethod==1?"PP":""}}</div>
                                </div>
                                <div class="col-120 bd-left">
                                    <div class="font-8px">COLL</div>
                                    <div class="print-content">{{objData.WeightChargePayMethod==2?"CC":""}}</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-14 bd-left">
                            <div class="font-10px" style="text-align: center; padding-top: 2px;">Other</div>
                            <div class="row bd-top" style="height: calc(100% - 14px);">
                                <div class="col-120">
                                    <div class="font-8px">PPD</div>
                                    <div style="margin-top: -7px; text-align: center; font-size: 12px;">{{objData.OtherChargePayMethod==1?"PP":""}}</div>
                                </div>
                                <div class="col-120 bd-left">
                                    <div class="font-8px">COLL</div>
                                    <div class="print-content">{{objData.OtherChargePayMethod==2?"CC":""}}</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-40 bd-left">
                            <div class="font-8px">Declared Value for Carriage</div>
                            <div style="text-align: center;">N.V.D</div>
                        </div>
                        <div class="col-30 bd-left">
                            <div class="font-9px">Declared Comtoms</div>
                            <div style="text-align: center; font-size: 12px;">{{$lib.Store.getValFromDic('OutOrder_DeclareValue',objData.DeclaredValue)}}</div>
                        </div>
                    </div>

                    <div class="row print-height bd-bottom">
                        <div class="col-60">
                            <div class="font-10px">Airport of Destination</div>
                            <div style="text-align: center;">{{objData.ToCityName}}</div>
                        </div>
                        <div class="col-60 bd-left">
                            <div style="text-align: center;">
                                <div class="bd-all" style="display: inline-block; border-top: none;">
                                    <span class="font-10px2" style="margin-left: 15px;">Flight/Date</span>
                                </div>                                
                            </div>
                            <div class="row" style="height: calc(100% - 14px);">
                                <div class="col-120" style="text-align: center; padding-top: 0px;">{{objData.FlightNumber}}</div>
                                <div class="col-120 bd-left" style="text-align: center; padding-top: 0px;">{{objData.FlightDate}}</div>
                            </div>
                        </div>

                        <div class="col-36 bd-left">
                            <div class="font-9px">Amount of insurance</div>
                            <div style="text-align: center;">NIL</div>
                        </div>
                        <div class="col-79 bd-left">
                            <div class="font-8px" style="padding: 2px 5px 0px 5px; position: absolute;">INSURANCE:If Carrier offers insurance,and such insurance is requested in accordance with the conditions thereof,indicate amount to be insured in figures in box marked Amount of insurance.</div>                            
                        </div>
                        <div class="col-5 bd-left">
                            <div class="font-10px" style="padding-left: 2px;">TC</div>
                        </div>
                    </div>

                    <div class="row" style="height: 63px;">
                        <div class="col-210">
                            <div class="font-10px">Handling Information</div>
                            <div style="padding: 5px; margin-top: -5px; line-height: 1.2; white-space: pre-wrap; word-wrap: break-word;">                                
                                <div v-html="objData.CustomerRemark.replace(/\n/g,'<br />')"></div>
                            </div>
                        </div>
                        <div class="col-30">
                            <div style="height: 30px;"></div>
                            <div class="bd-left bd-top" style="height: 30px;">
                                <div class="font-10px" style="text-align: center;">SCI</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row print-height" style="height: 38px !important;">
                        <div class="col-12 bd-bottom">
                            <div class="font-10px" style="text-align: center; position: absolute; width: 130%;">No. of Pieces RCP</div>
                        </div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Gross<br />Weight</div>
                        </div>
                        <div class="col-4 bd-left bd-bottom">
                            <div class="font-9px" style="padding-top: 5px;">kg<br /><br />lb</div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20">
                            <div class="font-10px" style="position: absolute; left: -10px; width: 130%; padding: 1px;">Rate Class</div>
                            <div class="bd-left bd-top bd-bottom" style="position: absolute; bottom: 0px; height: 22px;">
                                <div class="font-10px" style="text-align: center; padding: 0px;">Commodity Item No.</div>
                            </div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Chargeable Weight</div>
                        </div>
                    
                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Rage/Charge</div>
                        </div>


                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Total</div>
                        </div>

                        <div class="col-4 bd-left bd-top" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left bd-bottom">
                            <div class="font-10px" style="text-align: center;">Nature and Quantity Goods<br />(incl.Dimensions or Volume)</div>
                        </div>
                    </div>
                    <div class="row" style="height: 195px; position: relative;">
                        <div style="position: absolute; left: 5px; top:40px; width: 45%; z-index: 50; line-height: 1.2; white-space: pre-wrap; word-wrap: break-word;">                            
                            <div v-html="objData.CustomerNotify.replace(/\n/g,'<br />')"></div>
                        </div>
                        <div class="col-12 bd-bottom"><div style="text-align: center; margin-top: 10px;">{{objChooseItem==null?objData.Piece:objChooseItem.Piece}}</div></div>
                        <div class="col-24 bd-left bd-bottom"><div style="text-align: center; margin-top: 10px;">{{objChooseItem==null?objData.Weight:objChooseItem.Weight}}</div></div>
                        <div class="col-4 bd-left"><div style="text-align: center; margin-top: 10px; position: absolute; z-index: 1;">KQ</div></div>
                        
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20 bd-left"></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;">{{objChooseItem==null?objData.ChargeWeight:objChooseItem.ChargeWeight}}</div></div>
                    
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;" v-show="objData.IsOfficeGoods==0">{{objChooseItem==null?objData.UnitPrice:""}}</div></div>


                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-bottom"><div style="text-align: center; margin-top: 10px;" v-show="objData.IsOfficeGoods==0">{{objChooseItem==null?objData.WeightCharge:"AS AGREED"}}</div></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left" style="padding: 10px 5px 0px 5px; font-size: 12px;">
                            <div>{{objChooseItem==null?objData.GoodsName:objChooseItem.GoodsName}}</div>
                            <div style="margin-top: 3px;">DIMS：</div>
                            <div style="position: absolute;">
                                <div v-if="objChooseItem==null" style="margin-top: 3px;">
                                    <span v-for="objItem in arrOutOrderSize" style="margin-bottom: 2px; display: inline-block; width: 49%;">{{objItem.Long+"*"+objItem.Width+"*"+objItem.Height+"/"+objItem.Piece}};</span>
                                    <!-- <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span>
                                    <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148;</span> <span style="margin-bottom: 5px; display: inline-block;">41*35*29 148</span> -->
                                </div>
                                <div v-else>
                                    <span v-for="objItem in objChooseItem.arrOutOrderSize" style="margin-bottom: 5px; display: inline-block; width: 49%;">{{objItem.Long+"*"+objItem.Width+"*"+objItem.Height+"/"+objItem.Piece}};</span>
                                </div>
                                <div>{{objChooseItem==null?$store.state.BasePackage.objMapping[objData.BP_Id].NameEn:""}}</div>
                                <div style="margin-top: 3px;">VOL：{{objChooseItem==null?objData.Volume:objChooseItem.Volume}}CBM</div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="row print-height">
                        <div class="col-12"><div style="text-align: center; margin-top: 10px;">{{objChooseItem==null?objData.Piece:""}}</div></div>
                        <div class="col-24 bd-left"><div style="text-align: center; margin-top: 10px;">{{objChooseItem==null?objData.Weight:""}}</div></div>
                        <div class="col-4 bd-left"></div>
                        
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>                                                
                        <div class="col-4 bd-left"></div>
                        <div class="col-20 bd-left"></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"></div>
                    
                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-24 bd-left"></div>


                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left"><div style="text-align: center; margin-top: 10px;" v-show="objData.IsOfficeGoods==0">{{objChooseItem==null?objData.WeightCharge:"AS AGREED"}}</div></div>

                        <div class="col-4 bd-left" style="background-color: #f56c6c;"></div>
                        <div class="col-62 bd-left">                            
                        </div>
                    </div>
                </div>

                <div class="hc_container-fluid bd-left bd-top bd-right">
                    <div class="row print-height bd-bottom">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 20px; z-index: 10;">
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;">Prepaid</div>
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;">Weight Charge</div>
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;">Collect</div>
                            </div>
                            
                            <div class="row print-height">
                                <div class="col-120" style="text-align: center; padding-top: 16px;" v-show="objData.IsOfficeGoods==0">{{objChooseItem==null?objData.WeightCharge:"AS AGREED"}}</div>
                                <div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left">
                            <div class="font-10px">Other Charges</div>
                            <div v-show="objData.IsOfficeGoods==0" style="position: absolute; z-index: 10; left: 5px; line-height: 1.2;">
                                <template v-if="objChooseItem==null">
                                    <div v-for="objItem in arrACOtherCharge">{{objItem.Name}}：{{objItem.Value}}</div>
                                </template>
                                <template v-else>AS AGREED</template>                                
                            </div>                           
                        </div>
                    </div>
                    <div class="row print-height bd-bottom">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 27px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;">Valuation Charge</div>                                
                            </div>                            
                            <div class="row print-height">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left"></div>
                    </div>
                    <div class="row print-height">
                        <div class="col-92 bd-left bd-bottom" style="background-color: #f56c6c;">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 7px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #f56c6c;">Tax</div>                                
                            </div>                            
                            <div class="row print-height">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left bd-bottom"></div>
                    </div>

                    <div class="row print-height">
                        <div class="col-92">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 32px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; background-color: #fff;" v-show="objData.IsOfficeGoods==0">Total Other Charges Due Agent</div>                                
                            </div>              
                            <div class="row print-height bd-bottom">
                                <div class="col-120" style="text-align: center; padding-top: 16px;" v-show="objData.IsOfficeGoods==0">{{objChooseItem==null?objData.OtherCharge:"AS AGREED"}}</div>
                                <div class="col-120 bd-left"></div>
                            </div>
                        </div>
                        <div class="col-148 bd-left">
                            <div class="font-10px" style="position: absolute; line-height: 1.1;">
                                Shipper certifies that the particulars on the face hereof are correct and that insofar as any part of the consignment contains restricted articles,such part is properly described by name and is in proper condition for carriage by air acording to the International Air Transport Association's Restricted Articles Regulations.
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-92 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 32px; z-index: 10;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px;background-color: #fff;">Total Other Charges Due Carrier</div>                                
                            </div>
                            <div class="row print-height">
                                <div class="col-120"></div><div class="col-120 bd-left"></div>
                            </div>
                            
                        </div>
                        <div class="col-148 bd-left" style="text-align: center; padding: 20px 10px 0px 10px;">
                            {{objData.AgentFullName}}
                        </div>
                    </div>

                    <div class="row print-height bd-left">
                        <div class="col-46 bd-top bd-bottom" style="background-color: #f56c6c;"></div>
                        <div class="col-46 bd-left bd-top bd-bottom" style="background-color: #f56c6c;"></div>
                        <div class="col-148 bd-left bd-bottom">
                            <div class="font-10px" style="position: absolute; bottom: 0px; text-align: center;">Signature of Shipper or his Agent</div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 17px;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Prepaid</div>                                
                            </div>
                            <div style="text-align: center; padding-top: 16px;">{{objChooseItem==null?objData.TotalCharge:"AS AGREED"}}</div>
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 100%; padding-left: 17px;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Collect</div>                                
                            </div>                            
                        </div>
                        <div class="col-148 bd-left">              
                            <div class="row" style="padding-top: 13px;">
                                <div class="col-120" style="text-align: center;">{{$dayjs().format("YYYY/MM/DD")}}</div>
                                <div class="col-120" style="text-align: center;">{{objChooseItem==null?(objData.PrimaryCode+" "+objData.Number):objChooseItem.Number}}</div>
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">
                            <div style="position: absolute; text-align: center; width: 119%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 5px; border-top: none;">Currency Conversion Rates</div>                                
                            </div>                            
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 120%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 5px; border-top: none;">CC Charges in Dest.Currency</div>                                
                            </div>
                        </div>
                        <div class="col-148 bd-left bd-bottom">              
                            <div class="bd-top" style="position: absolute; bottom: 0px; width: 100%; border-top-style: dashed;">
                                <div class="font-10px">Executed on <span style="margin-left: 60px;">(Date)</span> <span style="margin-left: 60px;">at</span> <span style="margin-left: 60px;">(Place)</span></div>
                            </div>
                        </div>
                    </div>

                    <div class="row print-height">
                        <div class="col-46 bd-bottom">                            
                            <div class="font-10px" style="text-align: center;">For Carriers Use Only Of at Destination</div>
                        </div>
                        <div class="col-46 bd-left bd-bottom">
                            <div style="position: absolute; text-align: center; width: 117%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Charges at Destination</div>
                            </div>
                        </div>
                        <div class="col-46 bd-left bd-bottom bd-right">
                            <div style="position: absolute; text-align: center; width: 117%;">                                
                                <div class="font-10px2 bd-all" style="padding: 2px 10px; border-top: none;">Total Collect Charges</div>                                
                            </div>                            
                        </div>
                    </div>
                </div>
                               
            </div>
        </div>

        <div style="height: 45px;">&nbsp;</div>
        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center; position: absolute; bottom: 0px; width: 100%; z-index: 100000;">            
            <el-button size="small" type="success" icon="el-icon-printer" onclick="printJS({printable:'divPrint',type:'html',css:'/static/script/hcui.css'})">打 印</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>
</template>

<script>

export default {
    data: function() {
        return{
            objChooseItem: null,    // 选择的分单

            arrOutOrderSize:[], // 主单尺寸
            arrOutOrderItem:[], // 分单
            objAirLine: null,
            objData:{
                Id: this.Id,
            },
            arrACOtherCharge:[],

            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            }, 
            arrACOtherChargePost:[],
            objPost:{
                Id: this.Id,
                ACOtherCharge: "",
                UnitPrice: null,
                WeightCharge: null,
                OtherCharge: null,
                TotalCharge: null,
            },
        }
    },
    props:{    
        Id:{
            type: Number,
            default: null
        },        
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {        
    },
    watch: {
    },
    created: function() {       
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        addItem: function(){
            this.arrACOtherChargePost.push({Name:"", Value:null});
        },
        removeItem: function(nIndex){
            this.arrACOtherChargePost.splice(nIndex,1);
        },
        save: function () {
            if(this.ctrForm.blnSubmit == true){
                return;
            }         
            this.ctrForm.blnSubmit = true;        

            this.objPost.ACOtherCharge = JSON.stringify(this.arrACOtherChargePost);
            
            this.objPost.WeightCharge = parseFloat((this.objData.ChargeWeight * this.objPost.UnitPrice).toFixed(2));
            var fTotalOtherCharge = 0;
            for(var i = 0; i < this.arrACOtherChargePost.length; i++){
                fTotalOtherCharge += parseFloat(this.arrACOtherChargePost[i].Value);
            }
            this.objPost.OtherCharge = parseFloat(fTotalOtherCharge.toFixed(2));
            this.objPost.TotalCharge = parseFloat((this.objPost.WeightCharge + this.objPost.OtherCharge).toFixed(2));            
            console.log(this.objPost);

            this.$refs.form.validate().then(blnValid => {
                this.ctrForm.blnSubmit = false;
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
                                                                        
                this.$ajax.post('/Admin/OutOrder/UpdateData?FromPage=1', this.objPost).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                    
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                     
                        return;
                    }

                    this.objData.UnitPrice = this.objPost.UnitPrice;
                    this.objData.WeightCharge = this.objPost.WeightCharge;
                    this.objData.OtherCharge = this.objPost.OtherCharge;
                    this.objData.TotalCharge = this.objPost.TotalCharge;
                    this.arrACOtherCharge = JSON.parse(this.objPost.ACOtherCharge);

                    this.$alert(objResult.message, '系统提示').then(() => {                             
                    });                        
                });
                               
            });
        },

        changeItem: function(nId){
            if(nId==0){
                this.objChooseItem = null;
            }
            else{
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    if(this.arrOutOrderItem[i].Id == nId){
                        this.objChooseItem = this.arrOutOrderItem[i];
                        break;
                    }
                }
            }
        },
        initPage:function(){            
            this.$ajax.get('/Admin/OutOrder/GetDetail?Id=' + this.objData.Id, null,{async:false}).done(objResult=> {                
                objResult.data[0].FlightDate = this.$lib.Format.fmtDate(objResult.data[0].FlightDate);
                this.objData = objResult.data[0];                
                this.arrACOtherCharge = JSON.parse(objResult.data[0]["ACOtherCharge"]);
                this.objAirLine = this.$store.state.AirLine.objMapping[this.objData.AL_Id];

                for (var strKey in this.objPost) {
                    switch (strKey) {
                        case "ACOtherCharge":
                            this.arrACOtherChargePost = JSON.parse(objResult.data[0][strKey]);
                            this.objPost[strKey] = objResult.data[0][strKey];
                            break;                            
                        default:
                            this.objPost[strKey] = objResult.data[0][strKey];
                            break;
                    }
                }


                if(this.objData.DirectOrder==1 || this.objData.IsEnterSize==0){
                    for(var i = 0; i < objResult.extData.arrOutOrderSize.length; i++){
                        this.arrOutOrderSize.push(objResult.extData.arrOutOrderSize[i]);
                    }
                }

                if(this.objData.DirectOrder==2){
                    var nIndex;
                    for(var i = 0; i < objResult.extData.arrOutOrderItem.length; i++){
                        this.arrOutOrderItem.push(objResult.extData.arrOutOrderItem[i]);

                        nIndex = this.arrOutOrderItem.length - 1;
                        this.arrOutOrderItem[nIndex].strSizeFormat = "";
                        this.arrOutOrderItem[nIndex].arrOutOrderSize = [];  
                        if(this.objData.IsEnterSize==1){                                                                                          
                            for(var j = 0; j < objResult.extData.arrOutOrderSize.length; j++){                                    
                                if(objResult.extData.arrOutOrderItem[i].Id == objResult.extData.arrOutOrderSize[j].OOI_Id){                                                                                
                                    this.arrOutOrderItem[nIndex].arrOutOrderSize.push(objResult.extData.arrOutOrderSize[j]);
                                }
                            }
                        }
                    }

                    if(this.objData.IsEnterSize==1){
                        var blnHas = false;

                        this.arrOutOrderSize = [];
                        for(var i = 0; i < this.arrOutOrderItem.length; i++){                        
                            for(var j = 0; j < this.arrOutOrderItem[i].arrOutOrderSize.length; j++){
                                blnHas = false;
                                if(this.arrOutOrderItem[i].arrOutOrderSize[j].Piece == null){                                
                                    continue;
                                }
                                for(var m = 0; m < this.arrOutOrderSize.length; m++){
                                    if(this.arrOutOrderItem[i].arrOutOrderSize[j].Long == this.arrOutOrderSize[m].Long && this.arrOutOrderItem[i].arrOutOrderSize[j].Width == this.arrOutOrderSize[m].Width && this.arrOutOrderItem[i].arrOutOrderSize[j].Height == this.arrOutOrderSize[m].Height){
                                        this.arrOutOrderSize[m].Piece += this.arrOutOrderItem[i].arrOutOrderSize[j].Piece;
                                        blnHas = true;
                                    }
                                }
                                if(blnHas == false){
                                    this.arrOutOrderSize.push(JSON.parse(JSON.stringify(this.arrOutOrderItem[i].arrOutOrderSize[j])));
                                    this.arrOutOrderSize[this.arrOutOrderSize.length-1].Id = null;
                                }
                            }
                        }
                    }
                }
            });
        }
    }
}

</script>

<style scoped>

</style>
