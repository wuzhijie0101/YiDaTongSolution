<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid hc_form-pc" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row">
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>航线名称</div>
                    <validation-provider tag="div" name="航线名称" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <input class="hc_text" v-model="objData.Name" placeholder="请输入" autocomplete="off" style="width: 200px;" />     
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">概述</div>
                    <div class="form-item-bd">
                        <textarea v-model="objData.Summary" class="hc_textarea" rows="5"></textarea>
                    </div>
                    <div class="form-item-ft"></div>
                </div> 
                <div class="col-240 form-item">
                    <div class="form-item-hd">内容</div>
                    <div class="form-item-bd">
                        <vue-ueditor-wrap v-model="objData.Content" :destroy="true" :config="objConfig"></vue-ueditor-wrap>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">
                        <el-popover placement="bottom-start" trigger="hover" width="400" content="按降序排序，值越大越排在前面">
                            <span slot="reference"><span class="form-required">*</span><i class="el-icon-question"></i>排序</span>                            
                        </el-popover>   
                    </div>
                    <validation-provider tag="div" name="排序" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-input-number v-model="objData.Sort" :min="1" name="排序"></el-input-number>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">备注</div>
                    <div class="form-item-bd">
                        <input class="hc_text" v-model="objData.Remark" placeholder="请输入" autocomplete="off" style="width: 80%;" />                        
                    </div>
                    <div class="form-item-ft"></div>
                </div>                

                
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{           
            objConfig:{
                toolbars: [this.$lib.Plugin.UEditor.arrSimple],
                enableAutoSave: false,                
                serverUrl: this.$lib.Config.Url_ApiUpload + '/Open/FileUpload/UEditorRequest',
                UEDITOR_HOME_URL: this.$lib.Plugin.UEditor.objConfig.UEDITOR_HOME_URL
            },

            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            objData: {                                
                Id: this.Id,
                Name: "",
                Summary: "",
                Content: "",
                Sort: null,
                Remark: ""                
            }   
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {              
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){       
            if(this.objData.Id == null){
                this.startWatch(); 
            }
            else{
                this.$ajax.get('/Admin/AirLine/GetById?Id=' + this.objData.Id).done(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }

                    for (var strKey in this.objData) {
                        switch (strKey) {                            
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }
                    
                    this.startWatch(); 
                });
            }                             
        },
        save: function () {
            if(this.objData.Id==null){
                // this.$lib.CURD.insert(this, "/Admin/Page/Insert");
            }
            else{
                this.$lib.CURD.update(this, "/Admin/AirLine/Update");
            }     
        },
    }
}
</script>

<style scoped>    
</style>
