<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="display: flex; background: #fff; align-items: center; padding: 10px; border-bottom: 1px solid #ddd;">
            <div>
                <select @change="loadFlight($event.target.value)" class="hc_select hc_form-small" style="width: 105px;">
                    <option v-for="strItem in arrDate" :value='strItem'>{{strItem}}</option>                    
                </select>
            </div>
            <div style="text-align: right; flex-grow: 1;">
                
                
                <!-- <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardImportData(2, null, null);">CBA数据导入</span> -->
            </div>
        </div>
        <div class="scrollbar1 chd_dis-flight" style="border-bottom: 1px solid #ddd;">            
            <span v-for="objItem in arrFlight" :class="objFlight.Id==objItem.Id?'on':''" @click="objFlight=objItem;" style="cursor: pointer;">{{objItem.Number}}</span>            
        </div>
        <div class="scrollbar1 chd_dis-flight" style="border-bottom: 1px solid #ddd;">            
            <!-- <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="updateToPlay();">一键到正装</span> -->
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardProcessData(objFlight.AL_Id, objFlight.Id);">删除CBA导入数据</span>
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardImportData(2, objFlight.AL_Id, objFlight.Id);">CBA数据导入</span>

            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openOutOrderInsertForZB();">新增CBA货运单</span>
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardImportData(3,objFlight.AL_Id,objFlight.Id);">舱单数据导入</span> 
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardPrintMakeBoard();">国际货物组板清单</span>
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardCheckData();">核对数据</span>
            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="openBoardImportDataULD(objFlight.AL_Id,objFlight.Id);">核对数据导入</span>

            <span v-show="$store.state.TabMenu.objMapping[195].HasPower" class="hc_button-text" @click="exportFreightInfor();">导出装载信息表</span>
        </div>

        <div style="height: 20px;"></div>
    </div>
</template>

<script>
import BoardImportData from '@/views/Board/ImportData.vue';
import BoardImportDataULD from '@/views/Board/ImportDataULD.vue';
import BoardPrintMakeBoard from '@/views/Board/PrintMakeBoard.vue';
import BoardProcessData from '@/views/Board/ProcessData.vue';
import BoardCheckData from '@/views/Board/CheckData.vue';
import OutOrderInsertForZB from '@/views/OutOrder/InsertForZB.vue';

export default {
    data: function() {
        return{
            PM_Id: 100,

            arrDate:[],         // 航班日期列表
            arrFlight:[],       // 当前航班日期下的所有航班
            arrAllFlight:[],    // 一个月内所有未结束的航班   
            objFlight: null,    // 当前选中的航班          
        }
    },
    props:{        
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        var objWhere = {
            "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            "Date": { "strField": "Date", "strCondition": "<=", "strValue": this.$dayjs().add(1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
        }
        this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc,AL_Id asc" }).then(objResult => {
            for(var i = 0; i < objResult.data.length; i++){
                objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
            }
            this.arrAllFlight = objResult.data;

            var strDate = ",";
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(strDate.indexOf(','+this.arrAllFlight[i].Date+',') == -1){
                    this.arrDate.push(this.arrAllFlight[i].Date);
                    strDate += this.arrAllFlight[i].Date + ",";
                }
            }

            if(this.arrAllFlight.length>1){
                this.loadFlight(this.arrAllFlight[0].Date);
            }
        });

        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                        
        },

        loadFlight: function(strDate){                    
            this.arrFlight = [];
            for(var i = 0; i < this.arrAllFlight.length; i++){
                if(this.arrAllFlight[i].Date == strDate){
                    this.arrFlight.push(this.arrAllFlight[i]);
                }
            }
            this.objFlight = this.arrFlight[0];
        },
        updateToPlay: function(){
            this.$confirm("确定全部到正装吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/OutOrder/BoardUpdateToPlay?F_Id=" + this.objFlight.Id).then(objResult=> {                      
                    if(objResult.success == false){                        
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                      
                        return;
                    }

                    this.$message({message: '提交成功',type: 'success'});
                });
            }).catch(function () {
            });
        },

        exportFreightInfor:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportFreightInfor?token="+localStorage.getItem("strToken")+"&AL_Id=" + this.objFlight.AL_Id+"&Number="+this.objFlight.Number+"&Date="+this.objFlight.Date+"&ToCityCode="+this.$store.state.AirLine.objMapping[this.objFlight.AL_Id].ToCityCode;        
        },

        openBoardImportData:function(nDataFrom, nAL_Id, nF_Id){     
            this.$layer.iframe({
                content: {
                    content: BoardImportData,
                    parent: this,
                    data:{ DataFrom: nDataFrom, AL_Id: nAL_Id, F_Id:nF_Id } 
                },
                area:['500px','400px'],
                shadeClose: false,
                title: "数据导入"
            });            
        },   
        openBoardImportDataULD:function(nAL_Id, nF_Id){     
            this.$layer.iframe({
                content: {
                    content: BoardImportDataULD,
                    parent: this,
                    data:{ AL_Id: nAL_Id, F_Id:nF_Id } 
                },
                area:['500px','400px'],
                shadeClose: false,
                title: "核对数据导入"
            });            
        },   
        openBoardProcessData:function(nAL_Id, nF_Id){     
            this.$layer.iframe({
                content: {
                    content: BoardProcessData,
                    parent: this,
                    data:{ AL_Id: nAL_Id, F_Id:nF_Id } 
                },
                area:['500px','400px'],
                shadeClose: false,
                title: "删除CBA导入数据"
            });            
        },
        openBoardCheckData:function(){     
            this.$layer.iframe({
                content: {
                    content: BoardCheckData,
                    parent: this,
                    data:{ AL_Id:this.objFlight.AL_Id } 
                },
                area:['800px','90%'],
                shadeClose: false,
                title: '核对数据'
            });
        },

        openBoardPrintMakeBoard:function(){     
            this.$layer.iframe({
                content: {
                    content: BoardPrintMakeBoard,
                    parent: this,
                    data:{ AL_Id:this.objFlight.AL_Id, F_Id:this.objFlight.Id } 
                },
                area:['862px','80%'],
                // area:['900px','80%'],
                shadeClose: false,
                title: '国际货物组板清单'
            });
        },
        openOutOrderInsertForZB:function(){     
            this.$layer.iframe({
                content: {
                    content: OutOrderInsertForZB,
                    parent: this,
                    data:{ AL_Id:this.objFlight.AL_Id, F_Id:this.objFlight.Id } 
                },
                area:['800px','600px'],
                shadeClose: false,
                title: '新增CBA货运单'
            });
        },
    }
}

</script>

<style scoped>

</style>
