<template>
    <div style="overflow-y:scroll; width: 100%; background: #F5F5F5;">       
        <div class="hc_container-fluid"  style="position: sticky; top: 0px; z-index: 1;">
            <div class="row" style="padding: 5px; align-items: center;font-size: 1.4rem; background: #F5F5F5;">
                <div class="col-135">{{strTip}}</div>
                <div class="col-105">
                    <input type="tel" v-model="strBorderFilter" class="hc_text-mini" @click="$event.currentTarget.select();" placeholder="板号" style="background: #fff; width: 50px;" />
                    <input type="tel" v-model="strFilter" @click="$event.currentTarget.select();" class="hc_text-mini" placeholder="空运单号" style="background: #fff; width: 60px;" />
                    <span class="hc_button-text" @click="strBorderFilter='';strFilter='';" style="margin-left: 2px;">清除</span>
                </div>
                <!-- <div class="col-30"><span class="hc_button-text" @click="strFilter='';" style="margin-left: 5px;">清除</span></div> -->
                <!-- <div class="col-160" style="text-align: right;">板重:3795; 净重:69906.7; 毛重:73561</div> -->
            </div>
        </div>
        <div class="hc_container-fluid" style="font-size: 1.4rem;">
            
            <!-- <validation-observer ref="form" tag="div" slim></validation-observer> -->
            <!-- <validation-observer ref="form" tag="div"> -->
            <div v-for="objItem in arrMakeBoard" v-show="objItem.State==53 && objItem.BoardNumber.indexOf(strBorderFilter)>-1 && objItem.NumberShort.indexOf(strFilter)>-1" class="row" style="background-color: #fff; padding: 5px; margin-bottom: 10px;">
                <!-- <validation-observer ref="form2" tag="div"></validation-observer> -->
                <div class="col-240 row clr-text2" style="align-items: center; border-bottom: 1px solid #ddd; padding-bottom: 5px;">
                    <div style="width: 20px;">{{objItem.BoardType}}</div>
                    <div style="width: 85px; font-weight: bold;">{{objItem.BoardNumber}}</div>
                    <div style="width: 110px; text-align: right;">{{objItem.Piece}}/<span style="font-weight: bold;">{{objItem.Weight}}</span>(货重)</div>
                    <div><span style="color: red;">{{objItem.Tip}}</span></div>
                </div>
                <div v-for="objChild in objItem.arrItem" :class="'col-234 row ' + (objChild.NumberShort==strFilter?'on':'')" style="padding: 5px 0px 5px 0px; margin-left: 8px; align-items: center; border-bottom: 1px dashed #ddd;">
                    <div style="width: 35px; font-weight: bold;">{{objChild.NumberShort}}</div>
                    <!-- <div style="width: 60px; text-align: right;">{{objChild.Piece}}/{{objChild.OO_CurrentPiece}}</div> -->
                    <div style="width: 60px; text-align: right;"><hc-number v-model="objChild.Piece" class="def_text-mini" @focus="pieceFocus(objChild);" @change="pieceChange(objItem,objChild);" style="width: 28px;" placeholder="件数"></hc-number>/{{objChild.OO_CurrentPiece}}</div>
                    <div style="width: 90px; text-align: right;"><hc-number v-model="objChild.Weight" class="def_text-mini" @focus="weightFocus(objChild);" @change="weightChange(objItem,objChild);" style="width: 40px;" placeholder="重量"></hc-number>/{{objChild.OO_CurrentWeight}}</div>
                    <!-- <div v-if="objChild.OO_CurrentWeight>objChild.OldWeight" style="width: 90px; text-align: right;"><hc-number v-model="objChild.Weight" class="def_text-mini" @focus="weightFocus(objChild);" @change="weightChange(objItem,objChild);" style="width: 40px;" placeholder="重量"></hc-number>/{{objChild.OO_CurrentWeight}}</div>
                    <div v-else style="width: 90px; text-align: right;">{{objChild.Weight}}/{{objChild.OO_CurrentWeight}}</div> -->
                    <div style="width: 30px; text-align: right;" class="clr-text3">{{$lib.Store.getValFromDic('OutOrder_DataFrom',objChild.DataFrom)}}</div>
                    <!-- <div style="width: 30px; text-align: right;"><span v-show="objChild.OO_CurrentWeight>objChild.OldWeight" class="hc_button-text" @click="updateMBI(objChild)">保存</span></div> -->
                </div>
                <div class="col-240" style="margin-top: 5px; align-items: center;">                 
                    <hc-number v-model="objItem.OverallWeight" class="def_text-mini" @change="overallWeightChange(objItem);" style="width: 52px;" placeholder="过磅重"></hc-number>-{{objItem.ChassisWeight}}(底重)=<span style="font-weight: bold;">{{objItem.GrossWeight}}</span>(毛重)-{{objItem.BoardWeight}}-<hc-number v-model="objItem.ElseWeight" class="def_text-mini" @change="elseWeightChange(objItem);" style="width: 30px;" placeholder="其他"></hc-number>={{objItem.GrossGoodsWeight}}(过货重)
                    <!-- <span style="float: right;" class="hc_button-text" @click="showTogether(objItem)">{{IsTogether==true?"取关":"查关联"}}</span> -->
                </div>
                <div class="col-240 row" style="margin-top: 5px; align-items: center;">
                    <div class="col-140">
                        <hc-number v-if="objItem.Type==1" v-model="objItem.Height" class="def_text-mini" style="width: 30px;" placeholder="板高"></hc-number>
                        <!-- <hc-number v-model="objItem.Volume" class="def_text-mini" style="width: 40px;" placeholder="板方数"></hc-number> -->                        
                        <span v-show="objItem.Type==1" class="clr-text3">{{objItem.ChassisNumber}}(底编)</span> <span class="clr-text3">{{objItem.ToCityCode}}</span> <span class="clr-text3">{{$store.state.Employee.objMapping[objItem.E_Id].Name}}</span>
                    </div>
                    <div class="col-100" style="text-align: right;">
                        <span class="hc_button-text" @click="save(objItem);">保存</span> | <span class="hc_button-text" @click="updateState(objItem.Id,52)">打回组板</span> | <span class="hc_button-text" @click="updateState(objItem.Id,54)">已核对</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>

export default {
    data: function() {
        return{
            strTip: "",
            strFilter: "",          // 空运单号关键字
            strBorderFilter: "",    // 板关键字               
            arrMakeBoard: [],
            ctrForm:{
                blnSubmit:false
            }
        }
    },
    props:{   
        AL_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {        
    },
    watch: {
    },
    created: function() {       
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){
            this.loadMakeBoard();
        },

        loadMakeBoard: function(){                    
            this.$ajax.get('/Admin/MakeBoard/GetData', {FromPage:"CheckData", AL_Id: this.AL_Id }).then(objResult => {  
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].arrItem = [];
                    objResult.data[i].BoardNumber = objResult.data[i].BoardNumber.replace("PMC","").replace("AKE","");
                    objResult.data[i].NumberShort = ",";    // 用于关键字过滤

                    if(objResult.data[i].State==53){
                        objResult.data[i].Piece = 0;
                        objResult.data[i].Weight = 0;
                        
                        for(var j = 0; j < objResult.extData.length; j++){
                            if(objResult.data[i].Id == objResult.extData[j].MB_Id){  
                                objResult.extData[j].NumberShort = objResult.extData[j].Number.substr(4);
                                objResult.data[i].NumberShort += objResult.extData[j].NumberShort + ",";
                                objResult.extData[j].OldPiece = objResult.extData[j].Piece;
                                
                                objResult.data[i].arrItem.push(objResult.extData[j]);
                                objResult.data[i].Piece += objResult.extData[j].Piece;
                                if(objResult.extData[j].Weight==0 && objResult.extData[j].Piece==objResult.extData[j].OO_CurrentPiece){
                                    objResult.extData[j].Weight = objResult.extData[j].OO_CurrentWeight;
                                }
                                objResult.data[i].Weight += objResult.extData[j].Weight;                                  
                            }
                        }
                    }
                    else{
                        for(var j = 0; j < objResult.extData.length; j++){
                            if(objResult.data[i].Id == objResult.extData[j].MB_Id){  
                                objResult.extData[j].NumberShort = objResult.extData[j].Number.substr(4);
                                objResult.data[i].NumberShort += objResult.extData[j].NumberShort + ",";
                                
                                objResult.data[i].arrItem.push(objResult.extData[j]);
                            }
                        }
                    }
                    

                    if(objResult.data[i].OverallWeight != null){                                
                        objResult.data[i].GrossGoodsWeight = objResult.data[i].GrossWeight - objResult.data[i].BoardWeight - objResult.data[i].ElseWeight;
                        objResult.data[i].Tip = "超" + (objResult.data[i].GrossGoodsWeight-objResult.data[i].Weight).toFixed(1) +"("+((objResult.data[i].GrossGoodsWeight-objResult.data[i].Weight)*100/objResult.data[i].Weight).toFixed(2)+"%)";
                    }
                    else{
                        objResult.data[i].GrossGoodsWeight = null;   // 过磅货物重量
                        objResult.data[i].Tip = "";    // 超出提示
                    }
                }
                this.arrMakeBoard = objResult.data;                        
            });
        },

        pieceFocus:function(objChild){
            this.strTip = "";
            var nBoardCount = 0;    // 打在几个板上
            var nTotalPiece = 0;
            var dTotalWeight = 0.0;
            for(var i = 0; i < this.arrMakeBoard.length; i++){
                for(var j = 0; j < this.arrMakeBoard[i].arrItem.length; j++){
                    if(this.arrMakeBoard[i].arrItem[j].NumberShort == objChild.NumberShort){
                        nBoardCount+=1;
                        nTotalPiece += this.arrMakeBoard[i].arrItem[j].Piece;
                        dTotalWeight += this.arrMakeBoard[i].arrItem[j].Weight;
                    }
                }
            }
            this.strTip = nBoardCount+'板;'+objChild.OO_CurrentPiece +"-"+nTotalPiece+"="+(objChild.OO_CurrentPiece-nTotalPiece)+";"+objChild.OO_CurrentWeight +"-"+dTotalWeight+"="+(objChild.OO_CurrentWeight-dTotalWeight);
        },
        weightFocus: function(objChild){
            this.strTip = "";
            var nBoardCount = 0;    // 打在几个板上
            // for(var i = 0; i < this.arrMakeBoard.length; i++){
            //     if(this.arrMakeBoard[i].NumberShort.indexOf(objChild.NumberShort)>-1){
            //         nBoardCount+=1;
            //     }
            // }
            var nTotalPiece = 0;
            var dTotalWeight = 0.0;
            for(var i = 0; i < this.arrMakeBoard.length; i++){
                for(var j = 0; j < this.arrMakeBoard[i].arrItem.length; j++){
                    if(this.arrMakeBoard[i].arrItem[j].NumberShort == objChild.NumberShort){
                        nBoardCount+=1;
                        nTotalPiece += this.arrMakeBoard[i].arrItem[j].Piece;
                        dTotalWeight += this.arrMakeBoard[i].arrItem[j].Weight;
                    }
                }
            }
            this.strTip = nBoardCount+'板;'+objChild.OO_CurrentPiece +"-"+nTotalPiece+"="+(objChild.OO_CurrentPiece-nTotalPiece)+";"+objChild.OO_CurrentWeight +"-"+dTotalWeight+"="+(objChild.OO_CurrentWeight-dTotalWeight);
        },
        weightChange: function(objItem,objChild){
            var nBoardCount = 0;    // 打在几个板上
            var nZeroCount = 0;
            var nTotalPiece = 0;    // 件数
            var dTotalWeight = 0.0;
            for(var i = 0; i < this.arrMakeBoard.length; i++){
                for(var j = 0; j < this.arrMakeBoard[i].arrItem.length; j++){
                    if(this.arrMakeBoard[i].arrItem[j].NumberShort == objChild.NumberShort){
                        nBoardCount+=1;
                        dTotalWeight += this.arrMakeBoard[i].arrItem[j].Weight;
                        nTotalPiece += this.arrMakeBoard[i].arrItem[j].Piece;
                        if(this.arrMakeBoard[i].arrItem[j].Weight==0){
                            nZeroCount+=1;
                        }
                        break;
                    }
                }
            }

            if(nZeroCount == 1 && nTotalPiece==objChild.OO_CurrentPiece){    // 只有一个板为0且打板件数等于剩余件数
                var blnOver = false;
                for(var i = 0; i < this.arrMakeBoard.length; i++){
                    for(var j = 0; j < this.arrMakeBoard[i].arrItem.length; j++){
                        if(this.arrMakeBoard[i].arrItem[j].NumberShort == objChild.NumberShort){
                            if(this.arrMakeBoard[i].arrItem[j].Weight==0){
                                this.arrMakeBoard[i].arrItem[j].Weight = objChild.OO_CurrentWeight-dTotalWeight;
                                this.arrMakeBoard[i].Weight += this.arrMakeBoard[i].arrItem[j].Weight;
                                dTotalWeight = objChild.OO_CurrentWeight;
                                blnOver = true;
                            }
                            break;
                        }
                    }
                    if(blnOver==true){
                        break;
                    }
                }
            }
            this.strTip = nBoardCount+'板;'+objChild.OO_CurrentPiece+"-"+nTotalPiece+"="+(objChild.OO_CurrentPiece-nTotalPiece)+";"+objChild.OO_CurrentWeight +"-"+dTotalWeight+"="+(objChild.OO_CurrentWeight-dTotalWeight);



            // console.log('a11')
            var dTotalBoardWeight = 0;
            for(var i = 0; i < objItem.arrItem.length; i++){
                dTotalBoardWeight += objItem.arrItem[i].Weight;
            }
            objItem.Weight = parseFloat(dTotalBoardWeight.toFixed(1));

            objItem.Tip = "超" + (objItem.GrossGoodsWeight-objItem.Weight).toFixed(1) +"("+((objItem.GrossGoodsWeight-objItem.Weight)*100/objItem.Weight).toFixed(2)+"%)";
        },
        pieceChange: function(objItem,objChild){
            this.strTip = "";
            var nBoardCount = 0;    // 打在几个板上
            var nTotalPiece = 0;
            var dTotalWeight = 0.0;
            for(var i = 0; i < this.arrMakeBoard.length; i++){
                for(var j = 0; j < this.arrMakeBoard[i].arrItem.length; j++){
                    if(this.arrMakeBoard[i].arrItem[j].NumberShort == objChild.NumberShort){
                        nBoardCount+=1;
                        nTotalPiece += this.arrMakeBoard[i].arrItem[j].Piece;
                        dTotalWeight += this.arrMakeBoard[i].arrItem[j].Weight;
                    }
                }
            }
            this.strTip = nBoardCount+'板;'+objChild.OO_CurrentPiece +"-"+nTotalPiece+"="+(objChild.OO_CurrentPiece-nTotalPiece)+";"+objChild.OO_CurrentWeight +"-"+dTotalWeight+"="+(objChild.OO_CurrentWeight-dTotalWeight);


            var nTotalBoardPiece = 0;
            for(var i = 0; i < objItem.arrItem.length; i++){
                nTotalBoardPiece += objItem.arrItem[i].Piece;
            }
            objItem.Piece = nTotalBoardPiece;
        },
        overallWeightChange: function(objItem){                   
            objItem.GrossWeight = objItem.OverallWeight - objItem.ChassisWeight;
            objItem.GrossGoodsWeight = objItem.GrossWeight - objItem.BoardWeight - objItem.ElseWeight;

            objItem.Tip = "超" + (objItem.GrossGoodsWeight-objItem.Weight).toFixed(1) +"("+((objItem.GrossGoodsWeight-objItem.Weight)*100/objItem.Weight).toFixed(2)+"%)";
        },
        elseWeightChange: function(objItem){
            objItem.GrossGoodsWeight = objItem.GrossWeight - objItem.BoardWeight - objItem.ElseWeight;

            objItem.Tip = "超" + (objItem.GrossGoodsWeight-objItem.Weight).toFixed(1) +"("+((objItem.GrossGoodsWeight-objItem.Weight)*100/objItem.Weight).toFixed(2)+"%)";
        },


        updateState: function(nId,nToState){
            this.$confirm("确定执行'"+(nToState==52?'打回':'已核对')+"'操作吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/MakeBoard/UpdateState",{Id:nId, ToState: nToState}).then(objResult=> {
                    if(objResult.success == false){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }
                    
                    this.$message({message: '提交成功',type: 'success'});      
                    for(var i = 0; i < this.arrMakeBoard.length; i++){
                        if(this.arrMakeBoard[i].Id == nId){
                            this.arrMakeBoard.splice(i,1);
                            break;
                        }
                    }                          
                });
            }).catch(function () {
            });
        },
        save: function(objItem){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            if(objItem.OverallWeight == null || objItem.OverallWeight < 0 || (''+objItem.OverallWeight).indexOf('.') > -1 ){
                this.$message({message: '请输入过磅数据',type: 'error'});      
                this.ctrForm.blnSubmit = false;
                return;
            }
            if(objItem.Type==1 && objItem.Height == null){
                this.$message({message: '请输入板高',type: 'error'});      
                this.ctrForm.blnSubmit = false;
                return;
            }

            objItem.ItemCount = 0;
            // var nIndex = 0;
            for(var i = 0; i < objItem.arrItem.length; i++){
                if(objItem.arrItem[i].Piece == null || objItem.arrItem[i].Piece < 0){
                    this.$message({message: '请输入货运单件数',type: 'error'});      
                    this.ctrForm.blnSubmit = false;
                    return;
                }
                if(objItem.arrItem[i].Weight == null || objItem.arrItem[i].Weight < 0){
                    this.$message({message: '请输入货运单重量',type: 'error'});      
                    this.ctrForm.blnSubmit = false;
                    return;
                }

                objItem["Id"+i] = objItem.arrItem[i].Id;
                objItem["OO_Id"+i] = objItem.arrItem[i].OO_Id;
                objItem["Piece"+i] = objItem.arrItem[i].Piece;
                objItem["OldPiece"+i] = objItem.arrItem[i].OldPiece;
                objItem["Weight"+i] = objItem.arrItem[i].Weight;
                objItem["Volume"+i] = (objItem.arrItem[i].Weight/objItem.arrItem[i].OO_Weight)*objItem.arrItem[i].OO_Volume;
                // console.log(JSON.stringify(objItem.arrItem[i]));
                objItem.ItemCount+=1;
                
            }


            this.$ajax.post('/Admin/MakeBoard/UpdateData?FromPage=1', objItem).then(objResult=> {                                  
                this.ctrForm.blnSubmit = false;
                if(objResult.success == false){
                    this.$alert(objResult.message, '系统提示', { type: 'error' });                        
                    return;
                }

                for(var i = 0; i < objItem.arrItem.length; i++){
                    objItem.arrItem[i].OldPiece = objItem.arrItem[i].Piece;
                }
                this.$message({message: '提交成功',type: 'success'});      
            });
        }
    }
}

</script>

<style scoped>
.def_text-mini{padding:1px; width: 100%; border:1px solid #999999; }
.on{ background-color: greenyellow; }
</style>
