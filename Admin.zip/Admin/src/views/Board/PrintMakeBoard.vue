<template>
    <div class="hc_container-fluid" style="height:100%;">       
        <div class="row" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div id="divPrint" style="width: 842px;">
                <table class="hc-table_print" style="width: 100%;">
                    <tr>
                        <td style="font-size: 2rem; font-weight: bold; text-align: center; padding: 10px 0px;">{{$lib.Store.getValById($store.state.Flight.objMapping,F_Id,"Date")}} {{$lib.Store.getValById($store.state.Flight.objMapping,F_Id,"Number")}}国际货物组板清单</td>
                    </tr>
                </table>
                
                <table class="hc-table_print hc-table_print-big" style="width: 100%; border-top:none; font-size: 1.4rem !important;">
                    <thead>
                        <tr>
                            <th style="width: 120px;">集装器</th>
                            <th style="width: 50px;">运单号</th>
                            <th style="width: 50px;">目的港</th>
                            <th style="width: 65px;">件数</th>
                            <th style="width: 60px;">重量</th>
                            <th style="width: 80px;">总件数<br />总重量</th>
                            <th style="width: 40px;">底架<br />编码</th>
                            <th style="width: 85px;">过磅数据</th>
                            <th style="width: 70px;">过磅重量<br /><含板量></th>
                            <th style="width: 40px;">板型</th>
                            <th style="width: 40px;">其他</th>
                            <th style="width: 50px;">状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- <tr>
                            <td style="text-align: center;">PAG23245ET 段</td>
                            <td style="text-align: right;">2312</td>
                            <td style="text-align: center;">ADD</td>
                            <td style="text-align: right;">111/202</td>
                            <td style="text-align: center;">2795</td>
                            <td style="text-align: right;">111/3819</td>
                            <td style="text-align: center;">217</td>
                            <td style="text-align: right;">5145-1195</td>
                            <td style="text-align: center;">3950</td>
                            <td style="text-align: center;">Q5</td>
                            <td style="text-align: center;">30</td>
                            <td style="text-align: center;">待核对</td>
                        </tr> -->
                        <template v-for="objItem in arrMakeBoard">
                            <tr>
                                <td style="text-align: center;">{{objItem.BoardNumber}} {{$store.state.Employee.objMapping[objItem.E_Id].Name.substr(0,1)}}</td>

                                <td style="text-align: right;">{{objItem.arrItem[0].NumberShort}}</td>
                                <td style="text-align: center;">{{objItem.arrItem[0].ToCityCode}}</td>
                                <td style="text-align: right;">{{objItem.arrItem[0].Piece}}/{{objItem.arrItem[0].OO_CurrentPiece}}</td>
                                <td style="text-align: center;">{{objItem.arrItem[0].Weight==0?"____":objItem.arrItem[0].Weight}}</td>

                                <td style="text-align: right;">{{objItem.Piece}}/{{objItem.Weight==0?"____":objItem.Weight}}&nbsp;</td>
                                <td style="text-align: center;">{{objItem.ChassisNumber}}</td>
                                <td style="text-align: right;">{{objItem.OverallWeight}}-{{objItem.ChassisWeight}}</td>
                                <td style="text-align: center;">{{objItem.GrossWeight}}</td>
                                <td style="text-align: center;">{{objItem.BoardType}}</td>
                                <td style="text-align: center;">{{objItem.ElseWeight}}</td>
                                <td style="text-align: center;">{{fmtState(objItem.State)}}</td>
                            </tr>

                            <template v-if="objItem.ItemCount>1">
                                <tr v-for="(objChild,j) in objItem.arrItem" v-if="j>0">
                                    <td></td>
                                    
                                    <td style="text-align: right;">{{objChild.NumberShort}}</td>
                                    <td style="text-align: center;">{{objChild.ToCityCode}}</td>
                                    <td style="text-align: right;">{{objChild.Piece}}/{{objChild.OO_CurrentPiece}}</td>
                                    <td style="text-align: center;">{{objChild.Weight==0?"____":objChild.Weight}}</td>
                                    
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </template>
                            <tr style="height: 15px;">
                                <td colspan="12"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">            
            <el-button size="small" type="success" icon="el-icon-printer" onclick="printJS({printable:'divPrint',type:'html',css:'/static/script/hcui.css'})">打 印</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>
</template>

<script>

export default {
    data: function() {
        return{
            arrMakeBoard:[]
        }
    },
    props:{   
        AL_Id:{
            type: Number,
            default: null
        },
        F_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {        
    },
    watch: {
    },
    created: function() {       
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){
            this.loadMakeBoard();
        },

        loadMakeBoard: function(){                    
            this.$ajax.get('/Admin/MakeBoard/GetData', {FromPage:"CheckData", AL_Id: this.AL_Id }).then(objResult => {  
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].arrItem = [];
                    objResult.data[i].BoardNumber = objResult.data[i].BoardNumber.replace("PMC","").replace("AKE","");
                    objResult.data[i].ItemCount = 0;
                    objResult.data[i].blnShow = true;

                    if(objResult.data[i].State==53){
                        objResult.data[i].Piece = 0;
                        objResult.data[i].Weight = 0;
                        objResult.data[i].IsZero = false;
                        for(var j = 0; j < objResult.extData.length; j++){
                            if(objResult.data[i].Id == objResult.extData[j].MB_Id){  
                                objResult.extData[j].NumberShort = objResult.extData[j].Number.substr(4);
                                
                                objResult.data[i].arrItem.push(objResult.extData[j]);
                                objResult.data[i].Piece += objResult.extData[j].Piece;
                                if(objResult.extData[j].Weight==0){
                                    if(objResult.extData[j].Piece==objResult.extData[j].OO_CurrentPiece){
                                        objResult.extData[j].Weight = objResult.extData[j].OO_CurrentWeight;
                                    }
                                    else{
                                        objResult.data[i].IsZero = true;
                                    }
                                }
                                
                                objResult.data[i].Weight += objResult.extData[j].Weight;
                                objResult.data[i].ItemCount += 1;
                            }
                        }
                        if(objResult.data[i].IsZero == true){
                            objResult.data[i].Weight = 0;
                        }
                    }
                    else{
                        for(var j = 0; j < objResult.extData.length; j++){
                            if(objResult.data[i].Id == objResult.extData[j].MB_Id){  
                                objResult.extData[j].NumberShort = objResult.extData[j].Number.substr(4);
                                
                                objResult.data[i].arrItem.push(objResult.extData[j]);
                                objResult.data[i].ItemCount += 1;
                            }
                        }
                    }
                    
                }
                this.arrMakeBoard = objResult.data;                        
            });
        },

        fmtState: function(nState){
            var strReturn = nState;
            switch(nState){
                case 53: strReturn = "待核对"; break;
                case 54: strReturn = "待打印"; break;
                case 55: strReturn = "待检查"; break;
                case 56: strReturn = "待装机"; break;
            }
            return strReturn
        }
    }
}

</script>

<style scoped>

</style>
