<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">

                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航线</div>                    
                    <div class="form-item-bd">
                        {{$store.state.AirLine.objMapping[objData.AL_Id].Name}}                            
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航班</div>                    
                    <div class="form-item-bd">
                        {{$store.state.Flight.objMapping[objData.F_Id].Date + "_" + $store.state.Flight.objMapping[objData.F_Id].Number}}
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                
                <div class="col-240 form-item">
                    <div class="form-item-hd">ULD舱单导入</div>                    
                    <div class="form-item-bd">                        
                        <file-pond ref="upManifest" @processfile="handleProcessFileManifest" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportManifestULD?AL_Id='+objData.AL_Id+'&F_Id='+objData.F_Id+'&E_Id='+objData.E_Id" label-idle="点击导入ULD舱单数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">关 闭</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{    
        AL_Id:{
            type: Number,
            default: null
        },
        F_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        } 
    },
    data: function() {
        return{           
            // arrBaseBoard:[], 
            objData:{
                AL_Id: this.AL_Id,
                F_Id: this.F_Id, 
                E_Id: this.$store.state.jobjUser.E_Id,
            }
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {               
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){             
        },

        handleProcessFileManifest: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upManifest"].removeFile(file.id);                
            }
        },
        
    }
}
</script>

<style scoped>

</style>
