<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">
                <template v-if="DataFrom==2">
                <!-- <div class="col-240 form-item">
                    <div class="form-item-hd">所属航线</div>                    
                    <div class="form-item-bd">
                        <select v-model="objData.AL_Id" class="hc_select" style="width: 150px;">
                            <option v-for="(objItem,i) in $store.state.AirLine.arrData" :value='objItem.Id'>{{objItem.Name}}</option>                    
                        </select>
                    </div>
                    <div class="form-item-ft"></div>
                </div> -->
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航线</div>                    
                    <div class="form-item-bd">
                        {{$store.state.AirLine.objMapping[objData.AL_Id].Name}}                            
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航班</div>                    
                    <div class="form-item-bd">
                        {{$store.state.Flight.objMapping[objData.F_Id].Date + "_" + $store.state.Flight.objMapping[objData.F_Id].Number}}
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">上一次CBA导入时间</div>                    
                    <div class="form-item-bd">{{objFlight.ImportCBATime}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd">CBA导入</div>                    
                    <div class="form-item-bd">
                        <file-pond ref="upCBA" @processfile="handleProcessFile" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportCBA?AL_Id='+objData.AL_Id+'&F_Id='+objData.F_Id+'&E_Id='+objData.E_Id" label-idle="点击导入CBA清单数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-240 clr-text3" style="margin-top: 10px;">
                    备注：CBA单必须在待分配前导入；舱单最迟在开始组板前导入
                </div>
                </template>
                <template v-else-if="DataFrom==3">
                    <div class="col-240 form-item">
                        <div class="form-item-hd">所属航线</div>                    
                        <div class="form-item-bd">
                            {{$store.state.AirLine.objMapping[objData.AL_Id].Name}}                            
                        </div>
                        <div class="form-item-ft"></div>
                    </div>
                    <div class="col-240 form-item">
                        <div class="form-item-hd">所属航班</div>                    
                        <div class="form-item-bd">
                            {{$store.state.Flight.objMapping[objData.F_Id].Date + "_" + $store.state.Flight.objMapping[objData.F_Id].Number}}
                        </div>
                        <div class="form-item-ft"></div>
                    </div>
                    <div class="col-240 form-item">
                        <div class="form-item-hd">上一次CBA导入时间</div>                    
                        <div class="form-item-bd">{{objFlight.ImportCBATime}}</div>
                        <div class="form-item-ft"></div>
                    </div>
                    <div class="col-240 form-item">
                        <div class="form-item-hd">上一次舱单导入时间</div>                    
                        <div class="form-item-bd">{{objFlight.ImportManifestTime}}</div>
                        <div class="form-item-ft"></div>
                    </div>
                    <div class="col-240 form-item">
                        <div class="form-item-hd">无ULD舱单导入</div>                    
                        <div class="form-item-bd">                        
                            <file-pond ref="upManifest" @processfile="handleProcessFileManifest" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportManifest?AL_Id='+objData.AL_Id+'&F_Id='+objData.F_Id+'&E_Id='+objData.E_Id" label-idle="点击导入舱单数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                        </div>
                        <div class="form-item-ft"></div>
                    </div>
                    <div class="col-240 clr-text3" style="margin-top: 10px;">
                        备注：CBA单必须在待分配前导入；舱单最迟在开始组板前导入
                    </div>
                </template>
                <!-- <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>板号</div>
                    <validation-provider tag="div" name="板号" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <hc-popup-radio ref="popBaseBoard" v-model="objData.BB_Id" name="板号" :data="arrBaseBoard" position="bottom" :mode="2" :filter="true" name-key="Number"></hc-popup-radio>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                </div> -->
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">关 闭</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{    
        DataFrom:{
            type: Number,
            default: null
        },
        AL_Id:{
            type: Number,
            default: null
        },
        F_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        } 
    },
    data: function() {
        return{           
            // arrBaseBoard:[], 
            objData:{
                // AL_Id: (this.DataFrom==2?this.$store.state.AirLine.arrData[0].Id:this.AL_Id),               
                AL_Id: this.AL_Id,
                F_Id: this.F_Id, 
                E_Id: this.$store.state.jobjUser.E_Id,

                // BB_Id: 1000,
            },
            objFlight:{
                ImportCBATime: "",
                ImportManifestTime: "",
            }
        }
    },    
    computed: {
    },
    watch: {
        // "objData.BB_Id": function(nNew, nOld){      
        //     console.log(this.objData.BB_Id);       
        //     console.log(this.$refs.popBaseBoard.objCurrent);       
        //     if(this.objData.BB_Id == null || this.objData.BB_Id == -1){
        //         console.log('b1');
        //     }
        //     else{                 
        //         console.log('b2');
        //         // console.log(this.$refs.popBaseBoard);
        //         // console.log(this.$refs.popBaseBoard.objCurrent);
        //         // alert(this.$refs.popBaseBoard.objCurrent.Weight);                
        //     }
        // }
    },
    created: function() {        
        // this.$ajax.get('/Admin/BaseBoard/Get', { Field: "*", Where:{}, OrderBy:"Number asc" }).then(objResult => {
        //     this.arrBaseBoard = objResult.data;
        // });           
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){    
            // if(this.DataFrom==3){
                this.$ajax.get('/Admin/Flight/GetById?Id=' + this.objData.F_Id).then(objResult=> {                  
                    if(objResult.success == false){                    
                        this.$alert(objResult.message, '系统提示', { type: 'error' });
                        return;
                    }
                                
                    this.objFlight.ImportCBATime = this.$lib.Format.fmtTime(objResult.data[0].ImportCBATime);
                    this.objFlight.ImportManifestTime = this.$lib.Format.fmtTime(objResult.data[0].ImportManifestTime);
                });
            // }            
        },

        handleProcessFile: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upCBA"].removeFile(file.id);                
            }
        },
        handleProcessFileManifest: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upManifest"].removeFile(file.id);                
            }
        },
        
    }
}
</script>

<style scoped>

</style>
