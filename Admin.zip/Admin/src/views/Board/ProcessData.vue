<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <!-- <div class="col-240 form-item">
                <div class="form-item-hd">航线</div>                    
                <div class="form-item-bd">
                    <select v-model="objData.AL_Id" class="hc_select" @change="loadFlight();" style="width: 200px;">
                        <option v-for="(objItem,i) in $store.state.AirLine.arrData" :value='objItem.Id'>{{objItem.Name}}</option>                    
                    </select>
                </div>
                <div class="form-item-ft"></div>
            </div>
            <div class="col-240 form-item">
                <div class="form-item-hd">航班</div>                    
                <div class="form-item-bd">
                    <select v-model="objData.F_Id" class="hc_select" style="width: 200px;">
                        <option v-for="(objItem,i) in arrFlight" :value='objItem.Id'>{{objItem.Date}}_{{objItem.Number}}</option>                    
                    </select>
                </div>
                <div class="form-item-ft"></div>
            </div> -->
            <div class="col-240 form-item">
                <div class="form-item-hd">所属航线</div>                    
                <div class="form-item-bd">
                    {{$store.state.AirLine.objMapping[objData.AL_Id].Name}}                            
                </div>
                <div class="form-item-ft"></div>
            </div>
            <div class="col-240 form-item">
                <div class="form-item-hd">所属航班</div>                    
                <div class="form-item-bd">
                    {{$store.state.Flight.objMapping[objData.F_Id].Date + "_" + $store.state.Flight.objMapping[objData.F_Id].Number}}
                </div>
                <div class="form-item-ft"></div>
            </div>
            <div class="col-240 clr-text3" style="margin-top: 10px;">
                备注：只会删除通过CBA清单导入的且状态为待组板的货运单数据。
            </div>
            <div class="col-240 form-item">
                <div class="form-item-hd"></div>
                <div class="form-item-bd">
                    <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交删除</el-button>
                </div>
                <div class="form-item-ft"></div>
            </div>
        </validation-observer>

        <!-- <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">关闭</el-button>
        </div> -->
    </div>  
</template>

<script>

export default {
    props:{
        AL_Id:{
            type: Number,
            default: null
        },
        F_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
   
            // arrFlight:[],
            objData:{
                AL_Id: this.AL_Id,
                F_Id: this.F_Id
            }
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {    
        // this.objData.AL_Id = this.$store.state.AirLine.arrData[0].Id; 
        // this.loadFlight();              
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
        },
        // loadFlight: function(){
        //     this.objData.F_Id = null;
        //     var objWhere = {
        //         "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
        //         "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
        //     }
        //     this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
        //         for(var i = 0; i < objResult.data.length; i++){
        //             objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
        //         }
        //         this.arrFlight = objResult.data;
        //     });
        // },
        
        
        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/ProcessData?FromPage=CBADelete', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>

</style>
