<template>
  <div class="download-page">
    <div class="header">
      <h1>鑫辰物流APP下载</h1>
      <p>访问地址：app.xinchen168.cn</p>
    </div>
    
    <div class="download-options">
      <div class="download-item">
        <div class="icon android">
          <i class="el-icon-mobile-phone"></i>
        </div>
        <h2>Android版本</h2>
        <a href="http://app.xinchen168.cn/android/xinchen.apk" class="download-btn" target="_blank">
          立即下载
        </a>
        <p class="version-info">最新版本：v1.0.0</p>
      </div>
      
      <div class="download-item">
        <div class="icon ios">
          <i class="el-icon-mobile-phone"></i>
        </div>
        <h2>iOS版本</h2>
        <button class="download-btn disabled" disabled>
          开发中
        </button>
        <p class="version-info">敬请期待</p>
      </div>
    </div>
    
    <div class="qr-code">
      <div class="qr-wrapper">
        <img :src="require('@/assets/qr-code.png')" alt="二维码">
        <p>扫描二维码下载</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AppDownload',
  data() {
    return {
      // Add any reactive data here if needed
    }
  }
}
</script>

<style scoped>
.download-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 20px;
  text-align: center;
}

.header {
  margin-bottom: 60px;
}

.header h1 {
  font-size: 36px;
  color: #333;
  margin-bottom: 16px;
}

.header p {
  font-size: 18px;
  color: #666;
}

.download-options {
  display: flex;
  justify-content: center;
  gap: 60px;
  margin-bottom: 60px;
}

.download-item {
  width: 280px;
  padding: 30px;
  border-radius: 12px;
  background: #fff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.download-item:hover {
  transform: translateY(-5px);
}

.icon {
  font-size: 48px;
  margin-bottom: 20px;
}

.icon i {
  font-size: 64px;
  color: #409EFF;
}

.download-item h2 {
  font-size: 24px;
  color: #333;
  margin-bottom: 20px;
}

.download-btn {
  display: inline-block;
  padding: 12px 36px;
  border-radius: 24px;
  background: #409EFF;
  color: #fff;
  font-size: 16px;
  border: none;
  cursor: pointer;
  transition: background 0.3s ease;
  text-decoration: none;
}

.download-btn:hover:not(.disabled) {
  background: #66b1ff;
}

.download-btn.disabled {
  background: #909399;
  cursor: not-allowed;
}

.version-info {
  margin-top: 10px;
  font-size: 14px;
  color: #666;
}

.qr-code {
  margin-top: 40px;
}

.qr-wrapper {
  display: inline-block;
}

.qr-wrapper img {
  width: 200px;
  height: 200px;
  margin-bottom: 16px;
}

.qr-wrapper p {
  font-size: 16px;
  color: #666;
}
</style>
