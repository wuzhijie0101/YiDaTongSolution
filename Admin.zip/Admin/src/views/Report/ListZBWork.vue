<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">                
                <el-select v-model="ctrTable.objParam.Where.AL_Id.strValue" filterable clearable placeholder="所属航线" style="width: 120px;">
                    <el-option v-for="objItem in $store.state.AirLine.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>                
                <el-date-picker v-model="ctrTable.objParam.Where.Date_Start.strValue" type="date" clearable value-format="yyyy-MM-dd 00:00:00" placeholder="航班开始时间" style="width:120px;"></el-date-picker>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_End.strValue" type="date" clearable value-format="yyyy-MM-dd 23:59:59" placeholder="航班结束时间" style="width:120px;"></el-date-picker>            

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-button-group>
                    <el-button v-show="$store.state.TabMenu.objMapping[198].HasPower" type="success" icon="el-icon-download" @click="exportExcel();">导出Excel</el-button>
                </el-button-group>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <table class="hc-table" style="overflow: auto;">
                <thead>
                    <tr style="line-height: 28px;">
                        <th style="width:90px;">航班日期</th>
                        <th v-for="strE_Id in Object.keys(objE_Id)" style="width:70px;">{{$store.state.Employee.objMapping[strE_Id].Name}}</th>
                    </tr>                
                </thead>
                <tbody>
                    <tr v-for="strDate in Object.keys(objData)" style="height: 28px;">
                        <td>{{strDate}}</td>
                        <td v-for="strE_Id in Object.keys(objE_Id)" style="text-align: right;">
                            {{(objData[strDate].hasOwnProperty(strE_Id)==true?objData[strDate][strE_Id]:"")}}
                        </td>
                    </tr>
                </tbody>
            </table>

                 
        </div>
    </div>    
</template>

<script>

export default {
    data: function() {
        return{
            PM_Id: 118,

            objE_Id: {},
            objData: {},            
            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {                                
                        "State": { "strField": "mb.State", "strCondition": ">", "strValue": "53", "strSingleQuotes": "" },
                        "AL_Id": { "strField": "mb.AL_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "Date_Start": { "strField": "f.Date", "strCondition": ">=", "strValue": this.$dayjs(this.$dayjs().format("YYYY-MM-01 08:00:00")).toDate(), "strSingleQuotes": "'" },
                        // "Date_Start": { "strField": "f.Date", "strCondition": ">=", "strValue": this.$dayjs().format("YYYY-MM-01"), "strSingleQuotes": "'" },                        
                        "Date_End": { "strField": "f.Date", "strCondition": "<", "strValue": "", "strSingleQuotes": "'" },
                    },
                    OrderBy: ""
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性                        
            return this.ctrTable.objParam.Where.AL_Id.strValue + this.ctrTable.objParam.Where.Date_Start.strValue + this.ctrTable.objParam.Where.Date_End.strValue;
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){              
            this.search();            
        },

        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            console.log(this.ctrTable.objParam);
            this.$ajax.get('/Admin/Report/GetZBWork', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == false) {                    
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                    return;
                }          
                
                console.log(objResult);
                this.objE_Id = {};
                for (var strDate in objResult.data) {
                    for (var strE_Id in objResult.data[strDate]) {
                        if(this.objE_Id.hasOwnProperty(strE_Id) == false){
                            this.objE_Id[strE_Id] = 1;
                        }
                    }
                }                            
                this.objData = objResult.data;
            });
        },
        exportExcel:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportZBWork?token="+localStorage.getItem("strToken")+"&Where=" + JSON.stringify(this.ctrTable.objParam.Where);            
        }            
    }
}

</script>

<style scoped>

</style>
