<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                <el-select v-model="ctrTable.objParam.Where.ECAgent.strValue" clearable placeholder="申报主体" style="width:90px;">
                    <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_ECAgent" :label="objItem.Name" :value="objItem.Value"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.CC_IdKJ.strValue" filterable clearable placeholder="所属客户" style="width: 100px;">
                    <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(1002)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.AL_Id.strValue" filterable clearable placeholder="所属航线" style="width: 120px;">
                    <el-option v-for="objItem in $store.state.AirLine.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>                
                <el-date-picker v-model="ctrTable.objParam.Where.Date_Start.strValue" type="date" clearable value-format="yyyy-MM-dd 00:00:00" placeholder="航班开始时间" style="width:120px;"></el-date-picker>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_End.strValue" type="date" clearable value-format="yyyy-MM-dd 23:59:59" placeholder="航班结束时间" style="width:120px;"></el-date-picker>            

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-button-group>
                    <el-button  v-show="$store.state.TabMenu.objMapping[183].HasPower" type="success" icon="el-icon-download" @click="exportExcel();">导出Excel</el-button>
                </el-button-group>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:100%;">   
                <el-table-column prop="ECAgent" label="申报主体" width="75" column-key="OutOrder_ECAgent" :formatter="$lib.Element.Table.formatter"></el-table-column>             
                <el-table-column prop="FlightDate" label="航班日期" width="90" :formatter="$lib.Element.Table.fmtDate"></el-table-column>
                
                <el-table-column prop="Number" label="空运单号" width="90"></el-table-column>
                <el-table-column prop="ToCityCode" label="目的港" width="120"></el-table-column>
                <el-table-column prop="Piece" label="实收件数" width="75" align="right"></el-table-column>
                <el-table-column prop="PackageCount" label="清单总数" width="75" align="right"></el-table-column>
                <el-table-column prop="Weight" label="实收重量" width="75" align="right"></el-table-column>
                <el-table-column prop="ChargeWeight" label="计费重量" width="75" align="right"></el-table-column>
                <el-table-column prop="ReportMoney" label="申报金额" width="90" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>
                <el-table-column prop="State" label="状态" width="120" column-key="OutOrder_State" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="SendInforTime" label="送报关资料时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                <el-table-column prop="CC_IdKJ" label="所属客户" width="100" :formatter="$lib.Element.Table.fmtCompanyCustomerName"></el-table-column>                                       
                <el-table-column prop="TransportMode" label="运输方式" width="75" column-key="OutOrder_TransportMode" :formatter="$lib.Element.Table.formatter"></el-table-column>                
            </el-table>            
        </div>
    </div>    
</template>

<script>

export default {
    data: function() {
        return{
            PM_Id: 113,

            C_IdKey: "",
            CC_IdKey: "",
            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {                                
                        "State": { "strField": "oo.State", "strCondition": "<", "strValue": "61", "strSingleQuotes": "" },
                        "C_IdKJ": { "strField": "oo.C_IdKJ", "strCondition": "=", "strValue": "1002", "strSingleQuotes": "" },
                        "CC_IdKJ": { "strField": "oo.CC_IdKJ", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },                        
                        "AL_Id": { "strField": "oo.AL_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },           
                        "ECAgent": { "strField": "oo.ECAgent", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },             
                        "Date_Start": { "strField": "oo.FlightDate", "strCondition": ">=", "strValue": this.$dayjs(this.$dayjs().format("YYYY-MM-01 08:00:00")).toDate(), "strSingleQuotes": "'" },
                        "Date_End": { "strField": "oo.FlightDate", "strCondition": "<", "strValue": "", "strSingleQuotes": "'" },
                    },
                    OrderBy: ""
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性                        
            return this.ctrTable.objParam.Where.ECAgent.strValue + this.ctrTable.objParam.Where.CC_IdKJ.strValue + this.ctrTable.objParam.Where.AL_Id.strValue + this.ctrTable.objParam.Where.Date_Start.strValue + this.ctrTable.objParam.Where.Date_End.strValue;
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                
            this.search();            
        },

        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            
            
            this.$ajax.get('/Admin/Report/GetKJOutOrder', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == true) {
                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                    if (this.ctrTable.nTotal > 0) {
                        this.$refs.tblList.setCurrentRow(this.ctrTable.arrData[0]);
                    }
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });
        },
        exportExcel:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportKJOutOrder?token="+localStorage.getItem("strToken")+"&Where=" + JSON.stringify(this.ctrTable.objParam.Where);            
        }            
    }
}

</script>

<style scoped>

</style>
