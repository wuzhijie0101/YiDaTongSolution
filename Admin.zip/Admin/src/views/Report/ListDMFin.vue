<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                <el-select v-model="ctrTable.objParam.Where.CC_IdDM.strValue" filterable clearable placeholder="所属客户" style="width: 100px;">
                    <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(1004)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.AL_Id.strValue" filterable clearable placeholder="所属航线" style="width: 120px;">
                    <el-option v-for="objItem in $store.state.AirLine.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>   
                <el-select v-model="ctrTable.objParam.Where.DirectOrder.strValue" clearable placeholder="直单分单" style="width:100px;">
                    <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_DirectOrder" :label="objItem.Name" :value="objItem.Value"></el-option>
                </el-select>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_Start.strValue" type="date" clearable value-format="yyyy-MM-dd 00:00:00" placeholder="航班开始时间" style="width:120px;"></el-date-picker>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_End.strValue" type="date" clearable value-format="yyyy-MM-dd 23:59:59" placeholder="航班结束时间" style="width:120px;"></el-date-picker>            

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-button-group>
                    <el-button v-show="$store.state.TabMenu.objMapping[194].HasPower" type="success" icon="el-icon-download" @click="exportExcel();">导出Excel</el-button>
                </el-button-group>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:100%;">                
                <el-table-column type="index" width="50" label="序号"></el-table-column>
                <el-table-column prop="CC_IdDM" label="所属客户" width="100" :formatter="$lib.Element.Table.fmtCompanyCustomerName"></el-table-column>
                <el-table-column prop="FlightDate" label="航班日期" width="90" :formatter="$lib.Element.Table.fmtDate"></el-table-column>   
                <el-table-column prop="FlightNumber" label="航班号" width="90"></el-table-column>
                <el-table-column prop="ArrivalTime" label="到货日期" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>  
                <el-table-column prop="DirectOrder" label="直单分单" width="75" column-key="OutOrder_DirectOrder" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="Number" label="空运单号" width="200"></el-table-column>
                <el-table-column prop="ToCityCode" label="目的港" width="75"></el-table-column>
                <el-table-column prop="Piece" label="实收件数" width="75" align="right"></el-table-column>
                <el-table-column prop="Weight" label="实收重量" width="75" align="right"></el-table-column>
                <el-table-column prop="ChargeWeight" label="计费重量" width="75" align="right"></el-table-column>

                <el-table-column prop="BillCount" label="提单分单" width="75" align="center"></el-table-column>
                <el-table-column prop="PreplanCount" label="预配运抵份数" width="100" align="center"></el-table-column>
                <el-table-column prop="PrintCount" label="提单正本份数" width="100" align="center"></el-table-column>

                <el-table-column prop="State" label="状态" width="120" column-key="OutOrder_State" :formatter="$lib.Element.Table.formatter"></el-table-column>                                
                <el-table-column prop="CancelState" label="取消前状态" width="120" column-key="OutOrder_State" :formatter="$lib.Element.Table.formatter"></el-table-column>                                
            </el-table>
        </div>
    </div>    
</template>

<script>

export default {
    data: function() {
        return{
            PM_Id: 116,

            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {                                
                        "State": { "strField": "oo.State", "strCondition": ">", "strValue": "32", "strSingleQuotes": "" },
                        "C_IdDM": { "strField": "oo.C_IdDM", "strCondition": "=", "strValue": "1004", "strSingleQuotes": "" },
                        "CC_IdDM": { "strField": "oo.CC_IdDM", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },                        
                        "AL_Id": { "strField": "oo.AL_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "DirectOrder": { "strField": "oo.DirectOrder", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "Date_Start": { "strField": "oo.FlightDate", "strCondition": ">=", "strValue": this.$dayjs(this.$dayjs().format("YYYY-MM-01 08:00:00")).toDate(), "strSingleQuotes": "'" },
                        "Date_End": { "strField": "oo.FlightDate", "strCondition": "<", "strValue": "", "strSingleQuotes": "'" },
                    },
                    OrderBy: ""
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性                        
            return this.ctrTable.objParam.Where.CC_IdDM.strValue + this.ctrTable.objParam.Where.AL_Id.strValue + this.ctrTable.objParam.Where.DirectOrder.strValue + this.ctrTable.objParam.Where.Date_Start.strValue + this.ctrTable.objParam.Where.Date_End.strValue;
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                
            this.search();            
        },

        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            
            
            this.$ajax.get('/Admin/Report/GetDMFin', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == false) {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }                

                /* 计算分单个数 */
                var nItemCount = 0;
                var nPreId = objResult.data.length>0?objResult.data[0].Id:null;
                var objMapping={};
                for(var i = 1; i < objResult.data.length; i++){
                    if(nPreId != objResult.data[i].Id){
                        objMapping[nPreId] = nItemCount;
                        nPreId = objResult.data[i].Id;
                        nItemCount = 0;
                    }

                    nItemCount += 1;
                }
                objMapping[nPreId] = nItemCount;    // 最后一个

                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].DirectOrder == 1){
                        objResult.data[i].ItemCount = 0;
                    }
                    else{
                        objResult.data[i].ItemCount = objMapping[objResult.data[i].Id];
                    }
                }

                nPreId = null;
                var blnIsFirst = false;
                for(var i = 0; i < objResult.data.length; i++){
                    if(nPreId == null){
                        nPreId = objResult.data[i].Id;
                    }
                    else{
                        blnIsFirst = false;
                        if(nPreId != objResult.data[i].Id){
                            blnIsFirst = true;  // 表示是第一个
                            nPreId = objResult.data[i].Id;
                        }
                    }

                    objResult.data[i].Number = objResult.data[i].PrimaryCode + objResult.data[i].Number;
                    if(objResult.data[i].DirectOrder == 1){     // 直单
                        objResult.data[i].BillCount = 1;
                        objResult.data[i].PreplanCount = 1;

                        if(objResult.data[i].State==61 && objResult.data[i].CancelState<35){    // 取消订单且只录了预配                            
                            objResult.data[i].PrintCount = 0;
                        }
                        else{                            
                            objResult.data[i].PrintCount = 1;
                        }                        
                    }
                    else{
                        if(objResult.data[i].ItemCount == 1){   // 一组一分
                            objResult.data[i].BillCount = 2;
                            objResult.data[i].PreplanCount = (objResult.data[i].IsInputPreplan==1?2:1);

                            if(objResult.data[i].State==61 && objResult.data[i].CancelState<35){    // 取消订单且只录了预配                                
                                objResult.data[i].PrintCount = 0;
                            }
                            else{                                
                                objResult.data[i].PrintCount = (objResult.data[i].BLPrint==1?2:1);
                            }
                        }
                        else{   // 一组多分
                            objResult.data[i].Number = objResult.data[i].Number + "_" + objResult.data[i].OOI_Number;
                            objResult.data[i].BillCount = 1 + (blnIsFirst==true?1:0);
                            objResult.data[i].PreplanCount = (objResult.data[i].IsInputPreplan==1?1:0) + (blnIsFirst==true?1:0);

                            if(objResult.data[i].State==61 && objResult.data[i].CancelState<35){    // 取消订单且只录了预配
                                objResult.data[i].PrintCount = 0;
                            }
                            else{
                                objResult.data[i].PrintCount = (objResult.data[i].BLPrint==1?1:0) + (blnIsFirst==true?1:0);
                            }

                            objResult.data[i].Piece = objResult.data[i].OOI_Piece;
                            objResult.data[i].Weight = objResult.data[i].OOI_Weight;
                            objResult.data[i].ChargeWeight = objResult.data[i].OOI_ChargeWeight;
                        }
                    }
                }

                this.ctrTable.arrData = objResult.data;                
            });
        },
        exportExcel:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportDMFin?token="+localStorage.getItem("strToken")+"&Where=" + JSON.stringify(this.ctrTable.objParam.Where);            
        }            
    }
}

</script>

<style scoped>

</style>
