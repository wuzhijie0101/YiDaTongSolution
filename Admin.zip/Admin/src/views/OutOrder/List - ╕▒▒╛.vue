<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                <template v-if="BizParam.C_Id==1002">
                    <el-select v-model="ctrTable.objParam.Where.ECAgent.strValue" clearable placeholder="申报主体" style="width:90px;">
                        <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_ECAgent" :label="objItem.Name" :value="objItem.Value"></el-option>
                    </el-select>
                </template>
                
                <el-select v-show="BizParam.C_Id!=1003" v-model="ctrTable.objParam.Where.CC_Id.strValue" filterable clearable placeholder="所属客户" style="width: 100px;">
                    <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(BizParam.C_Id)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.State.strValue" clearable placeholder="状态" style="width:120px;">
                    <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_State" :label="objItem.Name" :value="objItem.Value"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.AL_Id.strValue" filterable clearable placeholder="所属航线" style="width: 120px;">
                    <el-option v-for="objItem in $store.state.AirLine.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>
                <el-select v-model="ctrTable.objParam.Where.F_Id.strValue" filterable clearable placeholder="航班号" style="width: 160px;">
                    <el-option v-for="objItem in $store.state.Flight.arrData" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                </el-select>
                <el-input v-model="ctrTable.objParam.Where.Number.strValue" clearable placeholder="空运单号" @change="search();" style="width:100px"></el-input>                                
                

                <el-popover placement="bottom" trigger="click">
                    <div class="search_mini">
                        <el-input v-model="ctrTable.objParam.Where.GoodsName.strValue" clearable placeholder="品名关键字" @change="search();" style="width:120px"></el-input>
                
                        <el-input v-model="ctrTable.objParam.Where.VirNumber.strValue" clearable placeholder="虚拟单号" @change="search();" style="width:100px"></el-input>
                        <el-select v-model="ctrTable.objParam.Where.Type.strValue" clearable placeholder="货物类型" style="width:95px;">
                            <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_Type" :label="objItem.Name" :value="objItem.Value"></el-option>
                        </el-select>
                        <el-select v-model="ctrTable.objParam.Where.DirectOrder.strValue" clearable placeholder="直单分单" style="width:95px;">
                            <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_DirectOrder" :label="objItem.Name" :value="objItem.Value"></el-option>
                        </el-select>
                        <el-select v-model="ctrTable.objParam.Where.IsEnterSize.strValue" clearable placeholder="分单录尺寸" style="width:100px;">
                            <el-option v-for="objItem in $store.state.Dictionary.objMapKey.Is" :label="objItem.Name" :value="objItem.Value"></el-option>
                        </el-select>
                        <el-select v-model="ctrTable.objParam.Where.E_IdEdit.strValue" filterable clearable placeholder="编辑员" style="width: 100px;">
                            <el-option v-for="objItem in $store.state.Employee.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                    </div>
                    <template slot="reference">
                        <span style="cursor: pointer;">更多条件</span>
                    </template>
                </el-popover>

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-button-group>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,1)" type="success" size="small" icon="el-icon-circle-plus-outline" @click="edit(null);">新增</el-button>
                    <!-- <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,2)" type="success" size="small" icon="el-icon-edit-outline" @click="edit(ctrTable.objCurrentRow.Id, null);">编辑</el-button>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,4)" type="danger" size="small" icon="el-icon-circle-close-outline" @click="deleteData(ctrTable.objCurrentRow.Id)">删除</el-button> -->
                </el-button-group>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">
                <el-table-column prop="Id" label="编号" width="60">
                    <template slot-scope="scope">
                        <span class="hc_button-text" @click="openOutOrderDetail(scope.row.Id);">{{scope.row.Id}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="State" label="状态" width="120" column-key="OutOrder_State" :formatter="$lib.Element.Table.formatter"></el-table-column>                                
                <el-table-column :prop="CC_IdKey" label="所属客户" width="80" :formatter="$lib.Element.Table.fmtCompanyCustomerName"></el-table-column>
                <el-table-column prop="AL_Id" label="所属航线" width="100" :formatter="$lib.Element.Table.fmtAirLineName"></el-table-column>
                <el-table-column prop="F_Id" label="航班" width="140" :formatter="$lib.Element.Table.fmtFlightName"></el-table-column>
                <el-table-column prop="Number" label="空运单号" width="80">
                    <template slot-scope="scope">
                        <span class="hc_button-text" @click="openOutOrderDetail(scope.row.Id);">{{scope.row.Number}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="VirNumber" label="虚拟单号" width="100"></el-table-column>
                <el-table-column prop="Type" label="货物类型" width="75" column-key="OutOrder_Type" :formatter="$lib.Element.Table.formatter"></el-table-column>                

                <el-table-column prop="IsBulkyCargo" label="是否抹泡" width="75" column-key="Is" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="DirectOrder" label="直单分单" width="75" column-key="OutOrder_DirectOrder" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="IsEnterSize" label="分单录尺寸" width="85" column-key="Is" :formatter="$lib.Element.Table.formatter"></el-table-column>

                <el-table-column prop="PrePiece" label="预录件数" width="75" align="right"></el-table-column>
                <el-table-column prop="PreVolume" label="预录体积" width="75" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>
                <el-table-column prop="PreWeight" label="预录重量" width="75" align="right"></el-table-column>
                <el-table-column prop="Piece" label="实收件数" width="75" align="right"></el-table-column>
                <el-table-column prop="Volume" label="实收体积" width="75" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>
                <el-table-column prop="Weight" label="实收重量" width="75" align="right"></el-table-column>
                <el-table-column prop="ChargeWeight" label="计费重量" width="75" align="right"></el-table-column>
                
                <template v-if="BizParam.C_Id==1002">
                    <el-table-column prop="ECAgent" label="申报主体" width="75" column-key="OutOrder_ECAgent" :formatter="$lib.Element.Table.formatter"></el-table-column>
                    <el-table-column prop="ECRemark" label="电商备注" width="200px" show-overflow-tooltip></el-table-column>
                </template>

                <el-table-column prop="AgentName" label="客户简称" width="75"></el-table-column>
                <el-table-column prop="ToCityCode" label="目的港" width="60"></el-table-column>
                <el-table-column prop="ChangeToCityCode" label="中转目的港" width="85"></el-table-column>
                <el-table-column prop="ChangeACCode" label="中转航司" width="75"></el-table-column>
                <el-table-column prop="ToCityName" label="目的港全称" width="100"></el-table-column>
                <el-table-column prop="GoodsName" label="品名" width="100"></el-table-column>                
                <el-table-column prop="IsOfficeGoods" label="公务货" width="60" column-key="Is" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="WeightCharge" label="货物运费" width="80" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>
                <el-table-column prop="OtherCharge" label="其他费用" width="80" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>
                <el-table-column prop="TotalCharge" label="费用合计" width="80" align="right" :formatter="$lib.Element.Table.fmtFixed2"></el-table-column>

                <el-table-column prop="CancelState" label="取消前状态" width="120" column-key="OutOrder_State" :formatter="$lib.Element.Table.formatter"></el-table-column>
                <el-table-column prop="SystemRemark" label="系统备注" width="200px" show-overflow-tooltip></el-table-column>
                <el-table-column prop="E_IdEdit" label="编辑员" width="65" :formatter="$lib.Element.Table.fmtEmployeeName"></el-table-column>
                <el-table-column prop="E_Id" label="创建员" width="65" :formatter="$lib.Element.Table.fmtEmployeeName"></el-table-column>
                <el-table-column prop="UpdateTime" label="更新时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                <el-table-column prop="CreateTime" label="创建时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>

                <el-table-column label="操作" width="80" fixed="right">
                    <template slot-scope="scope">
                        <!-- <span v-show="scope.row.DirectOrder==1" class="hc_button-text" @click="edit(scope.row.Id);">直改分</span> -->
                        <span v-if="$lib.Sys.hasPower(PM_Id,2)" v-show="((BizParam.C_Id==1004 && scope.row.State<=35) || scope.row.State==1 || scope.row.State==10 || scope.row.State==31) && BizParam.C_Id!=1000" class="hc_button-text" @click="edit(scope.row.Id);">编辑</span>
                        <span v-if="$lib.Sys.hasPower(PM_Id,4)" v-show="(scope.row.State==1 || scope.row.State==10 || scope.row.State==31) && BizParam.C_Id!=1000" class="hc_button-text" @click="deleteData(scope.row.Id);">删除</span> 
                    </template>
                </el-table-column>

                <!-- <el-table-column prop="Mobile" label="手机" width="110"></el-table-column>
                <el-table-column prop="Name" label="姓名" width="100"></el-table-column>
                <el-table-column prop="Sex" label="性别" width="60" column-key="Sex" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Sex')" filter-placement="bottom-end"></el-table-column>                                

                <el-table-column prop="Remark" label="备注" width="200px" show-overflow-tooltip></el-table-column>
                <el-table-column prop="Enable" label="启用" width="60" column-key="Enable" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Enable')" filter-placement="bottom-end"></el-table-column>                                
                <el-table-column prop="UpdateTime" label="更新时间" width="150" sortable="custom" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                <el-table-column prop="CreateTime" label="创建时间" width="150" :formatter="$lib.Element.Table.fmtTime"></el-table-column> -->
            </el-table>
            <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
        </div>
    </div>    
</template>

<script>
import OutOrderEdit from '@/views/OutOrder/Edit.vue';
// import OutOrderUpdateDirect from '@/views/OutOrder/UpdateDirect.vue';
import OutOrderDetail from '@/views/OutOrder/Detail.vue';

export default {
    data: function() {
        return{
            PM_Id: null,

            C_IdKey: "",
            CC_IdKey: "",
            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Id desc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {                                
                        "C_Id": { "strField": "C_Id", "strCondition": "=", "strValue": (this.BizParam.C_Id==1000?"":this.BizParam.C_Id), "strSingleQuotes": "" },
                        "CC_Id": { "strField": "CC_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        // "CC_IdKJ": { "strField": "CC_IdKJ", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        // "CC_IdKF": { "strField": "CC_IdKF", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        // "CC_IdDM": { "strField": "CC_IdDM", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        
                        "ECAgent": { "strField": "ECAgent", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },

                        "State": { "strField": "State", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "Number": { "strField": "Number", "strCondition": "like", "strValue": "", "strSingleQuotes": "'" },
                        "VirNumber": { "strField": "VirNumber", "strCondition": "like", "strValue": "", "strSingleQuotes": "'" },
                        "Type": { "strField": "Type", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "DirectOrder": { "strField": "DirectOrder", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "IsEnterSize": { "strField": "IsEnterSize", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "GoodsName": { "strField": "GoodsName", "strCondition": "like", "strValue": "", "strSingleQuotes": "'" },
                        "E_IdEdit": { "strField": "E_IdEdit", "strCondition": "=", "strValue": "", "strSingleQuotes": "" }                    
                    },
                    OrderBy: "Id desc"
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
        BizParam:{
            type: Object,
            default: null
        }
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
            return this.ctrTable.objParam.Where.ECAgent.strValue + this.ctrTable.objParam.Where.State.strValue + this.ctrTable.objParam.Where.CC_Id.strValue + this.ctrTable.objParam.Where.AL_Id.strValue + this.ctrTable.objParam.Where.F_Id.strValue + this.ctrTable.objParam.Where.Type.strValue + this.ctrTable.objParam.Where.DirectOrder.strValue + this.ctrTable.objParam.Where.IsEnterSize.strValue + this.ctrTable.objParam.Where.E_IdEdit.strValue;
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {
        switch(this.BizParam.C_Id){
            case 1000:
                this.PM_Id = 123;
                break;
            case 1001:  // 客服
                this.PM_Id = 108;
                this.C_IdKey = "C_IdKF";
                this.CC_IdKey = "CC_IdKF";
                this.ctrTable.objParam.Where.C_Id.strField = "C_IdKF";
                this.ctrTable.objParam.Where.CC_Id.strField = "CC_IdKF";
                break;
            case 1002:  // 跨境电商
                this.PM_Id = 109;
                this.C_IdKey = "C_IdKJ";
                this.CC_IdKey = "CC_IdKJ";
                this.ctrTable.objParam.Where.C_Id.strField = "C_IdKJ";
                this.ctrTable.objParam.Where.CC_Id.strField = "CC_IdKJ";
                break;
            case 1003:  // 前置仓
                this.PM_Id = 111;
                this.C_IdKey = "C_IdQZC";       
                this.CC_IdKey = "CC_Id";          
                this.ctrTable.objParam.Where.C_Id.strField = "C_IdQZC";
                break;
            case 1004:  // 地面
                this.PM_Id = 110;
                this.C_IdKey = "C_IdDM";
                this.CC_IdKey = "CC_IdDM";
                this.ctrTable.objParam.Where.C_Id.strField = "C_IdDM";
                this.ctrTable.objParam.Where.CC_Id.strField = "CC_IdDM";
                break;
            case 1005:  // 组板
                break;
        }

        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){            
            this.search();            
        },

        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            if (blnIsReload != true) {
                this.ctrTable.objParam.Page = 1;
            }            
            // this.ctrTable.objParam.Where.Sex.strValue = "" + this.ctrTable.objParam.Where.Sex.arrValue;
            // this.ctrTable.objParam.Where.Enable.strValue = "" + this.ctrTable.objParam.Where.Enable.arrValue;           

            this.$ajax.get('/Admin/OutOrder/GetPage', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == true) {
                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                    if (this.ctrTable.nTotal > 0) {
                        this.$refs.tblList.setCurrentRow(this.ctrTable.arrData[0]);
                    }
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });
        },
        // edit:function(nId){ // 新增或编辑     
        //     if(nId==null){
        //         this.$store.commit('TabMenu/addTabIdentity', {strTitle: '新增货运单', strPath: 'OutOrderEdit', jobjBizParam: {Id:nId, TabId:nId, C_Id:this.BizParam.C_Id}});
        //     }
        //     else{
        //         this.$store.commit('TabMenu/addTab', {strId: nId, strTitle: '编辑' + nId, strPath: 'OutOrderEdit', jobjBizParam: {Id:nId, TabId:nId, C_Id:this.BizParam.C_Id}});
        //     }
        // },
        edit:function(nId){ // 新增或编辑     
            this.$layer.iframe({
                content: {
                    content: OutOrderEdit,
                    parent: this,
                    data:{ Id:nId,C_Id:this.BizParam.C_Id } 
                },
                area:['95%','95%'],
                shadeClose: false,
                title: (nId==null?'新增':'编辑')
            });
        },
        deleteData: function (nId) { // 删除,函数不取名为delete是因为vue的@click绑定函数名称不能为关键字,而delete为关键字            
            this.$lib.CURD.delete(this, "/Admin/OutOrder/Delete?Id=" + nId, objResult => {         
                for(var i = 0; i < this.ctrTable.arrData.length; i++){
                    if(nId == this.ctrTable.arrData[i].Id){
                        this.ctrTable.arrData.splice(i, 1);                        
                        break;
                    }
                }
                // this.search(true);
            });
        },
        // openOutOrderUpdateDirect:function(nId){ // 新增或编辑     
        //     this.$layer.iframe({
        //         content: {
        //             content: OutOrderUpdateDirect,
        //             parent: this,
        //             data:{ Id:nId } 
        //         },
        //         area:['95%','95%'],
        //         shadeClose: false,
        //         title: "直单改分单"
        //     });
        // },
        
        openOutOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: OutOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['800px','90%'],
                shadeClose: false,
                title: '货运单详情'
            });
        },

        
        ctrTable_sortChange: function (objSort) {   // 表格排序
            this.$lib.Element.Table.sortChange(objSort, this);
        },
        ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
            this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
        },
        ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
            this.$lib.Element.Table.selectionChange(selection, this);
        },
        ctrTable_filterChange: function (objFilters) {    // 列过滤
            this.$lib.Element.Table.filterChange(objFilters, this);            
        },

        ctrPage_sizeChange: function (nValue) { // 页码改变
            this.$lib.Element.Page.sizeChange(nValue, this);         
        },
        ctrPage_currentChange: function (nValue) {  // 当前页改变 
            this.$lib.Element.Page.currentChange(nValue, this);
        }
    }
}

</script>

<style scoped>

</style>
