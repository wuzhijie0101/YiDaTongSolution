<template>
    <div style="width:100%; height: 100%;">
        <!-- <div class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row hc_form form-size-small">
                
            </div>
        </div> -->

        <validation-observer ref="form" tag="div" class="hc_container-fluid hc_form-pc" style="padding: 10px;">
            <div class="row">
                <div class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属部门</div>
                    <div class="form-item-bd">{{$store.state.Company.objMapping[objData.C_Id].Name}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <div v-if="Mode==1" class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属客户</div>                    
                    <validation-provider tag="div" name="所属客户" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.CC_IdKey" filterable placeholder="请选择" style="width: 100%;" @change="changeCompanyCustomer">
                            <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(objData.C_IdKey)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>
                <div v-else class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属客户</div>                    
                    <validation-provider tag="div" name="所属客户" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.CC_Id" filterable placeholder="请选择" style="width: 100%;" @change="changeCompanyCustomer">
                            <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(objData.C_Id)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>

                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属航线</div>                    
                    <validation-provider tag="div" name="所属航线" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.AL_Id" filterable placeholder="请选择" :disabled="objData.Id!=null" style="width: 100%;" @change="changeAirLine">
                            <el-option v-for="objItem in $store.state.AirLine.getByEnable(1)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd">航班号</div>                    
                    <!-- <validation-provider tag="div" name="航班号" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.F_Id" filterable placeholder="请选择" clearable style="width: 100%;">
                            <el-option v-for="objItem in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                     -->
                    <div class="form-item-bd">
                        <el-select v-model="objData.F_Id" filterable placeholder="请选择" clearable style="width: 100%;">
                            <el-option v-for="objItem in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                        </el-select>
                    </div>
                    <div class="form-item-ft"></div>
                </div>


                <div class="col-57 form-item">
                    <div class="form-item-hd">状态</div>                    
                    <div class="form-item-bd">
                        <template v-if="objData.C_Id==1001 || objData.C_Id==1004">
                            <el-select v-model="objData.State" :disabled="objData.Id!=null" style="width: 100%;">
                                <el-option label="待发车" :value="1"></el-option>
                                <!-- <el-option label="运输中" :value="3"></el-option> -->                                                                                  
                                <el-option label="待货车卸货" :value="31"></el-option>                            
                            </el-select>
                        </template>
                        <template v-else>
                            <el-select v-model="objData.State" style="width: 100%;" :disabled="Mode==1">
                                <el-option label="待报海关" :value="10"></el-option>
                            </el-select>
                        </template>
                        
                        <div class="form-error"></div>
                    </div>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.VirNumber" name="虚拟单号"></hc-text-item>
                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd">空运单号</div>                    
                    <validation-provider tag="div" name="空运单号" class="form-item-bd" v-slot="{ errors }">
                        {{objData.PrimaryCode}} <input class="hc_text" v-model="objData.Number" placeholder="请输入" autocomplete="off" style="width: 80%;" />                        
                    </validation-provider>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.Type" name="货物类型" disabled :data="$store.state.Dictionary.objMapKey.OutOrder_Type"></hc-radio-item>
            </div>
            <div class="row">
                <hc-text-item class="col-57" type="text" v-model="objData.ToCityCode" validate="required" name="目的港三字码"></hc-text-item>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.ChangeToCityCode" name="中转目的港"></hc-text-item>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.ChangeACCode" name="中转航司二字码"></hc-text-item>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.ToCityName" validate="required" name="目的港全称"></hc-text-item>                

                <hc-radio-item class="col-57" v-model="objData.Currency" name="币种" :data="$store.state.Dictionary.objMapKey.Currency"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.WeightChargePayMethod" name="运费支付方式" :data="$store.state.Dictionary.objMapKey.OutOrder_PayMethod"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.OtherChargePayMethod" name="其他费用支付方式" :data="$store.state.Dictionary.objMapKey.OutOrder_PayMethod"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.DeclaredValue" name="海关申报价值" :data="$store.state.Dictionary.objMapKey.OutOrder_DeclareValue"></hc-radio-item>                

                <hc-textarea-item class="col-240" v-model="objData.ACAccountInfor" name="航司结算代码"></hc-textarea-item>

                <div class="col-240 form-item">
                    <div class="form-item-hd">航司其他费用</div>
                    <div class="form-item-bd">                        
                        <div v-for="(objItem,i) in arrACOtherCharge" style="display: inline-block; margin-right: 15px;">
                            <input type="text" class="hc_text" v-model="objItem.Name" placeholder="费用名称" style="width: 80px; border-bottom: 1px solid #cdcdcd;" />：
                            <input type="number" class="hc_text" v-model="objItem.Value" placeholder="费用" style="width: 80px; border-bottom: 1px solid #cdcdcd;" />
                            <span class="hc_button-text" @click="removeItemACOC(i);">删除</span>
                        </div>
                        <span class="hc_button hc_button-primary hc_button-small" @click="addItemACOC();">增加其他费用项</span>
                    </div>
                </div>

                <hc-radio-item class="col-57" v-model="objData.IsBulkyCargo" name="是否抹泡" :data="$store.state.Dictionary.objMapKey.Is"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.DirectOrder" name="直单分单" :disabled="objData.Id!=null" @change="changeDirectOrder" :data="$store.state.Dictionary.objMapKey.OutOrder_DirectOrder"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item v-show="objData.DirectOrder==2" class="col-57" v-model="objData.IsEnterSize" name="分单是否录尺寸" :disabled="objData.Id!=null" @change="changeIsEnterSize" :data="$store.state.Dictionary.objMapKey.Is"></hc-radio-item>
                <div class="col-4"></div>
                <div v-show="objData.State==1" class="col-57 form-item">
                    <div class="form-item-hd">前置仓安检</div>                    
                    <div class="form-item-bd">
                        <el-select v-model="objData.IsSecurityCheck" placeholder="请选择" clearable style="width: 100%;">
                            <el-option v-for="objItem in $store.state.Dictionary.objMapKey.Is" :label="objItem.Name" :value="parseInt(objItem.Value)"></el-option>
                        </el-select>                        
                    </div>                    
                    <div class="form-item-ft"></div>
                </div>
            </div>
            <div v-if="objData.State==10" class="row">
                <hc-datetime-item class="col-57" type="datetime-local" v-model="objData.SendInforTime" validate="required" name="送报关资料时间" placeholder="请选择"></hc-datetime-item>                
                <!-- <input type="datetime-local" class="hc_text" v-model="objData.SendInforTime" /> -->
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.CarNumber" name="车牌号"></hc-text-item>
                <div class="col-4"></div>
                <hc-number-item class="col-57" v-model="objData.PackageCount" validate="required|numeric" name="清单数量"></hc-number-item>
                <div class="col-4"></div>
                <hc-number-item class="col-57" v-model="objData.ReportMoney" validate="required|dec2|min_value:0" name="申报金额"></hc-number-item>                

                <hc-radio-item class="col-57" v-model="objData.TransportMode" name="运输方式" :data="$store.state.Dictionary.objMapKey.OutOrder_TransportMode"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.GroundAgentKJ" name="地面代理" :data="$store.state.Dictionary.objMapKey.OutOrder_GroundAgentKJ"></hc-radio-item>                
                <!-- <div class="col-57 form-item">
                    <div class="form-item-hd">地面代理</div>                    
                    <div class="form-item-bd">
                        <label class="hc_checkbox">
                            <input type="checkbox" v-model="objData.C_IdDM" :value="1004" name="地面代理" /> <span>璟盛</span>
                        </label>
                    </div>                    
                    <div class="form-item-ft"></div>
                </div> -->
                <div class="col-4"></div>
            </div>
            <div class="row">
                <hc-text-item class="col-240" type="text" v-model="objData.Remark" name="备注"></hc-text-item>
            </div>
            <!-- <div>车牌号、空车重量、司机、身份证、手机</div> -->

            <div class="row">
                <div class="col-240" style="margin-top: 10px;">
                    <table class="hc-table hc_form-small" style="width:100%;">
                        <thead>
                            <tr style="line-height: 28px; font-weight: bold;">
                                <th style="width: 1%;"></th>
                                <th style="width: 10%;">单号</th>
                                <th style="width: 12%;">品名</th>      
                                <th style="width: 21%;">尺寸</th>
                                <th style="width: 8%;">数据</th>
                                <th style="width: 8%;">计费重量</th>
                                <th style="width: 8%;">运价</th>
                                <th style="width: 16%;">收寄件地址</th>
                                <th style="width: 16%;">备注通知</th>                                
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="vertical-align:middle;">主单</td>
                                <td style="vertical-align:middle;">{{objData.PrimaryCode+'-'+objData.Number}}</td>
                                <td>
                                    <div>
                                        <div><span style="color: red;">*</span>品名：</div>
                                        <validation-provider tag="div" name="品名" class="form-item-bd" rules="required" v-slot="{ errors }">
                                            <input type="text" v-model="objData.GoodsName" class="hc_text hc_text-border" placeholder="请输入" />
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>

                                    <div style="margin-top: 15px;">
                                        <div><span class="form-required">*</span>包装英文</div>
                                        <validation-provider tag="div" name="包装英文" class="form-item-bd" rules="required" v-slot="{ errors }">
                                            <el-select v-model="objData.BP_Id" filterable placeholder="请选择" style="width: 100%;" size="mini">
                                                <el-option v-for="objItem in $store.state.BasePackage.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                                            </el-select>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>                                
                                </td>
                                <td>
                                    <div v-show="objData.DirectOrder==1 || objData.IsEnterSize==0" style="margin-bottom: 5px;">
                                        <input type="text" v-model="strSizeFormat" class="hc_text hc_text-border" placeholder="长*宽*高/件数" style="width: 116px;" /> <span class="hc_button-text" @click="addItemOOS();" style="font-weight: bold;">添加尺寸</span>
                                    </div>
                                    
                                    <template v-if="objData.DirectOrder==2 && objData.IsEnterSize==1">
                                        <span v-for="(objItem,i) in arrOutOrderSize">
                                            {{objItem.Long + '*' + objItem.Width + '*' + objItem.Height + '/' + objItem.Piece}};
                                        </span>
                                    </template>
                                    <template v-else>
                                        <div v-for="(objItem,i) in arrOutOrderSize" style="max-width: 130px; width: 100%; display: inline-block;">
                                            <!-- <validation-provider tag="div" name="尺寸" rules="required" v-slot="{ errors }" style="width: 49%; margin-bottom: 5px; display:inline-block;">
                                                <input type="text" v-model="objItem.Format" class="hc_text hc_text-border" placeholder="长*宽*高/件数" style="width: 90%;" /><span class="hc_button-text" @click="removeItemOOS(i)">X</span>
                                                <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                            </validation-provider> -->
                                            <validation-provider tag="span" name="长" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;">
                                                <hc-number type="text" v-model="objItem.Long" @change="changeMasterSize(objItem);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="长"></hc-number>
                                            </validation-provider><validation-provider tag="span" name="宽" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;" >
                                                <hc-number type="text" v-model="objItem.Width" @change="changeMasterSize(objItem);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="宽"></hc-number>                                            
                                            </validation-provider><validation-provider tag="span" name="高" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;">
                                                <hc-number type="text" v-model="objItem.Height" @change="changeMasterSize(objItem);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="高"></hc-number>                                           
                                            </validation-provider><validation-provider tag="span" name="件数" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 35px; margin-bottom: 5px;">
                                                <!-- <input type="text" v-model="objItem.Piece" @change="changeMasterSize(objItem);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="件数" /> -->
                                                <hc-number type="text" v-model="objItem.Piece" @change="changeMasterSize(objItem);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="件数"></hc-number>
                                            </validation-provider><span class="hc_button-text" @click="removeItemOOS(i)" :style="(i%2==0?'margin-right: 1%;':'')">X</span>
                                            <!-- <input type="text" v-model="objItem.Long" class="hc_text hc_text-border" placeholder="长" style="width: 25px;" /><input type="text" v-model="objItem.Width" class="hc_text hc_text-border" placeholder="宽" style="width: 25px; margin-left: 2px;" /><input type="text" v-model="objItem.Height" class="hc_text hc_text-border" placeholder="高" style="width: 25px; margin-left: 2px;" /><input type="text" v-model="objItem.Piece" class="hc_text hc_text-border" placeholder="件数" style="width: 35px; margin-left: 2px;" /><span class="hc_button-text" @click="removeItemOOS(i)">X</span> -->                                        
                                        </div>  
                                    </template>
                                                                      
                                    
                                    <!-- <input type="text" class="hc_text hc_text-border" placeholder="请输入" style="width: 49%; margin-bottom: 5px;" />
                                    <input type="text" class="hc_text hc_text-border" placeholder="请输入" style="width: 49%; margin-bottom: 5px;" />
                                    <input type="text" class="hc_text hc_text-border" placeholder="请输入" style="width: 49%; margin-bottom: 5px;" />
                                    <input type="text" class="hc_text hc_text-border" placeholder="请输入" style="width: 49%; margin-bottom: 5px;" /> -->                                                                        
                                </td>
                                <td>
                                    <div>件数:{{objData.Piece}}</div>
                                    <div style="margin-top: 8px;">方数:{{objData.Volume}}</div>
                                    <div style="margin-top: 8px;">重量:
                                        <validation-provider tag="span" name="重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            <hc-number type="text" v-model="objData.Weight" class="hc_text hc_text-border" @change="calcMasterChargeWeight();" :disabled="(objData.DirectOrder==2 && objData.IsEnterSize==1)" placeholder="请输入" style="width: 50%;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 14px;">
                                        <div>体积换算标准</div>
                                        <!-- <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_ConvertStandard">                
                                            <input type="radio" v-model="objData.ConvertStandard" :value="parseInt(objItem.Value)" name="体积换算标准" /><span>{{objItem.Name}}</span>                                            
                                        </label> -->

                                        <!-- <el-select v-model="objData.ConvertStandard" placeholder="请选择" clearable style="width: 100%;" size="mini">
                                            <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_ConvertStandard" :key="objItem.Id" :label="objItem.Name" :value="parseInt(objItem.Value)"></el-option>
                                        </el-select> -->
                                        <el-select v-model="objData.ConvertStandard" placeholder="请选择" @change="calcMasterChargeWeight();" style="width: 100%;" size="mini">
                                            <el-option label="166.666" :value="166.666"></el-option>
                                            <el-option label="167" :value="167"></el-option>
                                        </el-select>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>计费自填：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objData.IsSelfCharge" :value="parseInt(objItem.Value)" name="计费靠打" @change="calcMasterChargeWeight();" /><span>{{objItem.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>计费重量：</div>
                                        <validation-provider tag="div" name="计费重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            <hc-number type="text" v-model="objData.ChargeWeight" class="hc_text hc_text-border" placeholder="请输入" :disabled="objData.IsSelfCharge==0"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>公务货：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objData.IsOfficeGoods" :value="parseInt(objItem.Value)" name="公务货" /><span>{{objItem.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>运价：</div>
                                        <validation-provider tag="div" name="运价" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }">
                                            <hc-number type="text" v-model="objData.UnitPrice" class="hc_text-mini" placeholder="请输入"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>                                        
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>寄件地址：</div>
                                        <textarea v-model="objData.FromAddress" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>收件地址：</div>
                                        <textarea v-model="objData.ToAddress" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>客户备注：</div>
                                        <textarea v-model="objData.CustomerRemark" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>客户通知：</div>
                                        <textarea v-model="objData.CustomerNotify" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                </td> 
                            </tr>                           



                            <tr v-for="(objItem,i) in arrOutOrderItem">
                                <td style="vertical-align:middle;">分单{{i+1}}<span class="hc_button-text" style="margin-top: 15px;" @click="removeItem(i)">删除</span></td>
                                <td>
                                    <input type="text" v-model="objItem.Number" class="hc_text hc_text-border" placeholder="分单号" />
                                    <div style="margin-top: 8px;">
                                        <div>录预配运抵：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objItem.IsInputPreplan" :value="parseInt(objItemDic.Value)" :name="'录预配运抵'+i" /><span>{{objItemDic.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <div>提单打印：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.OutOrderItem_BLPrint">                
                                                <input type="radio" v-model="objItem.BLPrint" :value="parseInt(objItemDic.Value)" :name="'提单打印'+i" /><span>{{objItemDic.Name}}</span>
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <div>虚拟分单：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objItem.IsVirtually" :value="parseInt(objItemDic.Value)" :name="'虚拟分单'+i" /><span>{{objItemDic.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div><span style="color: red;">*</span>品名：</div>
                                        <validation-provider tag="div" name="品名" class="form-item-bd" rules="required" v-slot="{ errors }">
                                            <input type="text" v-model="objItem.GoodsName" class="hc_text hc_text-border" placeholder="请输入" />
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <div v-show="objData.IsEnterSize==1" style="margin-bottom: 5px;">
                                        <input type="text" v-model="objItem.strSizeFormat" class="hc_text hc_text-border" placeholder="长*宽*高/件数" style="width: 116px;" /> <span class="hc_button-text" @click="addItemChildOOS(objItem);" style="font-weight: bold;">添加尺寸</span>
                                    </div>
                                    
                                    <div v-for="(objItemChildOOS,j) in objItem.arrOutOrderSize" style="max-width: 130px; width: 100%; display: inline-block;">
                                        <validation-provider tag="span" name="长" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;">
                                            <hc-number type="text" v-model="objItemChildOOS.Long" @change="changeSlaveSize(objItem,j);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="长"></hc-number>
                                        </validation-provider><validation-provider tag="span" name="宽" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;" >
                                            <hc-number type="text" v-model="objItemChildOOS.Width" @change="changeSlaveSize(objItem,j);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="宽"></hc-number>                                            
                                        </validation-provider><validation-provider tag="span" name="高" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 25px; margin-right: 2px; margin-bottom: 5px;">
                                            <hc-number type="text" v-model="objItemChildOOS.Height" @change="changeSlaveSize(objItem,j);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="高"></hc-number>                                           
                                        </validation-provider><validation-provider tag="span" name="件数" rules="required|numeric" v-slot="{ errors }" style="display: inline-block; width: 35px; margin-bottom: 5px;">                                            
                                            <hc-number type="text" v-model="objItemChildOOS.Piece" @change="changeSlaveSize(objItem,j);" :class="'hc_text hc_text-border' + (errors[0]?' form-invalid':'')" placeholder="件数"></hc-number>
                                        </validation-provider><span class="hc_button-text" @click="removeItemChildOOS(objItem,j)" :style="(j%2==0?'margin-right: 1%;':'')">X</span>
                                    </div>

                                    <!-- <template v-for="(objItemChildOOS,j) in objItem.arrOutOrderSize">
                                        <input type="text" v-model="objItemChildOOS.Format" class="hc_text hc_text-border" placeholder="长*宽*高/件数" style="width: 44%; margin-bottom: 5px;" /><span class="hc_button-text" @click="removeItemChildOOS(objItem,j)">X</span>
                                    </template>
                                    <div v-show="objData.IsEnterSize==1" class="hc_button-text" @click="addItemChildOOS(objItem);" style="font-weight: bold;">添加尺寸</div>                                     -->
                                </td>
                                <td>
                                    <div>件数:
                                        <validation-provider tag="span" name="件数" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            <!-- <input type="text" v-model="objItem.Piece" class="hc_text hc_text-border" :disabled="objData.IsEnterSize==1" placeholder="请输入" style="width: 60%;" /> -->
                                            <hc-number type="text" v-model="objItem.Piece" class="hc_text hc_text-border" :disabled="objData.IsEnterSize==1" placeholder="请输入" style="width: 100%;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>

                                    </div>
                                    <div style="margin-top: 10px;">方数:
                                        <validation-provider tag="span" name="方数" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }">
                                            <hc-number type="text" v-model="objItem.Volume" class="hc_text hc_text-border" @change="calcSlaveChargeWeight(objItem);" :disabled="objData.IsEnterSize==1" placeholder="请输入" style="width: 100%;"></hc-number>
                                            <!-- <input type="text" v-model="objItem.Volume" class="hc_text hc_text-border" @change="calcSlaveChargeWeight(objItem);" :disabled="objData.IsEnterSize==1" placeholder="请输入" style="width: 60%;" /> -->
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 10px;">重量:
                                        <validation-provider tag="span" name="重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            <hc-number type="text" v-model="objItem.Weight" class="hc_text hc_text-border" @change="calcSlaveChargeWeight(objItem);" placeholder="请输入" style="width: 100%;"></hc-number>
                                            <!-- <input type="text" v-model="objItem.Weight" class="hc_text hc_text-border" @change="calcSlaveChargeWeight(objItem);" placeholder="请输入" style="width: 60%;" /> -->
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <!-- <div>
                                        <div>是否自填：</div>
                                        <div>
                                            <label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objItem.IsSelfCharge" :value="parseInt(objItemDic.Value)" @change="calcSlaveChargeWeight(objItem);" :name="'是否自填'+i" /><span>{{objItemDic.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div> -->
                                    <div>
                                        <div>计费重量：</div>
                                        <validation-provider tag="div" name="计费重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            <!-- <input type="text" v-model="objItem.ChargeWeight" class="hc_text hc_text-border" placeholder="请输入" :disabled="objData.IsSelfCharge==0" /> -->
                                            <hc-number type="text" v-model="objItem.ChargeWeight" class="hc_text hc_text-border" :disabled="objData.IsSelfCharge==0" placeholder="请输入"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>运价：</div>
                                        <el-select v-model="objItem.UnitPriceChoose" placeholder="请选择" style="width: 100%;" size="mini">
                                            <el-option v-for="objItemDic in $store.state.Dictionary.objMapKey.OutOrderItem_UnitPriceChoose" :key="objItemDic.Id" :label="objItemDic.Name" :value="parseInt(objItemDic.Value)"></el-option>
                                        </el-select>                                        
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>寄件地址：</div>
                                        <textarea v-model="objItem.FromAddress" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>收件地址：</div>
                                        <textarea v-model="objItem.ToAddress" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>客户备注：</div>
                                        <textarea v-model="objItem.CustomerRemark" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <div>客户通知：</div>
                                        <textarea v-model="objItem.CustomerNotify" class="hc_textarea" cols="3"></textarea>
                                    </div>
                                </td> 
                            </tr>
                            <tr v-show="objData.DirectOrder==2">
                                <td></td>
                                <td colspan="8"><span class="hc_button hc_button-primary hc_button-small" @click="addItem();">增加分单</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center; margin-top: 10px;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        // TabId:{
        //     type: String,
        //     default: null
        // },
        layerid: {
            type: String,
            default: ""
        },
        C_Id:{
            type: Number,
            default: null
        },
        Mode:{
            type: Number,
            default: null
        },
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },            
            arrFlight:[],
            arrACOtherCharge:[],
            arrOutOrderSize:[],
            arrOutOrderItem:[],

            strSizeFormat: "",

            objDetail: {},
            objData: {
                Id: this.Id,
                C_Id: this.C_Id,                
                CC_Id: null,
                C_IdKey: null,      // 用于Mode=1
                CC_IdKey: null,     // 用于Mode=1
                State: null,
                AL_Id: null,
                F_Id: null,
                PrimaryCode: "",
                Number: "",
                VirNumber: "",
                Type: null,
                DataFrom: null,

                AgentName: "",
                AgentFullName: "",
                ToCityCode: "",
                ChangeToCityCode: "",
                ChangeACCode: "",
                ToCityName: "",
                Currency: null,
                WeightChargePayMethod: null,
                OtherChargePayMethod: null,
                DeclaredValue: null,
                ACAccountInfor: "",
                ACOtherCharge: "",

                GoodsName: "",
                BP_Id: null,
                Piece: null,
                Volume: null,
                Weight: null,
                // Piece: null,
                // Volume: null,
                // Weight: null,
                ConvertStandard: null,
                IsSelfCharge: null,
                ChargeWeight: null,
                IsOfficeGoods: null,
                UnitPrice: null,
                ToAddress: "",
                FromAddress: "",
                CustomerRemark: "",
                CustomerNotify: "",
                // WeightCharge: null,
                // OtherCharge: null,
                // TotalCharge: null,

                IsBulkyCargo: null,
                DirectOrder: null,
                IsEnterSize: null,
                Remark: "",
                
                // C_IdKF: null,
                // CC_IdKF: null,
                // C_IdKJ: null,
                // CC_IdKJ: null,                
                // C_IdDM: null,
                // CC_IdDM: null,

                SendInforTime: "",
                CarNumber: "",                
                PackageCount: null,
                ReportMoney: null,
                TransportMode: null,
                GroundAgentKJ: null,

                IsSecurityCheck: "",

                // CT_Id: null,
                // CD_Id: null,
                // CarNumber: "",
                // CarWeight: null,
                // DriverName: "",
                // DriverIdCard: "",
                // DriverMobile: "",

                
                ItemCount: 0,
                OOSCount: 0,

                DeleteIds: "",      // 更新时需要删除的项
                DeleteSizeIds: ""   // 更新时需要删除的项
            }            
        }
    },    
    computed: {
    },
    watch: {
        "objData.State": function(nNew, nOld){
            // this.objData.CarNumber = "";
            // this.objData.SendInforTime = "";
            // this.objData.PackageCount = null;
            // this.objData.ReportMoney = null;
            // this.objData.TransportMode = null;
            // this.objData.GroundAgentKJ = null;

            this.objData.IsSecurityCheck = "";

            // this.objData.CT_Id = null;
            // this.objData.CD_Id = null;            
            // this.objData.CarWeight = null;
            // this.objData.DriverName = "";
            // this.objData.DriverIdCard = "";
            // this.objData.DriverMobile = "";

            // switch(nNew){
            //     case 10: // 跨境电商
            //         this.objData.SendInforTime = this.$dayjs().format("YYYY-MM-DD HH:mm");
            //         this.objData.TransportMode = 1;
            //         this.objData.GroundAgentKJ = 1;
            //         break;
            //     case 1: // 待发车
            //         break;
            //     case 31:    // 待卸货
            //         break;
            // }
        }
    },
    created: function() {
        if(this.Mode == 1){ // 跨境电商完善数据            
            this.objData.C_IdKey = this.$store.state.jobjUser.C_Id;
        }
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){                  
            if(this.objData.Id == null){                                
                this.objData.DataFrom = 1;
                this.objData.Currency= 1;
                this.objData.WeightChargePayMethod = 1;
                this.objData.OtherChargePayMethod = 1;
                this.objData.DeclaredValue = 1;
                this.objData.ACOtherCharge = "[]";
                this.objData.Piece = 0;
                this.objData.Volume = 0;
                this.objData.Weight = 0;
                this.objData.ConvertStandard = 166.666;
                this.objData.IsSelfCharge = 0;
                this.objData.ChargeWeight = 0;
                this.objData.IsOfficeGoods = 0;
                this.objData.UnitPrice = 0;
                this.objData.IsBulkyCargo = 0;
                this.objData.DirectOrder = 1;
                // this.objData.IsEnterSize = 1;

                switch(this.objData.C_Id){
                    case 1002:  // 跨境电商     
                        this.objData.State = 10;                   
                        this.objData.Type = 2;
                        this.objData.SendInforTime = this.$dayjs().format("YYYY-MM-DD HH:mm");
                        this.objData.TransportMode = 1;
                        this.objData.GroundAgentKJ = 1;
                        break;
                    default:
                        this.objData.State = 1;                   
                        this.objData.Type = 1;
                        break;
                    // case 1001:  // 客服
                    //     break;
                    // case 1004:  // 地面
                    //     break;
                }
                
                this.startWatch();
            }
            else{
                this.$ajax.get('/Admin/OutOrder/GetDetail?Id=' + this.objData.Id).then(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }
                    this.objDetail = objResult;               
                    console.log(objResult);
                    for (var strKey in this.objData) {
                        switch (strKey) {
                            case "C_IdKey":
                                break;
                            case "CC_IdKey":
                                switch(this.objData.C_IdKey){
                                    case 1001:
                                        this.objData[strKey] = objResult.data[0]["CC_IdKF"];
                                        break;
                                    case 1004:
                                        this.objData[strKey] = objResult.data[0]["CC_IdDM"];
                                        break;
                                }
                                break;
                            case "ACOtherCharge":
                                this.arrACOtherCharge = JSON.parse(objResult.data[0][strKey]);
                                break;
                            case "SendInforTime":
                                this.objData[strKey] = this.$lib.Format.fmtTime(objResult.data[0][strKey]);
                                break;
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }
                    
                    if(this.objData.DirectOrder==1 || (this.objData.DirectOrder==2 && this.objData.IsEnterSize==0)){                        
                        for(var i = 0; i < objResult.extData.arrOutOrderSize.length; i++){
                            this.arrOutOrderSize.push(objResult.extData.arrOutOrderSize[i]);
                        }
                    }

                    if(this.objData.DirectOrder==2){
                        var nIndex;
                        for(var i = 0; i < objResult.extData.arrOutOrderItem.length; i++){
                            this.arrOutOrderItem.push(objResult.extData.arrOutOrderItem[i]);

                            nIndex = this.arrOutOrderItem.length - 1;
                            this.arrOutOrderItem[nIndex].strSizeFormat = "";
                            this.arrOutOrderItem[nIndex].arrOutOrderSize = [];  
                            if(this.objData.IsEnterSize==1){                                                                                          
                                for(var j = 0; j < objResult.extData.arrOutOrderSize.length; j++){                                    
                                    if(objResult.extData.arrOutOrderItem[i].Id == objResult.extData.arrOutOrderSize[j].OOI_Id){                                                                                
                                        this.arrOutOrderItem[nIndex].arrOutOrderSize.push(objResult.extData.arrOutOrderSize[j]);
                                    }
                                }
                            }                            
                        }

                        this.calcMasterSizeBySlave();
                    }

                    var objWhere = {
                        "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
                        "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                    }
                    this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                        for(var i = 0; i < objResult.data.length; i++){
                            objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                        }
                        this.arrFlight = objResult.data;
                    });                    
                    
                    this.startWatch(); 
                });
            }                             
        },
        save: function () {
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            // alert('test\r\ntest');
            // return;
            // console.log(this.objData.IsSecurityCheck);
            // return;            
            this.ctrForm.blnSubmit = true;        
            

            // switch(this.objData.C_Id){
            //     case 1001:
            //         this.objData.C_IdKF = this.objData.C_Id;
            //         this.objData.CC_IdKF = this.objData.CC_Id;

            //         this.objData.C_IdDM = 1004;
            //         break;
            //     case 1002:
            //         this.objData.C_IdKJ = this.objData.C_Id;
            //         this.objData.CC_IdKJ = this.objData.CC_Id;

            //         if(this.objData.PrimaryCode == '071'){ // ET航线
            //             this.objData.C_IdKF = 1001;
            //         }
            //         if(this.objData.GroundAgentKJ==1){
            //             this.objData.C_IdDM = 1004;
            //         }

            //         break;
            //     case 1004:
            //         this.objData.C_IdDM = this.objData.C_Id;
            //         this.objData.CC_IdDM = this.objData.CC_Id;
            //         break;
            // }


                        
            if(this.objData.DirectOrder==2 && this.objData.IsEnterSize==1){
                var nPiece = 0;
                var dVolume = 0;
                var nWeight = 0;
                var nChargeWeight = 0;
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    nPiece += this.arrOutOrderItem[i].Piece;
                    dVolume += this.arrOutOrderItem[i].Volume;
                    nWeight += this.arrOutOrderItem[i].Weight;
                    nChargeWeight += this.arrOutOrderItem[i].ChargeWeight;
                }

                var strMessage = "";
                if(nPiece != this.objData.Piece){
                    strMessage += "分单件数" + nPiece + "与主单件数" + this.objData.Piece + "不相等;";
                }
                if(parseFloat(dVolume.toFixed(2)) != this.objData.Volume){
                    strMessage += "<br />分单方数" + dVolume + "与主单方数" + this.objData.Volume + "不相等;";
                }
                if(nWeight != this.objData.Weight){
                    strMessage += "<br />分单重量" + nWeight + "与主单重量" + this.objData.Weight + "不相等;";
                }
                if(nChargeWeight != this.objData.ChargeWeight){
                    strMessage += "<br />分单计费重量" + nChargeWeight + "与主单计费重量" + this.objData.ChargeWeight + "不相等;";                            
                }
                if(strMessage!=""){
                    this.$alert(strMessage, '系统提示', { dangerouslyUseHTMLString:true, type: 'warning' });
                    this.ctrForm.blnSubmit = false;  
                    return;
                }
                // if(this.objData.IsEnterSize == 0){  // 不录入尺寸                                                            
                // }
                // else{   // 录入尺寸
                //     if(strMessage!=""){
                //         this.$alert(strMessage, '系统提示', { dangerouslyUseHTMLString:true, type: 'warning' });
                //         this.ctrForm.blnSubmit = false;  
                //         return;
                //     }
                // }

                // if(nChargeWeight != this.objData.ChargeWeight){
                //     if(this.objData.IsSelfCharge == 0){ // 不自填
                //         this.$alert("分单计费重量" + nChargeWeight + "与主单计费重量" + this.objData.ChargeWeight + "不相等;", '系统提示', { dangerouslyUseHTMLString:true, type: 'warning' });
                //         this.ctrForm.blnSubmit = false;  
                //         return;
                //     }                    
                // }                
            }


            this.objData.ACOtherCharge = JSON.stringify(this.arrACOtherCharge);

            if(this.objData.DirectOrder == 1){  // 直单                
                this.objData.OOSCount = this.arrOutOrderSize.length;
                for(var i = 0; i < this.arrOutOrderSize.length; i++){
                    this.objData["Id_m" + i] = this.arrOutOrderSize[i].Id;
                    this.objData["Long_m" + i] = this.arrOutOrderSize[i].Long;
                    this.objData["Width_m" + i] = this.arrOutOrderSize[i].Width;
                    this.objData["Height_m" + i] = this.arrOutOrderSize[i].Height;
                    this.objData["Piece_m" + i] = this.arrOutOrderSize[i].Piece;
                    this.objData["Volume_m" + i] = this.arrOutOrderSize[i].Volume;
                }

                this.objData.ItemCount = 0;
            }
            else if(this.objData.DirectOrder == 2){  // 分单不录入尺寸                
                this.objData.ItemCount = this.arrOutOrderItem.length;
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    this.objData["Id" + i] = this.arrOutOrderItem[i].Id;
                    this.objData["Number" + i] = this.arrOutOrderItem[i].Number;
                    this.objData["GoodsName" + i] = this.arrOutOrderItem[i].GoodsName;
                    this.objData["Piece" + i] = this.arrOutOrderItem[i].Piece;
                    this.objData["Volume" + i] = this.arrOutOrderItem[i].Volume;
                    this.objData["Weight" + i] = this.arrOutOrderItem[i].Weight;
                    // this.objData["Piece" + i] = this.arrOutOrderItem[i].Piece;
                    // this.objData["Volume" + i] = this.arrOutOrderItem[i].Volume;
                    // this.objData["Weight" + i] = this.arrOutOrderItem[i].Weight;
                    this.objData["ChargeWeight" + i] = this.arrOutOrderItem[i].ChargeWeight;
                    this.objData["UnitPriceChoose" + i] = this.arrOutOrderItem[i].UnitPriceChoose;
                    this.objData["ToAddress" + i] = this.arrOutOrderItem[i].ToAddress;
                    this.objData["FromAddress" + i] = this.arrOutOrderItem[i].FromAddress;
                    this.objData["CustomerRemark" + i] = this.arrOutOrderItem[i].CustomerRemark;
                    this.objData["CustomerNotify" + i] = this.arrOutOrderItem[i].CustomerNotify;
                    this.objData["IsInputPreplan" + i] = this.arrOutOrderItem[i].IsInputPreplan;
                    this.objData["BLPrint" + i] = this.arrOutOrderItem[i].BLPrint;
                    this.objData["IsVirtually" + i] = this.arrOutOrderItem[i].IsVirtually;                   
                }

                if(this.objData.IsEnterSize == 0){  // 不录入尺寸
                    this.objData.OOSCount = this.arrOutOrderSize.length;
                    for(var i = 0; i < this.arrOutOrderSize.length; i++){
                        this.objData["Id_m" + i] = this.arrOutOrderSize[i].Id;
                        this.objData["Long_m" + i] = this.arrOutOrderSize[i].Long;
                        this.objData["Width_m" + i] = this.arrOutOrderSize[i].Width;
                        this.objData["Height_m" + i] = this.arrOutOrderSize[i].Height;
                        this.objData["Piece_m" + i] = this.arrOutOrderSize[i].Piece;
                        this.objData["Volume_m" + i] = this.arrOutOrderSize[i].Volume;
                    }
                }
                else{   // 录入尺寸
                    for(var i = 0; i < this.arrOutOrderItem.length; i++){
                        this.objData["OOSCount" + i] = this.arrOutOrderItem[i].arrOutOrderSize.length;
                        for(var j = 0; j < this.arrOutOrderItem[i].arrOutOrderSize.length; j++){
                            this.objData["Id_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Id;
                            this.objData["Long_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Long;
                            this.objData["Width_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Width;
                            this.objData["Height_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Height;
                            this.objData["Piece_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Piece;
                            this.objData["Volume_s" + i + '_' + j] = this.arrOutOrderItem[i].arrOutOrderSize[j].Volume;
                        }
                    }
                }
            }


            if(this.objData.Id != null){
                var strDeleteIds = "";
                var blnHas = false;
                for(var i = 0; i < this.objDetail.extData.arrOutOrderItem.length; i++){
                    blnHas = false;
                    for(var j = 0; j < this.arrOutOrderItem.length; j++){
                        if(this.objDetail.extData.arrOutOrderItem[i].Id == this.arrOutOrderItem[j].Id){
                            blnHas = true;
                            break;
                        }
                    }
                    if(blnHas == false){    // 需要删除的数据
                        strDeleteIds += this.objDetail.extData.arrOutOrderItem[i].Id + ",";
                    }
                }
                this.objData.DeleteIds = (strDeleteIds.length==0?"":strDeleteIds.substring(0,strDeleteIds-1));                
                
                
                var strOOSId = ",";
                /* 获得更新的Id */
                for(var i = 0; i < this.arrOutOrderSize.length; i++){
                    strOOSId+=(this.arrOutOrderSize[i].Id==null?"":(this.arrOutOrderSize[i].Id+","));
                }
                for(var i = 0; i < this.arrOutOrderItem.length; i++){                    
                    for(var j = 0; j < this.arrOutOrderItem[i].arrOutOrderSize.length; j++){                        
                        strOOSId+=(this.arrOutOrderItem[i].arrOutOrderSize[j].Id==null?"":(this.arrOutOrderItem[i].arrOutOrderSize[j].Id+","));
                    }
                }
                
                strDeleteIds = "";
                for(var i = 0; i < this.objDetail.extData.arrOutOrderSize.length; i++){                    
                    if(strOOSId.indexOf(","+this.objDetail.extData.arrOutOrderSize[i].Id+",")==-1){
                        strDeleteIds += this.objDetail.extData.arrOutOrderSize[i].Id + ",";
                    }
                }

                this.objData.DeleteSizeIds = (strDeleteIds.length==0?"":strDeleteIds.substring(0,strDeleteIds-1));                
            }



            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
                                        
                if(this.objData.Id == null){
                    this.$ajax.post('/Admin/OutOrder/Insert', this.objData).then(objResult=> {                                
                        this.ctrForm.blnSubmit = false;
                        if(objResult.success == false){                            
                            this.$alert(objResult.message, '系统提示', { type: 'error' }); 
                            return;
                        }

                        this.$alert(objResult.message, '系统提示').then(() => { 
                            this.$parent.search();
                            this.$layer.close(this.layerid);
                            // this.$store.commit('TabMenu/closeTab', this.TabId);
                        });                         
                    });
                }
                else{
                    this.$ajax.post('/Admin/OutOrder/Update', this.objData).then(objResult=> {                                  
                        this.ctrForm.blnSubmit = false;
                        if(objResult.success == false){                                    
                            this.$alert(objResult.message, '系统提示', { type: 'error' });                     
                            return;
                        }

                        this.$alert(objResult.message, '系统提示').then(() => { 
                            if(this.Mode!=1){
                                this.$parent.search();
                            }
                            this.$layer.close(this.layerid);
                            // this.$store.commit('TabMenu/closeTab', this.TabId);                           
                        });                        
                    });
                }                
            });
        },
        changeCompanyCustomer: function(nNew){
            console.log('a1')
            this.objData.AgentName = this.$store.state.CompanyCustomer.objMapping[nNew].Code;
            this.objData.AgentFullName = this.$store.state.CompanyCustomer.objMapping[nNew].FullCode;
        },
        changeAirLine: function(nNew){
            console.log('a2')
            this.arrFlight = [];
            this.objData.F_Id = null;
            this.objData.PrimaryCode = this.$store.state.AirLine.objMapping[nNew].PrimaryCode;
            this.objData.ToCityCode = this.$store.state.AirLine.objMapping[nNew].ToCityCode;
            this.objData.ChangeToCityCode = "";
            this.objData.ChangeACCode = "";
            this.objData.ToCityName = this.$store.state.AirLine.objMapping[nNew].ToCityName;
            this.objData.ACAccountInfor = this.$store.state.AirLine.objMapping[nNew].AccountInfor;
            this.arrACOtherCharge = JSON.parse(this.$store.state.AirLine.objMapping[nNew].OtherCharge);


            var objWhere = {
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": nNew, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;
            });
        },
        changeDirectOrder:function(nNew){
            console.log('a3')            
            this.objData.IsEnterSize = (nNew==1?null:1);
            this.objData.Piece = 0;
            this.objData.Volume = 0;
            this.objData.Weight = 0;
            this.objData.ChargeWeight = 0;
            this.arrOutOrderSize = [];

            this.arrOutOrderItem = [];                    
        },
        changeIsEnterSize: function(nNew){
            console.log('a4')
            this.objData.Piece = 0;
            this.objData.Volume = 0;
            this.objData.Weight = 0;
            this.objData.ChargeWeight = 0;
            this.arrOutOrderSize = [];

            this.arrOutOrderItem = [];            
            // for(var i = 0; i < this.arrOutOrderItem.length; i++){
            //     this.arrOutOrderItem[i].arrOutOrderSize = [];
            // }
        },

        addItemACOC: function(){
            this.arrACOtherCharge.push({Name:"", Value:null});
        },
        removeItemACOC: function(nIndex){
            this.arrACOtherCharge.splice(nIndex,1);
        },

        addItemOOS: function(){
            if(this.strSizeFormat == ""){
                this.arrOutOrderSize.push({Id:null, Long:null, Width:null, Height:null, Piece:null, Volume: null});
            }
            else{
                var objOOS = {Id:null, Long:null, Width:null, Height:null, Piece:null, Volume: null};

                var arrTemp = this.$lib.Common.split(this.strSizeFormat,"/");
                if(arrTemp.length!=2){
                    this.$alert("请按正确的格式'长*宽*高/件数'输入数据", '错误提示', { type: 'error' });
                    return;
                }
                objOOS.Piece = parseInt(arrTemp[1]);

                arrTemp = this.$lib.Common.split(arrTemp[0],"*");
                if(arrTemp.length!=3){
                    this.$alert("请按正确的格式'长*宽*高/件数'输入数据", '错误提示', { type: 'error' });
                    return;
                }

                objOOS.Long = parseInt(arrTemp[0]);    
                objOOS.Width = parseInt(arrTemp[1]);    
                objOOS.Height = parseInt(arrTemp[2]);
                objOOS.Volume = parseFloat(((objOOS.Long/100) * (objOOS.Width/100) * (objOOS.Height/100) * objOOS.Piece).toFixed(2));

                this.arrOutOrderSize.push(objOOS);
                this.strSizeFormat = "";

                this.calcMasterSize();
            }
        },
        removeItemOOS: function(nIndex){
            this.arrOutOrderSize.splice(nIndex,1);
            this.calcMasterSize();
        },
        changeMasterSize: function(objOOS){
            try{
                objOOS.Volume = parseFloat(((objOOS.Long/100) * (objOOS.Width/100) * (objOOS.Height/100) * objOOS.Piece).toFixed(2));
            }
            catch(message){
                console.log('a1');
                console.log(message);
            }
            
            this.calcMasterSize();
        },
        calcMasterSize: function(){ // 计算主单尺寸数据
            var nTotalPiece = 0;
            var nTotalVolume = 0;
            for(var i = 0; i < this.arrOutOrderSize.length; i++){
                nTotalPiece += this.arrOutOrderSize[i].Piece;
                nTotalVolume += this.arrOutOrderSize[i].Volume;
            }
            this.objData.Piece = nTotalPiece;
            this.objData.Volume = parseFloat(nTotalVolume.toFixed(2));

            this.calcMasterChargeWeight();
        },
        calcMasterChargeWeight: function(){ // 计算主单计费重量
            if(this.objData.IsSelfCharge == 0){
                if(this.objData.DirectOrder==1 || (this.objData.DirectOrder==2 && this.objData.IsEnterSize==0)){    // 直单
                    var fChargeWeight = parseInt(this.objData.Volume * this.objData.ConvertStandard);
                    if(fChargeWeight > this.objData.Weight){
                        this.objData.ChargeWeight = fChargeWeight;
                    }
                    else{
                        this.objData.ChargeWeight = this.objData.Weight;
                    }
                }
                else {  // 分单
                    var nChargeWeight = 0;
                    for(var i = 0; i < this.arrOutOrderItem.length; i++){
                        var fChargeWeight = parseInt(this.arrOutOrderItem[i].Volume * this.objData.ConvertStandard);
                        if(fChargeWeight > this.arrOutOrderItem[i].Weight){
                            this.arrOutOrderItem[i].ChargeWeight = fChargeWeight;
                        }
                        else{
                            this.arrOutOrderItem[i].ChargeWeight = this.arrOutOrderItem[i].Weight;
                        }
                        nChargeWeight += this.arrOutOrderItem[i].ChargeWeight;
                    }
                    this.objData.ChargeWeight = nChargeWeight;
                }
            }
        },


        addItem: function(){
            this.arrOutOrderItem.push({
                Id: null,
                Number: "",
                GoodsName: "",
                Piece: 0,
                Volume: 0,
                Weight: 0,
                // Piece: null,
                // Volume: null,
                // Weight: null,
                // IsSelfCharge: 0,
                ChargeWeight: 0,

                UnitPriceChoose: 1,
                ToAddress: "",
                FromAddress: "",
                CustomerRemark: "",
                CustomerNotify: "",

                IsInputPreplan: 1,
                BLPrint: 1,
                IsVirtually: 0,

                strSizeFormat: "",
                arrOutOrderSize: []
            });
        },
        removeItem: function(nIndex){
            this.arrOutOrderItem.splice(nIndex,1);
        },
        addItemChildOOS: function(objItem){            
            if(objItem.strSizeFormat == ""){
                objItem.arrOutOrderSize.push({Id:null, Format:"", Long:null, Width:null, Height:null, Piece:null, Volume: null});
            }
            else{
                var objOOS = {Id:null, Format:"", Long:null, Width:null, Height:null, Piece:null, Volume: null};

                var arrTemp = this.$lib.Common.split(objItem.strSizeFormat,"/");
                if(arrTemp.length!=2){
                    this.$alert("请按正确的格式'长*宽*高/件数'输入数据", '错误提示', { type: 'error' });
                    return;
                }
                objOOS.Piece = parseInt(arrTemp[1]);

                arrTemp = this.$lib.Common.split(arrTemp[0],"*");
                if(arrTemp.length!=3){
                    this.$alert("请按正确的格式'长*宽*高/件数'输入数据", '错误提示', { type: 'error' });
                    return;
                }

                objOOS.Long = parseInt(arrTemp[0]);    
                objOOS.Width = parseInt(arrTemp[1]);    
                objOOS.Height = parseInt(arrTemp[2]);
                objOOS.Volume = parseFloat(((objOOS.Long/100) * (objOOS.Width/100) * (objOOS.Height/100) * objOOS.Piece).toFixed(2));

                objItem.arrOutOrderSize.push(objOOS);
                objItem.strSizeFormat = "";
                
                this.calcSlaveSize(objItem);
            }

        },
        removeItemChildOOS: function(objItem,nIndex){
            objItem.arrOutOrderSize.splice(nIndex,1);
            this.calcSlaveSize(objItem);
        },
        changeSlaveSize: function(objItem, j){
            try{                
                objItem.arrOutOrderSize[j].Volume = parseFloat(((objItem.arrOutOrderSize[j].Long/100) * (objItem.arrOutOrderSize[j].Width/100) * (objItem.arrOutOrderSize[j].Height/100) * objItem.arrOutOrderSize[j].Piece).toFixed(2));
            }
            catch(message){
                console.log('a1');
                console.log(message);
            }
            
            this.calcSlaveSize(objItem);
        },
        calcSlaveSize: function(objItem){ // 计算分单尺寸数据
            var nTotalPiece = 0;
            var nTotalVolume = 0;
            for(var i = 0; i < objItem.arrOutOrderSize.length; i++){
                nTotalPiece += objItem.arrOutOrderSize[i].Piece;
                nTotalVolume += objItem.arrOutOrderSize[i].Volume;
            }
            objItem.Piece = nTotalPiece;
            objItem.Volume = parseFloat(nTotalVolume.toFixed(2));

            this.calcSlaveChargeWeight(objItem);

            this.calcMasterSizeBySlave();
        },
        calcSlaveChargeWeight: function(objItem){ // 计算分单计费重量
            if(this.objData.IsSelfCharge == 0){
                var fChargeWeight = parseInt(objItem.Volume * this.objData.ConvertStandard);
                if(fChargeWeight > objItem.Weight){
                    objItem.ChargeWeight = fChargeWeight;
                }
                else{
                    objItem.ChargeWeight = objItem.Weight;
                }

                if(this.objData.IsEnterSize==1){    // 计算主单计费重量                    
                    var nChargeWeight = 0;                    
                    for(var i = 0; i < this.arrOutOrderItem.length; i++){                        
                        nChargeWeight += this.arrOutOrderItem[i].ChargeWeight;
                    }

                    this.objData.ChargeWeight = nChargeWeight;                    
                }
            }

            if(this.objData.IsEnterSize==1){    // 根据分单计算主单重量数据
                var nWeight = 0;
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    nWeight += this.arrOutOrderItem[i].Weight;                        
                }

                this.objData.Weight = nWeight;                    
            }
        },

        calcMasterSizeBySlave:function(){   // 根据分单计算主单尺寸数据
            if(this.objData.IsEnterSize == 0){
                return;
            }

            var blnHas = false;
            var nTotalPiece = 0;
            var nTotalVolume = 0;

            this.arrOutOrderSize = [];
            for(var i = 0; i < this.arrOutOrderItem.length; i++){
                nTotalPiece += this.arrOutOrderItem[i].Piece;
                nTotalVolume += this.arrOutOrderItem[i].Volume;

                for(var j = 0; j < this.arrOutOrderItem[i].arrOutOrderSize.length; j++){
                    blnHas = false;
                    if(this.arrOutOrderItem[i].arrOutOrderSize[j].Piece == null){                        
                        continue;
                    }
                    for(var m = 0; m < this.arrOutOrderSize.length; m++){
                        if(this.arrOutOrderItem[i].arrOutOrderSize[j].Long == this.arrOutOrderSize[m].Long && this.arrOutOrderItem[i].arrOutOrderSize[j].Width == this.arrOutOrderSize[m].Width && this.arrOutOrderItem[i].arrOutOrderSize[j].Height == this.arrOutOrderSize[m].Height){
                            this.arrOutOrderSize[m].Piece += this.arrOutOrderItem[i].arrOutOrderSize[j].Piece;
                            blnHas = true;
                        }
                    }
                    if(blnHas == false){
                        this.arrOutOrderSize.push(JSON.parse(JSON.stringify(this.arrOutOrderItem[i].arrOutOrderSize[j])));
                        this.arrOutOrderSize[this.arrOutOrderSize.length-1].Id = null;
                    }
                }
            }
            this.objData.Piece = nTotalPiece;
            this.objData.Volume = parseFloat(nTotalVolume.toFixed(2));
        }
    }
}
</script>

<style scoped>
    /* .form-item-hd{width: 120px;}
    .form-item-bd{ width:calc(100% - 120px);}  */

    .table-size div:nth-of-type(odd){
        margin-right: 1%;
    }


</style>
