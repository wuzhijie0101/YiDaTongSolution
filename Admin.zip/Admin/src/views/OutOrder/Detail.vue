<template>
    <div class="hc-bg_gray" style="height:100%; width: 100%; overflow-y: auto;">
        <div class="def-tab" style="display: flex; align-items: center; border-bottom: 1px solid #dfdfdf; background-color: #fff; ">
            <div style="flex-grow: 1; text-align: center; cursor: pointer;" @click="nTab=0;" ><span :class="(nTab==0?'on':'')">基本信息</span></div>
            <div style="flex-grow: 1; text-align: center; cursor: pointer;" @click="nTab=1;"><span :class="(nTab==1?'on':'')">详细信息</span></div>
            <div style="flex-grow: 1; text-align: center; cursor: pointer;" @click="nTab=2;"><span :class="(nTab==2?'on':'')">业务信息</span></div>
        </div>

        <div v-show="nTab == 0">
            <div class="hc_container-fluid" style="background-color: #fff;">
                <div class="row" style="padding: 10px; padding-bottom: 0px;">
                    <div class="col-80">航班:{{objData.FlightNumber}}</div>
                    <div class="col-160">单号:{{objData.PrimaryCode}}-{{objData.Number}}</div>
                </div>
                <div class="row" style="padding: 10px;">
                    <div class="col-60">件数:{{objData.Piece}}</div>
                    <div class="col-60">货重:{{objData.Weight}}</div>
                    <div class="col-60">计重:{{objData.ChargeWeight}}</div>
                    <div class="col-60">方数:{{objData.Volume}}</div>
                </div>
            </div>
            
            <div style="position: relative; margin-top: 10px;">
                
                <div style="position: relative; margin-left: 34%; width: 65%; border-left: 5px solid #cccccc;">
                    <div style="position: absolute; left: -90px; top: -2px;">航班创建<img src="/static/image/jingang.gif" style="width: 16px; height: 16px; margin-bottom: -2px;" /></div>                        
                    <div><span class="oo-time-dot" style="background-color: red;"></span></div>
                    <div style="height: 20px;"></div>

                    <template v-if="objData.Type==2">
                    <div class="oo-time-title">跨境电商<span class="oo-time-dot"></span></div>
                    <div class="oo-time-content">创建货运单{{"["+$store.state.Employee.objMapping[objData.E_Id].Name+"]"+$dayjs(objData.CreateTime).format("MM-DD HH:mm")}}</div>
                    <div :class="(objData.State>=10?'oo-time-content':'oo-time-wait')">{{getMessage(10,'CustomsAuditTime')}}</div>
                    <div :class="(objData.State>=11?'oo-time-content':'oo-time-wait')">{{getMessage(11,'EnterTimeKJ')}}</div>
                    <div :class="(objData.State>=12?'oo-time-content':'oo-time-wait')">{{getMessage(12,(objData.CustomsCheckTime==null?'PassTimeKJ':'CustomsCheckTime'))}}</div>
                    <div v-if="!(objData.State>13 && objData.CustomsCheckTime==null)" :class="(objData.State>=13?'oo-time-content':'oo-time-wait')">{{getMessage(13,'PassTimeKJ')}}</div>
                    <div :class="(objData.State>=14?'oo-time-content':'oo-time-wait')">{{getMessage(14,'LeaveTimeKJ')}}</div>
                    </template>
                    <template v-else>
                    <div class="oo-time-title">客服<span class="oo-time-dot"></span></div>
                    <div class="oo-time-content">创建货运单{{"["+$store.state.Employee.objMapping[objData.E_Id].Name+"]"+$dayjs(objData.CreateTime).format("MM-DD HH:mm")}}</div>                        
                    <div :class="getClass(1,'DepartTime')">{{getMessage(1,'DepartTime')}}</div>
                    <div :class="getClass(2,'ArrivalTime')">{{getMessage(2,'ArrivalTime')}}</div>
                    <div v-if="objData.State==3" :class="getClass(3,'PassTimeKF')">{{getMessage(3,'PassTimeKF')}}</div>
                    
                    <div v-if="!(objData.State>20 && objData.EnterTimeQZC==null)" class="oo-time-title">前置仓<span class="oo-time-dot"></span></div>
                    <div v-if="!(objData.State>20 && objData.EnterTimeQZC==null)" :class="(objData.State>=20?'oo-time-content':'oo-time-wait')">{{getMessage(20,'EnterTimeQZC')}}</div>
                    <div v-if="!(objData.State>21 && objData.CustomConfirmTimeQZC==null)" :class="(objData.State>=21?'oo-time-content':'oo-time-wait')">{{getMessage(21,'CustomConfirmTimeQZC')}}</div>
                    <div v-if="!(objData.State>22 && objData.DeliverTime==null)" :class="(objData.State>=22?'oo-time-content':'oo-time-wait')">{{getMessage(22,'DeliverTime')}}</div>
                    <div v-if="!(objData.State>23 && objData.LeaveTimeQZC==null)" :class="(objData.State>=23?'oo-time-content':'oo-time-wait')">{{getMessage(23,'LeaveTimeQZC')}}</div>
                    </template>

                    <div class="oo-time-title">地面<span class="oo-time-dot"></span></div>
                    <div v-if="objData.Type==2" :class="getClass(30,'PerfectDataTime')">{{getMessage(30,'PerfectDataTime')}}</div>
                    <div :class="getClass(31,'UnloadTime')">{{getMessage(31,'UnloadTime')}}</div>
                    <div v-if="objData.Type!=2 && !(objData.State>32 && objData.CustomConfirmTimeDM==null)" :class="getClass(32,'CustomConfirmTimeDM')">{{getMessage(32,'CustomConfirmTimeDM')}}</div>
                    <div :class="getClass(33,'EnterPreplanTime')">{{getMessage(33,'EnterPreplanTime')}}</div>
                    <div v-if="objData.Type!=2" :class="getClass(34,'ReportCustomsTime')">{{getMessage(34,'ReportCustomsTime')}}</div>
                    <div :class="getClass(35,'EnterShipTime')">{{getMessage(35,'EnterShipTime')}}</div>
                    <div v-if="objData.Type!=2 && !(objData.State>36 && objData.CheckTime==null)" :class="getClass(36,'CheckTime')">{{getMessage(36,'CheckTime')}}</div>
                    <div v-if="objData.Type!=2 && !(objData.State>37 && objData.AgainTime==null)" :class="getClass(37,'AgainTime')">{{getMessage(37,'AgainTime')}}</div>
                    <div :class="getClass(38,'PassTimeDM')">{{getMessage(38,'PassTimeDM')}}</div>
                    <div :class="getClass(39,'SecurityCheckedTime')">{{getMessage(39,'SecurityCheckedTime')}}</div>

                    <div class="oo-time-title">组板<span class="oo-time-dot"></span></div>
                    <div :class="getClass(50,'ArrangeTime')">{{getMessage(50,'ArrangeTime')}}</div>
                    <div v-if="!(objData.State>51 && objData.StartBoardTime==null)" :class="getClass(51,'StartBoardTime')">{{getMessage(51,'StartBoardTime')}}</div>
                    <div :class="getClass(52,'OverBoardTime')">{{getMessage(52,'OverBoardTime')}}</div>
                    <div :class="getClass(53,'CheckDataTime')">{{getMessage(53,'CheckDataTime')}}</div>
                    <div :class="getClass(54,'PrintTime')">{{getMessage(54,'PrintTime')}}
                        <div v-if="arrMakeBoard.length>0" style="padding-left: 15px;">
                            <div>所属板:</div>
                            <div v-for="objItem in arrMakeBoard">{{objItem.BoardNumber}}</div>
                        </div>
                    </div>
                    <div :class="getClass(55,'CheckFlyTime')">{{getMessage(55,'CheckFlyTime')}}</div>
                    <div :class="getClass(56,'OverTime')">{{getMessage(56,'OverTime')}}</div>

                    <div v-if="objData.State==60" class="oo-time-content">已完成</div>
                    <div v-else-if="objData.State==61" class="oo-time-content">{{$lib.Store.getValFromDic('OutOrder_State',61)+('['+$store.state.Employee.objMapping[objData.E_IdCancelTime].Name+']'+$dayjs(objData.CancelTime).format("MM-DD HH:mm"))}}</div>
                    
              
                    <div style="height: 10px;"></div>
                    <div style="position: absolute; left: -122px; width: 105px; text-align: right; bottom: -10px;">预飞{{$lib.Store.getValById($store.state.Flight.objMapping,objData.F_Id,"EstimatedTime")}}<img src="/static/image/ligang.gif" style="width: 16px; height: 16px; margin-bottom: -2px;" /></div>

                    <div style="position: absolute; left: -12.5px; bottom: -20px;"><span style="display: inline-block; width: 0px; height: 0px; border: 10px solid transparent; border-top-color: #cccccc;"></span></div>
                </div>
                
                <div v-show="objData.State<60 && nFlyMinute>=0" style="margin-top: 17px; margin-left: 9%; color: red; font-weight: bold;">距离{{objData.FlightNumber}}起飞还有{{nFlyMinute}}分钟</div>
            </div>                
        </div>
        

        <div v-show="nTab == 1">
            <div class="hc_container-fluid" style="background-color: #fff;">
                <div class="row" style="padding: 5px 10px; padding-top: 10px;">
                    <div class="col-80"><span class="cell-hd">航线:</span><span class="cell-bd">{{$lib.Store.getValById($store.state.AirLine.objMapping,objData.AL_Id)}}</span></div>
                    <div class="col-80"><span class="cell-hd">航班:</span><span class="cell-bd">{{objData.FlightNumber}}</span></div>
                    <div class="col-80"><span class="cell-hd">状态:</span><span class="cell-bd">{{$lib.Store.getValFromDic('OutOrder_State',objData.State)}}</span></div>                                                
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-80"><span class="cell-hd">类型:</span><span class="cell-bd">{{$lib.Store.getValFromDic('OutOrder_Type',objData.Type)}}</span></div>
                    <div class="col-160"><span class="cell-hd">虚拟单号:</span><span class="cell-bd">{{objData.VirNumber}}</span></div>
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-80"><span class="cell-hd">目的港:</span><span class="cell-bd">{{objData.ToCityCode}}</span></div>
                    <div class="col-80"><span class="cell-hd">是否抹泡:</span><span class="cell-bd">{{$lib.Store.getValFromDic('Is',objData.IsBulkyCargo)}}</span></div>
                    <div class="col-80"><span class="cell-hd">直单分单:</span><span class="cell-bd">{{$lib.Store.getValFromDic('OutOrder_DirectOrder',objData.DirectOrder)}}</span></div>
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-240"><span class="cell-hd">备注:</span><span class="cell-bd">{{objData.Remark}}</span></div>                                                 
                </div>
            </div>

            <div class="hc_container-fluid" style="background-color: #fff; margin-top: 10px; padding: 5px 0px;">
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-60"><span class="cell-hd">件数:</span><span class="cell-bd">{{objData.Piece}}</span></div>
                    <div class="col-60"><span class="cell-hd">货重:</span><span class="cell-bd">{{objData.Weight}}</span></div>
                    <div class="col-60"><span class="cell-hd">计重:</span><span class="cell-bd">{{objData.ChargeWeight}}</span></div>
                    <div class="col-60"><span class="cell-hd">方数:</span><span class="cell-bd">{{objData.Volume}}</span></div>
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-60"><span class="cell-hd">主单:</span><span class="cell-bd" v-html="$lib.Format.fmtImageName(objData.OrderVoucher,',')"></span></div>
                    <div class="col-60"><span class="cell-hd">分单:</span><span class="cell-bd" v-html="$lib.Format.fmtImageName(objData.SlaveVoucher,',')"></span></div>
                    <div class="col-60"><span class="cell-hd">舱单:</span><span class="cell-bd" v-html="$lib.Format.fmtImageName(objData.ManifestVoucher,',')"></span></div>
                    <div class="col-60"><span class="cell-hd">安全:</span><span class="cell-bd" v-html="$lib.Format.fmtImageName(objData.SafeVoucher,',')"></span></div>
                </div>
            </div>

            <div v-for="(objItem,i) in arrOutOrderItem" class="hc_container-fluid" style="background-color: #fff; margin-top: 10px; padding: 5px 0px;">
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-240"><span class="cell-hd">分单{{(i+1)}}:</span><span class="cell-bd">{{objItem.Number}}</span></div>
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-80"><span class="cell-hd">录预配运抵:</span><span class="cell-bd">{{$lib.Store.getValFromDic('Is',objItem.IsInputPreplan)}}</span></div>
                    <div class="col-80"><span class="cell-hd">提单打印:</span><span class="cell-bd">{{$lib.Store.getValFromDic('OutOrderItem_BLPrint',objItem.BLPrint)}}</span></div>
                    <div class="col-80"><span class="cell-hd">虚拟分单:</span><span class="cell-bd">{{$lib.Store.getValFromDic('Is',objItem.IsVirtually)}}</span></div>   
                </div>
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-80"><span class="cell-hd">件数:</span><span class="cell-bd">{{objItem.Piece}}</span></div>
                    <div class="col-80"><span class="cell-hd">货重:</span><span class="cell-bd">{{objItem.Weight}}</span></div>
                    <div class="col-80"><span class="cell-hd">方数:</span><span class="cell-bd">{{objItem.Volume}}</span></div>
                </div>
                <!-- <div class="row" style="padding: 5px 10px;">
                    <div class="col-240"><span class="cell-hd">扫描件:</span><span class="cell-bd" v-html="$lib.Format.fmtImageName(objItem.OrderVoucher,',')"></span></div>
                </div> -->
            </div>

        </div>

        <div v-show="nTab == 2">
            <div class="hc_container-fluid" style="background-color: #fff; padding: 5px 0px;">
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-80"><span class="cell-hd">货车:</span><span class="cell-bd">{{objData.CarNumber}}</span></div>
                    <div class="col-80"><span class="cell-hd">司机:</span><span class="cell-bd">{{objData.DriverName}}</span></div>                                                                        
                </div>
                <div v-show="arrMakeBoard.length>0" class="row" style="padding: 5px 10px;">
                    <div class="col-240" style="font-weight: bold; margin-bottom: 5px;">所属板</div>
                    <div v-for="objItem in arrMakeBoard" class="col-80">{{objItem.BoardNumber}}</div>
                </div>
                <div v-show="objData.PreId!=null" class="row" style="padding: 5px 10px;">
                    <div class="col-240"><span class="cell-hd">前空运单号:</span><span class="cell-bd"><span class="hc_button-text" @click="openOutOrderDetail(objData.PreId)">点击查看</span></span></div>
                </div>

                
                <div v-if="objData.DetainCount>0" class="row" style="padding: 5px 10px;">
                    <div class="col-240" style="font-weight: bold; margin-bottom: 5px;">跨境电商退件</div>
                    <!-- <div class="col-240 row" style="align-items: center;">
                        <template v-for="objItem in arrDetainGoods">
                            <div class="col-240">
                                <div><span class="cell-hd">运单号:</span><span class="cell-bd">{{objItem.WaybillNumber}}</span></div>
                                <div style="margin-top: 10px;"><span class="cell-hd">扣件原因:</span><span class="cell-bd">{{objItem.Reason}}</span></div>
                            </div>
                        </template>                                                           
                    </div> -->
                    <div class="col-240"><span class="cell-hd">跨境备注:</span><span class="cell-bd">{{objData.ECRemark}}</span></div>   
                    <div v-for="objItem in arrLogisticsOrder" v-if="objItem.Type==1" class="col-240" style="margin-bottom: 10px;"><span class="cell-hd">快递单1:</span><span class="hc_button-text" @click="openLogisticsOrderDetail(objItem.Id);">{{objItem.Number}}</span></div>          
                </div>
                
                <div class="row" style="padding: 5px 10px;">
                    <div class="col-240" style="font-weight: bold; margin-bottom: 5px;">地面退件</div>
                    <div v-for="objItem in arrLogisticsOrder" v-if="objItem.Type==3" class="col-240" style="margin-bottom: 10px;"><span class="cell-hd">快递单1:</span><span class="hc_button-text" @click="openLogisticsOrderDetail(objItem.Id);">{{objItem.Number}}</span></div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import OutOrderDetail from '@/views/OutOrder/Detail.vue';
import LogisticsOrderDetail from '@/views/LogisticsOrder/Detail.vue';

export default {
    data: function() {
        return{
            nTab : 0,
            nFlyMinute: 0,

            arrOutOrderItem:[],
            arrDetainGoods:[],
            arrLogisticsOrder:[],                    
            arrMakeBoard:[],
            objData:{
                Id: this.Id,                        
            }
        }
    },
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        
        openOutOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: OutOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['700px','90%'],
                shadeClose: false,
                title: '前货运单详情'
            });
        },
        openLogisticsOrderDetail:function(nId){     
            this.$layer.iframe({
                content: {
                    content: LogisticsOrderDetail,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['700px','90%'],
                shadeClose: false,
                title: '快递进度'
            });
        },

        getClass: function(nState, strTimeField){
            return (this.objData.State == nState || this.objData[strTimeField] != null ? "oo-time-content" : "oo-time-wait");
        },
        getMessage:function(nState, strTimeField){
            var strReturn = "";

            strReturn = this.$lib.Store.getValFromDic('OutOrder_State',nState).replace('待','');;
            if(this.objData.State > nState){
                strReturn += (this.objData[strTimeField]==null?'-未录系统':('['+this.$store.state.Employee.objMapping[this.objData['E_Id'+strTimeField]].Name+']'+this.$dayjs(this.objData[strTimeField]).format("MM-DD HH:mm")))
            }
            else if(this.objData.State == nState){
                strReturn += "-执行中...";
            }
            else{
                strReturn += "-待执行";
            }
            return strReturn;
        },

        initPage: function(){                    
            this.$ajax.get('/Admin/OutOrder/GetForDetail?Id=' + this.objData.Id, null,{async:false}).done(objResult=> {
                if(objResult.success == false){                    
                    this.$alert(objResult.message, '系统提示', { type: 'error' }); 
                    return;
                }

                this.objData = objResult.data[0];

                this.arrDetainGoods = objResult.extData.arrDetainGoods;
                this.arrLogisticsOrder = objResult.extData.arrLogisticsOrder;
                this.arrMakeBoard = objResult.extData.arrMakeBoard;                        

                var strFlyTime = this.$lib.Store.getValById(this.$store.state.Flight.objMapping,this.objData.F_Id,"EstimatedTime");
                if(strFlyTime == ""){
                    this.nFlyMinute = -1;
                }
                else{
                    strFlyTime = this.$lib.Store.getValById(this.$store.state.Flight.objMapping,this.objData.F_Id,"Date") + " " + strFlyTime;
                    this.nFlyMinute = parseInt((this.$dayjs(strFlyTime) - this.$dayjs())/1000/60);
                    // alert(this.$dayjs((this.$dayjs('2023-08-05 01:05:00') - this.$dayjs('2023-08-05 00:01:00'))).format("YYYY-MM-DD HH:mm"))
                }
                
                

                if(this.objData.DirectOrder==2){
                    for(var i = 0; i < objResult.extData.arrOutOrderItem.length; i++){
                        this.arrOutOrderItem.push(objResult.extData.arrOutOrderItem[i]);
                    }
                }
            });
        }
    }
}

</script>

<style scoped>
.def-tab{}
.def-tab span{display: inline-block; padding: 10px 10px;}
.def-tab .on{color: #005a99; border-bottom: 3px solid #005a99;}
.hc_cell{padding: 5px !important;}
.cell-hd{display: inline-block;}
.cell-bd{display: inline-block; color: #999;}        

.oo-time-title{  font-weight: bold; color: #333; padding: 5px 8px; position: relative;}
.oo-time-dot{ position: absolute; left: -10px; display: inline-block; width: 14px; height: 14px; border-radius: 50%; background-color: #005a99; }
.oo-time-content{  color: #333; padding: 5px; }
.oo-time-wait{  color: #999; padding: 5px;}
</style>
