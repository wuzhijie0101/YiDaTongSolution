<template>
    <div style="width:100%; height: 100%;">
        <!-- <div class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row hc_form form-size-small">
                
            </div>
        </div> -->

        <validation-observer ref="form" tag="div" class="hc_container-fluid hc_form-pc" style="padding: 10px;">
            <div class="row">
                <!-- <div class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属部门</div>
                    <div class="form-item-bd">{{$store.state.Company.objMapping[objData[C_IdKey]].Name}}</div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div> -->
                <div class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属客户</div>                    
                    <validation-provider tag="div" name="所属客户" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData[CC_IdKey]" filterable placeholder="请选择" style="width: 100%;">
                            <el-option v-for="objItem in $store.state.CompanyCustomer.getByC_Id(objData[C_IdKey])" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属航线</div>                    
                    <validation-provider tag="div" name="所属航线" class="form-item-bd" rules="required" v-slot="{ errors }">
                        <el-select v-model="objData.AL_Id" filterable placeholder="请选择" :disabled="objData.Id!=null" style="width: 100%;" @change="changeAirLine">
                            <el-option v-for="objItem in $store.state.AirLine.getByEnable(1)" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                        </el-select>
                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                    </validation-provider>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd">航班号</div>
                    <div class="form-item-bd">
                        <el-select v-model="objData.F_Id" filterable placeholder="请选择" clearable style="width: 100%;">
                            <el-option v-for="objItem in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                        </el-select>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.Type" name="货物类型" :data="arrOutOrder_Type"></hc-radio-item>

                
                <div class="col-57 form-item">                                        
                    <div class="form-item-hd">状态</div>                    
                    <div class="form-item-bd">
                        <template v-if="Mode==0 && objData.Id == null">
                            <el-select v-model="objData.State" style="width: 100%;">
                                <el-option v-show="objData.C_Id!=1002" label="待发车" :value="1"></el-option>
                                <!-- <el-option label="运输中" :value="3"></el-option> -->
                                <!-- <el-option v-show="objData.C_Id!=1002" label="待货车卸货" :value="31"></el-option>   -->

                                <el-option v-show="objData.C_Id==1002" label="待报海关" :value="10"></el-option>
                            </el-select>
                        </template>
                        <template v-else>
                            <el-select v-model="objData.State" style="width: 100%;" disabled>                                
                                <el-option v-for="objItem in $store.state.Dictionary.objMapKey.OutOrder_State" :label="objItem.Name" :value="parseInt(objItem.Value)"></el-option>
                            </el-select>
                        </template>

                        <div class="form-error"></div>
                    </div>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.VirNumber" name="虚拟单号"></hc-text-item>
                <div class="col-4"></div>
                <div class="col-57 form-item">
                    <div class="form-item-hd">空运单号</div>                    
                    <validation-provider tag="div" name="空运单号" class="form-item-bd" v-slot="{ errors }">
                        {{objData.PrimaryCode}} <input class="hc_text" v-model="objData.Number" placeholder="请输入" autocomplete="off" style="width: 80%;" />                        
                    </validation-provider>
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.ToCityCode" validate="required" name="目的港三字码"></hc-text-item>
            </div>
            

            <div class="row">
                <hc-radio-item class="col-57" v-model="objData.IsBulkyCargo" name="是否抹泡" :data="$store.state.Dictionary.objMapKey.Is"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item class="col-57" v-model="objData.DirectOrder" name="直单分单" @change="changeDirectOrder" :data="$store.state.Dictionary.objMapKey.OutOrder_DirectOrder"></hc-radio-item>
                <div class="col-4"></div>
                <hc-radio-item v-if="Mode==3" class="col-57" v-model="objData.GoToQZC" name="走前置仓" :data="$store.state.Dictionary.objMapKey.Is"></hc-radio-item>
                
                <!-- <hc-text-item class="col-118" type="text" v-model="objData.Remark" name="备注"></hc-text-item> -->
            </div>
            <div v-if="C_Id==1002" class="row">
                <hc-datetime-item class="col-57" type="datetime-local" v-model="objData.SendInforTime" validate="required" name="送报关资料时间" placeholder="请选择"></hc-datetime-item>
                <div class="col-4"></div>
                <hc-text-item class="col-57" type="text" v-model="objData.CarNumber" name="车牌号" placeholder="格式入：湘B8925A"></hc-text-item>
                <div class="col-4"></div>
                <hc-number-item class="col-57" v-model="objData.PackageCount" validate="required|numeric" name="清单总数"></hc-number-item>
                <div class="col-4"></div>
                <hc-number-item class="col-57" v-model="objData.ReportMoney" validate="required|dec2|min_value:0" name="申报金额"></hc-number-item>                

                <hc-radio-item class="col-57" v-model="objData.TransportMode" name="运输方式" :data="$store.state.Dictionary.objMapKey.OutOrder_TransportMode"></hc-radio-item>
                <div class="col-4"></div>
                <!-- <hc-radio-item class="col-57" v-model="objData.GroundAgentKJ" name="地面代理" :data="$store.state.Dictionary.objMapKey.OutOrder_GroundAgentKJ"></hc-radio-item> -->

                <div class="col-57 form-item">
                    <div class="form-item-hd">地面代理</div>                    
                    <div class="form-item-bd">
                        <label class="hc_checkbox">
                            <input type="checkbox" v-model="objData.blnC_IdDM" name="地面代理" /> <span>璟盛</span>
                        </label>
                    </div>                    
                    <div class="form-item-ft"></div>
                </div>
                <div class="col-4"></div>

                <hc-radio-item class="col-57" v-model="objData.ECAgent" name="申报主体" :data="$store.state.Dictionary.objMapKey.OutOrder_ECAgent"></hc-radio-item>
                <div class="col-4"></div>
            </div>
            
            <!-- <div>车牌号、空车重量、司机、身份证、手机</div> -->

            <div class="row">
                <div class="col-240" style="margin-top: 10px;">
                    <table class="hc-table hc_form-small" style="margin: 0px auto;">
                        <thead>
                            <tr style="line-height: 28px; font-weight: bold;">
                                <th style="width: 30px;"></th>
                                <th style="width: 210px;">单号</th>
                                <th style="width: 200px;">尺寸</th>
                                <th style="width: 130px;">数据</th>
                                <th style="width: 170px;">计费重量</th>
                                <th style="width: 50px;">操作</th>
                            </tr>   
                        </thead>
                        <tbody>
                            <tr>
                                <td style="vertical-align:middle; text-align: center;">主单</td>
                                <td style="vertical-align:middle;">{{objData.PrimaryCode+'-'+objData.Number}}</td>
                                <td>
                                    <textarea v-model="objData.SizeInfor" class="hc_textarea" rows="5"></textarea>
                                </td>
                                <td>
                                    <div>
                                        <validation-provider tag="span" name="件数" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            件数：<hc-number type="text" v-model="objData.Piece" class="hc_text hc_text-border" :disabled="objData.DirectOrder==2" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <validation-provider tag="span" name="重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            重量：<hc-number type="text" v-model="objData.Weight" class="hc_text hc_text-border" :disabled="objData.DirectOrder==2" @change="calcMasterChargeWeight();" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <validation-provider tag="span" name="方数" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }">
                                            方数：<hc-number type="text" v-model="objData.Volume" class="hc_text hc_text-border" @change="calcMasterChargeWeight();" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div>
                                            计费靠打：<label class="hc_radio" v-for="objItem in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objData.IsSelfCharge" :value="parseInt(objItem.Value)" name="计费靠打" @change="calcMasterChargeWeight();" /><span>{{objItem.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <validation-provider tag="div" name="计费重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            计费重量：<hc-number type="text" v-model="objData.ChargeWeight" class="hc_text hc_text-border" placeholder="请输入" :disabled="objData.IsSelfCharge==0" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <div>
                                            体积换算：<el-select v-model="objData.ConvertStandard" placeholder="请选择" @change="calcMasterChargeWeight();" style="width: 85px;" size="mini">
                                                <el-option label="166.666" :value="166.666"></el-option>
                                                <el-option label="167" :value="167"></el-option>
                                            </el-select>
                                        </div>
                                    </div>
                                </td>
                                <td></td>
                            </tr>                           



                            <tr v-for="(objItem,i) in arrOutOrderItem">
                                <td style="vertical-align:middle; text-align: center;">分单{{i+1}}</td>
                                <td>
                                    <validation-provider tag="span" name="分单号" class="form-item-bd" rules="required" v-slot="{ errors }">
                                        <input type="text" v-model="objItem.Number" class="hc_text hc_text-border" placeholder="分单号" />
                                        <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                    </validation-provider>
                                    <!-- <div style="margin-top: 8px;">
                                        <div>
                                            录预配运抵：<label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objItem.IsInputPreplan" :value="parseInt(objItemDic.Value)" :name="'录预配运抵'+i" /><span>{{objItemDic.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <div>
                                            提单打印：<label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.OutOrderItem_BLPrint">                
                                                <input type="radio" v-model="objItem.BLPrint" :value="parseInt(objItemDic.Value)" :name="'提单打印'+i" /><span>{{objItemDic.Name}}</span>
                                            </label>
                                        </div>
                                    </div> -->
                                    <div style="margin-top: 8px;">
                                        <div>
                                            虚拟分单：<label class="hc_radio" v-for="objItemDic in $store.state.Dictionary.objMapKey.Is">                
                                                <input type="radio" v-model="objItem.IsVirtually" :value="parseInt(objItemDic.Value)" :name="'虚拟分单'+i" /><span>{{objItemDic.Name}}</span>                                            
                                            </label>
                                        </div>
                                    </div>
                                </td>
                                <td></td>
                                <td>
                                    <div>
                                        <validation-provider tag="span" name="件数" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            件数：<hc-number type="text" v-model="objItem.Piece" class="hc_text hc_text-border" @change="calcMasterBySlave();calcMasterChargeWeight();" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <validation-provider tag="span" name="重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            重量：<hc-number type="text" v-model="objItem.Weight" class="hc_text hc_text-border" @change="calcMasterBySlave();calcMasterChargeWeight();" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                    <div style="margin-top: 8px;">
                                        <validation-provider tag="span" name="方数" class="form-item-bd" rules="required|dec2|min_value:0" v-slot="{ errors }">
                                            方数：<hc-number type="text" v-model="objItem.Volume" class="hc_text hc_text-border" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div>
                                </td>
                                <td>
                                    <!-- <div>
                                        <validation-provider tag="div" name="计费重量" class="form-item-bd" rules="required|numeric" v-slot="{ errors }">
                                            计费重量：<hc-number type="text" v-model="objItem.ChargeWeight" class="hc_text hc_text-border" @change="calcMasterChargeWeightBySlave();" :disabled="objData.IsSelfCharge==0" placeholder="请输入" style="width: 70px;"></hc-number>
                                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>
                                        </validation-provider>
                                    </div> -->
                                </td>
                                <td style="vertical-align:middle;"><span class="hc_button-text" style="margin-top: 15px;" @click="removeItem(i);calcMasterBySlave();calcMasterChargeWeight();">删除</span></td>
                            </tr>
                            <tr v-show="objData.DirectOrder==2">
                                <td></td>
                                <td colspan="5"><span class="hc_button hc_button-primary hc_button-small" @click="addItem();">增加分单</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center; margin-top: 10px;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
            <!-- <el-button v-if="objData.Mode==1" size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="objData.ModeState=1;save();">提交保存并已完善数据</el-button>    -->
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        },
        C_Id:{
            type: Number,
            default: null
        },
        Mode:{  // 0:新增编辑 1:完善数据 2:重申报-原单号 3:重申报-新单号
            type: Number,
            default: 0
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            arrOutOrder_Type:[], 
            arrFlight:[],
            arrOutOrderItem:[],

            objDetail: {},
            C_IdKey: "",
            CC_IdKey: "",
            objData: {
                Mode: this.Mode,
                ModeState: null,
                Id: this.Id,                
                // C_Id: this.C_Id,
                C_Id: null,
                // CC_Id: null,

                C_IdKF: null,
                CC_IdKF: null,
                C_IdKJ: null,
                CC_IdKJ: null,                
                C_IdDM: null,
                blnC_IdDM: null,
                CC_IdDM: null,
                PreId: null,
                
                State: null,
                AL_Id: null,
                F_Id: null,
                PrimaryCode: "",
                Number: "",
                VirNumber: "",
                Type: null,
                DataFrom: null,

                IsBulkyCargo: null,
                DirectOrder: null,
                SizeInfor: "",
                Remark: "",

                // AgentName: "",
                // AgentFullName: "",
                ToCityCode: "",
                // ChangeToCityCode: "",
                // ChangeACCode: "",
                // ToCityName: "",
                // Currency: null,
                // WeightChargePayMethod: null,
                // OtherChargePayMethod: null,
                // DeclaredValue: null,
                // ACAccountInfor: "",
                // ACOtherCharge: "",

                // GoodsName: "",
                // BP_Id: null,
                Piece: null,
                Volume: null,
                Weight: null,
                ConvertStandard: null,
                IsSelfCharge: null,
                ChargeWeight: null,
                // IsOfficeGoods: null,
                // UnitPrice: null,
                // ToAddress: "",
                // FromAddress: "",
                // CustomerRemark: "",
                // CustomerNotify: "",
                // WeightCharge: null,
                // OtherCharge: null,
                // TotalCharge: null,

                SendInforTime: "",
                CarNumber: "",                
                PackageCount: null,
                ReportMoney: null,
                TransportMode: null,
                GroundAgentKJ: null,
                ECAgent: null,

                // IsSecurityCheck: "",

                // CT_Id: null,
                // CD_Id: null,
                // CarNumber: "",
                // CarWeight: null,
                // DriverName: "",
                // DriverIdCard: "",
                // DriverMobile: "",

                ItemCount: 0,

                GoToQZC: 0,
                DeleteIds: ""   // 更新时需要删除的项
            }            
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {
        switch(this.C_Id){
            case 1001:
                this.C_IdKey = "C_IdKF";
                this.CC_IdKey = "CC_IdKF";                
                break;
            case 1002:
                this.C_IdKey = "C_IdKJ";
                this.CC_IdKey = "CC_IdKJ";
                break;
            case 1004:
                this.C_IdKey = "C_IdDM";
                this.CC_IdKey = "CC_IdDM";
                break;
        }
        this.objData[this.C_IdKey] = this.C_Id;        
        this.initPage();
    },
    mounted: function(){        
        for(var i = 0; i < this.$store.state.Dictionary.objMapKey.OutOrder_Type.length; i++){
            if(this.$store.state.Dictionary.objMapKey.OutOrder_Type[i].Value != "3"){
                this.arrOutOrder_Type.push(this.$store.state.Dictionary.objMapKey.OutOrder_Type[i]);
            }            
        }
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){                  
            if(this.objData.Id == null){    
                this.objData.C_Id = this.C_Id;       
                this.objData.blnC_IdDM = false;         
                this.objData.DataFrom = 1;
                this.objData.IsBulkyCargo = 0;
                this.objData.DirectOrder = 1;
                // this.objData.Currency= 1;
                // this.objData.WeightChargePayMethod = 1;
                // this.objData.OtherChargePayMethod = 1;
                // this.objData.DeclaredValue = 1;
                // this.objData.ACOtherCharge = "[]";
                this.objData.Piece = 0;
                this.objData.Volume = 0;
                this.objData.Weight = 0;
                this.objData.ConvertStandard = 166.666;
                this.objData.IsSelfCharge = 0;
                this.objData.ChargeWeight = 0;
                // this.objData.IsOfficeGoods = 0;
                // this.objData.UnitPrice = 0;

                switch(this.objData.C_Id){
                    case 1002:  // 跨境电商     
                        this.objData.State = 10;                   
                        this.objData.Type = 2;
                        this.objData.ECAgent = 1;
                        this.objData.SendInforTime = this.$dayjs().format("YYYY-MM-DD HH:mm");
                        this.objData.TransportMode = 1;
                        this.objData.GroundAgentKJ = 1;
                        break;
                    default:
                        this.objData.State = 1;                   
                        this.objData.Type = 1;
                        break;
                    // case 1001:  // 客服
                    //     break;
                    // case 1004:  // 地面
                    //     break;
                }
                
                this.startWatch();
            }
            else{     
                this.$ajax.get('/Admin/OutOrder/GetDetail?Id=' + this.objData.Id, null,{async:false}).done(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }
                    this.objDetail = objResult;               
                    console.log(objResult);
                    for (var strKey in this.objData) {
                        switch (strKey) {
                            case "Mode":
                            case "blnC_IdDM":
                            case "GoToQZC":
                                break;     
                            // case "ACOtherCharge":
                            //     this.arrACOtherCharge = JSON.parse(objResult.data[0][strKey]);
                            //     break;
                            case "SendInforTime":
                                this.objData[strKey] = this.$lib.Format.fmtTime(objResult.data[0][strKey]);
                                break;
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }
                    switch(this.Mode){                        
                        case 3:                            
                            this.objData.PreId = this.objData.Id;
                            this.objData.Id = null;
                            break;
                    }
                    this.objData.blnC_IdDM = (this.objData["C_IdDM"]==1004);
                    


                    if(this.objData.DirectOrder==2){
                        for(var i = 0; i < objResult.extData.arrOutOrderItem.length; i++){
                            this.arrOutOrderItem.push(objResult.extData.arrOutOrderItem[i]);
                        }
                    }

                    var objWhere = {
                        "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
                        "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
                    }
                    this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                        for(var i = 0; i < objResult.data.length; i++){
                            objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                        }
                        this.arrFlight = objResult.data;
                    });
                    
                    this.startWatch(); 
                });
            }                             
        },
        save: function () {
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;        
            
            switch(this.objData.C_Id){                
                case 1002:
                    this.objData.C_IdDM = (this.objData.blnC_IdDM==true?1004:null);
                    break;                
            }

            if(this.objData.DirectOrder==2){
                var nPiece = 0;
                // var dVolume = 0;
                var nWeight = 0;
                // var nChargeWeight = 0;
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    nPiece += this.arrOutOrderItem[i].Piece;
                    // dVolume += this.arrOutOrderItem[i].Volume;
                    nWeight += this.arrOutOrderItem[i].Weight;
                    // nChargeWeight += this.arrOutOrderItem[i].ChargeWeight;
                }

                var strMessage = "";
                if(nPiece != this.objData.Piece){
                    strMessage += "分单件数" + nPiece + "与主单件数" + this.objData.Piece + "不相等;";
                }
                // if(parseFloat(dVolume.toFixed(2)) != this.objData.Volume){
                //     strMessage += "<br />分单方数" + dVolume + "与主单方数" + this.objData.Volume + "不相等;";
                // }
                if(nWeight != this.objData.Weight){
                    strMessage += "<br />分单重量" + nWeight + "与主单重量" + this.objData.Weight + "不相等;";
                }
                // if(nChargeWeight != this.objData.ChargeWeight){
                //     strMessage += "<br />分单计费重量" + nChargeWeight + "与主单计费重量" + this.objData.ChargeWeight + "不相等;";                            
                // }
                if(strMessage!=""){
                    this.$alert(strMessage, '系统提示', { dangerouslyUseHTMLString:true, type: 'warning' });
                    this.ctrForm.blnSubmit = false;  
                    return;
                }             
            }

            this.objData.ItemCount = 0;
            if(this.objData.DirectOrder == 2){  // 分单            
                this.objData.ItemCount = this.arrOutOrderItem.length;
                for(var i = 0; i < this.arrOutOrderItem.length; i++){
                    this.objData["Id" + i] = this.arrOutOrderItem[i].Id;
                    this.objData["Number" + i] = this.arrOutOrderItem[i].Number;
                    this.objData["IsInputPreplan" + i] = this.arrOutOrderItem[i].IsInputPreplan;
                    this.objData["BLPrint" + i] = this.arrOutOrderItem[i].BLPrint;
                    this.objData["IsVirtually" + i] = this.arrOutOrderItem[i].IsVirtually;

                    this.objData["Piece" + i] = this.arrOutOrderItem[i].Piece;
                    this.objData["Volume" + i] = this.arrOutOrderItem[i].Volume;
                    this.objData["Weight" + i] = this.arrOutOrderItem[i].Weight;
                    // this.objData["ChargeWeight" + i] = this.arrOutOrderItem[i].ChargeWeight;                  
                }
            }


            if(this.objData.Id != null){
                var strDeleteIds = "";
                var blnHas = false;
                for(var i = 0; i < this.objDetail.extData.arrOutOrderItem.length; i++){
                    blnHas = false;
                    for(var j = 0; j < this.arrOutOrderItem.length; j++){
                        if(this.objDetail.extData.arrOutOrderItem[i].Id == this.arrOutOrderItem[j].Id){
                            blnHas = true;
                            break;
                        }
                    }
                    if(blnHas == false){    // 需要删除的数据
                        strDeleteIds += this.objDetail.extData.arrOutOrderItem[i].Id + ",";
                    }
                }
                this.objData.DeleteIds = (strDeleteIds.length==0?"":strDeleteIds.substr(0,strDeleteIds.length-1));
            }

            this.objData.CarNumber = this.objData.CarNumber.toUpperCase();

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }

                if(this.objData.Id == null){
                    this.$ajax.post('/Admin/OutOrder/Insert', this.objData).then(objResult=> {                                
                        this.ctrForm.blnSubmit = false;
                        if(objResult.success == false){                            
                            this.$alert(objResult.message, '系统提示', { type: 'error' }); 
                            return;
                        }

                        this.$alert(objResult.message, '系统提示').then(() => { 
                            switch(this.Mode){
                                case 0: 
                                    this.$parent.search();
                                    break;
                                case 3:
                                    this.$parent.loadOrder(this.objDetail.data[0]["AL_Id"],this.objDetail.data[0]["F_Id"]);
                                    this.$parent.loadTask();
                                    break;
                            }
                            
                            this.$layer.close(this.layerid);
                        });                         
                    });
                }
                else{
                    this.$ajax.post('/Admin/OutOrder/Update', this.objData).then(objResult=> {                                  
                        this.ctrForm.blnSubmit = false;
                        if(objResult.success == false){                                    
                            this.$alert(objResult.message, '系统提示', { type: 'error' });                     
                            return;
                        }

                        this.$alert(objResult.message, '系统提示').then(() => {                             
                            switch(this.Mode){
                                case 0: this.$parent.search();break;
                                case 1: this.$parent.loadOrder();break;
                                case 2:
                                case 3:
                                    this.$parent.loadOrder(this.objDetail.data[0]["AL_Id"],this.objDetail.data[0]["F_Id"]);
                                    this.$parent.loadTask();
                                    break;
                            }
                            this.$layer.close(this.layerid);                          
                        });                        
                    });
                }                
            });
        },

        changeAirLine: function(nNew){
            this.arrFlight = [];
            this.objData.F_Id = null;
            this.objData.PrimaryCode = this.$store.state.AirLine.objMapping[nNew].PrimaryCode;
            this.objData.ToCityCode = this.$store.state.AirLine.objMapping[nNew].ToCityCode;
            
            var objWhere = {
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": nNew, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 1, "strSingleQuotes": "" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date asc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;
            });
        },
        changeDirectOrder:function(nNew){        
            this.objData.Piece = 0;
            this.objData.Volume = 0;
            this.objData.Weight = 0;
            this.objData.ChargeWeight = 0;

            this.arrOutOrderItem = [];                    
        },

        calcMasterChargeWeight: function(){ // 计算主单计费重量
            if(this.objData.IsSelfCharge==1)
                return;

            var fChargeWeight = parseInt((this.objData.Volume * this.objData.ConvertStandard).toFixed(0));
            if(fChargeWeight > this.objData.Weight){
                this.objData.ChargeWeight = fChargeWeight;
            }
            else{
                this.objData.ChargeWeight = this.objData.Weight;
            }
        },


        addItem: function(){
            this.arrOutOrderItem.push({
                Id: null,
                Number: "",
                IsInputPreplan: 1,
                BLPrint: 1,
                IsVirtually: 0,

                Piece: 0,
                Volume: 0,
                Weight: 0,
                // ChargeWeight: 0
            });
        },
        removeItem: function(nIndex){
            this.arrOutOrderItem.splice(nIndex,1);
        },
        
        calcMasterBySlave:function(){   // 根据分单计算主单数据
            var nTotalPiece = 0;
            var nTotalWeight = 0;
            // var dTotalVolume = 0;

            for(var i = 0; i < this.arrOutOrderItem.length; i++){
                nTotalPiece += this.arrOutOrderItem[i].Piece;
                nTotalWeight += this.arrOutOrderItem[i].Weight;
                // dTotalVolume += this.arrOutOrderItem[i].Volume;
            }
            this.objData.Piece = nTotalPiece;
            this.objData.Weight = nTotalWeight;
            // this.objData.Volume = parseFloat(dTotalVolume.toFixed(2));
        }
    }
}
</script>

<style scoped>
    /* .form-item-hd{width: 120px;}
    .form-item-bd{ width:calc(100% - 120px);}  */

    .table-size div:nth-of-type(odd){
        margin-right: 1%;
    }


</style>
