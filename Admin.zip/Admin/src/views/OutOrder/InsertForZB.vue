<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <hc-text-item class="col-240" v-model="objData.Number" validate="required|length:8" name="单号"></hc-text-item>
            <hc-text-item class="col-240" type="text" v-model="objData.ToCityCode" validate="required" name="目的港三字码"></hc-text-item>
            <hc-number-item class="col-240" v-model="objData.Piece" validate="required|numeric" name="件数"></hc-number-item>
            <hc-number-item class="col-240" v-model="objData.Weight" validate="required|numeric" name="重量"></hc-number-item>
            <hc-number-item class="col-240" v-model="objData.Volume" validate="required|dec2|min_value:0" name="方数"></hc-number-item>
            <hc-text-item class="col-240" v-model="objData.BoardType" name="板型"></hc-text-item>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        AL_Id:{
            type: Number,
            default: null
        },
        F_Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }        
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
   
            objData:{
                Id: this.Id,
                AL_Id: this.AL_Id,
                F_Id: this.F_Id,

                Number: "",
                ToCityCode: this.$store.state.AirLine.objMapping[this.AL_Id].ToCityCode,
                Piece: null,
                Weight: null,
                Volume: null,
                BoardType: ""
            }
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {                   
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){    
        },
        
        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/OutOrder/InsertForZB', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
    }
}
</script>

<style scoped>

</style>
