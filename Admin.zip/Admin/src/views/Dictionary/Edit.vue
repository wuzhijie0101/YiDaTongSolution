<template>
    <div style="width:100%; height: 100%;">
        <div style="height:calc(100% - 54px); overflow:auto; margin: 10px 10px 0px 10px;">        
            <validation-observer ref="form" tag="div">
            <el-form :model="objData" :rules="objRules" status-icon ref="ctrForm" size="small" label-width="100px">            
                <el-form-item label="所属父级" prop="LevelPath">
                    <el-popover placement="right" title="标题" width="200" trigger="focus">
                        <div>字段说明<br />字段说明</div>
                        <el-cascader slot="reference" expand-trigger="hover" :options="$store.getters['Dictionary/getCascader']" v-model="objData.LevelPath" :props="{value:'Id',label:'Name',children:'Children'}" clearable :change-on-select="true"></el-cascader>
                    </el-popover>                
                </el-form-item>
                <el-form-item label="类型">
                    <el-popover placement="right" trigger="focus">
                        <div>字段说明<br />字段说明</div>
                        <el-radio-group slot="reference" v-model="objData.Type">
                            <el-radio-button v-for="itmTemp in $store.state.Dictionary.objMapKey.Dictionary_Type" v-if="itmTemp.Value!='1'" :label="itmTemp.Value">{{itmTemp.Name}}</el-radio-button>                        
                        </el-radio-group>
                    </el-popover>                
                </el-form-item>
                <el-form-item label="调用Key" prop="CallKey">
                    <el-popover placement="right" trigger="hover" content="这是一段内容,这是一段内容,这是一段内容,这是一段内容。">
                        <!-- <el-button slot="reference">hover 激活</el-button> -->
                        <el-input slot="reference" v-model="objData.CallKey" clearable style="width:300px;"></el-input>
                    </el-popover>
                </el-form-item>
                <el-form-item label="名称" prop="Name">
                    <el-popover placement="right" title="标题" trigger="focus" content="这是一段内容,这是一段内容,这是一段内容,这是一段内容。">
                        <el-input slot="reference" v-model="objData.Name" clearable style="width:300px;"></el-input>
                    </el-popover>                                    
                </el-form-item>


                <el-form-item label="值" :style="'2,3,8,9'.indexOf(objData.Type)>-1?'':'display:none'">
                    <el-input v-model="objData.Value" clearable style="width:300px;"></el-input>
                </el-form-item>
                <el-form-item label="加密值" :style="'5,9'.indexOf(objData.Type)>-1?'':'display:none'">
                    <el-input v-model="objData.EncodeValue" clearable style="width:300px;"></el-input>
                </el-form-item>
                <el-form-item label="图片" :style="'6,8,9'.indexOf(objData.Type)>-1?'':'display:none'">                
                    <el-upload class="el-upload_single" :action="$lib.Config.Url_ApiUpload + '/Open/FileUpload/Upload?Directory=Dictionary&NameMode=Random&Compress=true'" :show-file-list="false" :on-success="ctrUpload_successImage" :before-upload="ctrUpload_beforeUpload" :accept="$lib.Element.Upload.strAcceptImage">
                        <img v-if="objData.Image" :src="$lib.Config.Url_ApiUpload + objData.Image" class="el-upload_single_img" />
                        <i v-else class="el-icon-plus el-upload_single_icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="附件" :style="'7,9'.indexOf(objData.Type)>-1?'':'display:none'">
                    <el-upload ref="ctrAttachment" style="max-width:500px;" :action="$lib.Config.Url_ApiUpload + '/Open/FileUpload/Upload?Directory=Dictionary&NameMode=Random&Compress=false&Ref=ctrAttachment'" :limit="3" :file-list="ctrUpload.arrAttachment" :on-success="ctrUpload_success" :before-upload="ctrUpload_beforeUpload15" :on-preview="$lib.Element.Upload.previewFile" :on-remove="ctrUpload_remove" :accept="$lib.Element.Upload.strAcceptFile">
                        <el-button size="small" type="primary">点击上传</el-button>
                        <span slot="tip" class="el-upload__tip">&nbsp;&nbsp;只能上传txt/doc/ppt/xls文件，且不超过15M</span>
                    </el-upload>
                </el-form-item>
                <el-form-item label="Html内容" :style="'4,9'.indexOf(objData.Type)>-1?'':'display:none'">                    
                    <vue-ueditor-wrap v-model="objData.HtmlContent" :destroy="true" :config="$lib.Plugin.UEditor.objConfig"></vue-ueditor-wrap>                    
                </el-form-item>
                <el-form-item label="附加值1">
                    <el-input v-model="objData.Value1" clearable></el-input>
                </el-form-item>
                <el-form-item label="附加值2">
                    <el-input v-model="objData.Value2" clearable></el-input>
                </el-form-item>
                <el-form-item label="附加值3">
                    <el-input v-model="objData.Value3" clearable></el-input>
                </el-form-item>
                <el-form-item label="附加值4">
                    <el-input type="textarea" v-model="objData.Value4" clearable></el-input>
                </el-form-item>
                <el-form-item label="排序">
                    <el-input-number v-model="objData.Sort" :min="1"></el-input-number>
                </el-form-item>
                <el-form-item label="启用">
                    <el-radio-group v-model="objData.Enable">
                        <el-radio-button v-for="itmTemp in $store.state.Dictionary.objMapKey.Enable" :label="itmTemp.Value">{{itmTemp.Name}}</el-radio-button>                    
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="备注">
                    <el-input v-model="objData.Remark" clearable></el-input>
                </el-form-item>
                
            </el-form>
            </validation-observer>
        </div>
        <div class="hc-bg_gray" style="height:44px; line-height:44px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>    
</template>

<script>

export default {    
    data: function() {
        return{
            ctrForm: {
                blnSubmit: false
            },
            ctrUpload: {                                
                arrAttachment: [],     // 单个文件                
                blnDialogVisible: false,
                strDialogImageUrl: ''
                //strAcceptImage: Lib.Element.Upload.strAcceptImage,
                //strAcceptFile: Lib.Element.Upload.strAcceptFile
            },
            // ctrCascader: {
            //     arrDictionary: []
            //     //arrDictionaryArray: []                
            // },           
            objData: {
                Id: this.Id,
                ParentId: this.ParentId,
                LevelPath: [],                
                Type: null,
                CallKey: "",
                Name: "",
                Value: "",
                EncodeValue: "",
                Image: "",
                Attachment: "",
                HtmlContent: '',
                Value1: "",
                Value2: "",
                Value3: "",
                Value4: "",
                Sort: 1,
                Remark: "",
                Enable: 1
            },
            objRules: {
                LevelPath: [{ type: 'array', required: true, message: '请选择所属父级。', trigger: 'change' }],
                // Type: [{ required: true, message: '必填。', trigger: 'blur' }],
                Name: [{ required: true, message: '请输入名称。', trigger: 'change' }],
                // CallKey: [{ validator: this.$lib.Valid.Async.validUnique("/JDY/Dictionary/ValidUniqueCallKey?Id=" + (this.Id==null?'':this.Id), "您好，调用Key重复，请更换其他Key。"), trigger: 'blur' }]
                // Enable: [{ required: true, message: '请选择启用。', trigger: 'change' }]
            }
        }
    },
    props:{
        Id:{
            type: Number,
            default: null
        },
        ParentId:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {},
    watch: {
        "objData.LevelPath": function (arrValue) {
            if (arrValue.length == 0) {
                this.objData.ParentId = null;
            }
            else {
                this.objData.ParentId = arrValue[arrValue.length - 1];
            }
            console.log(this.objData.ParentId);
        },
        "objData.ParentId": function (strValue) {
            if(this.objData.Id != null) // 编辑则不执行
                return;

            if (this.objData.Type == "2" && strValue != null) {                
                this.$ajax.get('/SYS/Dictionary/GetCodeValue', { ParentId: strValue }).then(objResult => {
                    if (objResult.success == true) {
                        this.objData.Value = objResult.data;
                    }
                    else {
                        this.objData.Value = "";
                    }
                });
            }
        },
        "objData.Type": function (strValue) {  
            if(this.objData.Id != null)  // 编辑则不执行
                return;

            this.objData.Value = "";
            if (strValue == "2" && this.objData.ParentId != null) {
                this.$ajax.get('/SYS/Dictionary/GetCodeValue', { ParentId: this.objData.ParentId }).then(objResult => {
                    if (objResult.success == true) {
                        this.objData.Value = objResult.data;
                    }
                });
            }
        }
    },
    created: function() {              
    },
    mounted: function(){
        this.initPage();
        this.objData.Type = 2;
    },
    destroyed: function() {},
    methods:{    
        // previewFile: function (docFile) {
        //     console.log(docFile);
        //     window.open(this.$config.Url_ApiUpload + docFile.url);
        // },
        initPage:function(){
            if(this.objData.Id == null){                
                this.objData.LevelPath = this.$lib.Element.Cascader.getArrayValue(this.$store.state.Dictionary.arrData, this.objData.ParentId);                    
                // this.objData.Type = 2;
            }
            else{
                this.$ajax.get('/SYS/Dictionary/GetById?Id=' + this.objData.Id).then(objResult=> {                                        
                    if (objResult.success == true) {
                        for (var strKey in this.objData) {
                            switch (strKey) {
                                case "LevelPath":                                    
                                    this.objData[strKey] = this.$lib.Common.split(objResult.data[0][strKey], ",", true);                                    
                                    break;
                                case "Attachment":
                                    this.$lib.Element.Upload.loadMuit(strKey, objResult.data[0][strKey], this);
                                    // var arrTemp = this.$lib.Common.split(objResult.arrData[0][strKey]);
                                    // for (var i = 0; i < arrTemp.length; i++) {
                                    //     this.ctrUpload.arrAttachment.push({ name: arrTemp[i].substr(arrTemp[i].lastIndexOf("/") + 1), url: arrTemp[i], ref: "ctrAttachment" });
                                    // }
                                    break;
                                // case "HtmlContent":
                                //     objTemp = UE.getEditor(strKey);
                                //     objTemp.ready(function () {
                                //         objTemp.setContent(objResult.data.arrData[0][strKey]);
                                //     });
                                //     break;
                                default:
                                    this.objData[strKey] = objResult.data[0][strKey];
                                    break;
                            }
                        }                        
                    }
                    else{
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                    }
                });
            }            
        },
        save: function () {            
            this.ctrForm.blnSubmit = true;            
            this.objData.Attachment = this.$lib.Element.Upload.getUrl(this.ctrUpload.arrAttachment);      
            // this.objData.HtmlContent = UE.getEditor("HtmlContent").getContent();
            
            if(this.objData.Id==null){
                this.$lib.CURD.insert(this, "/SYS/Dictionary/Insert");
            }
            else{
                this.$lib.CURD.update(this, "/SYS/Dictionary/Update");
            }
        },
        // ctrTree_formatter: function (arrData) {
        //     for (var i = 0; i < arrData.length; i++) {
        //         arrData[i].strName = arrData[i].strName + (arrData[i].nEnable == 0 ? " [禁用]" : "");
        //         if (arrData[i].arrChildren.length > 0) {
        //             this.ctrTree_formatter(arrData[i].arrChildren);
        //         }
        //     }
        // },
        ctrUpload_successImage: function (objResult, docFile, arrFileList) {
            this.objData.Image = objResult.data;
        },

        ctrUpload_beforeUpload: function (docFile) {            
            return this.$lib.Element.Upload.beforeUpload(docFile, 5, this);
        },
        ctrUpload_beforeUpload15: function (docFile) {            
            return this.$lib.Element.Upload.beforeUpload(docFile, 15, this);
        },
        ctrUpload_success: function (objResult, docFile, arrFileList) {            
            return this.$lib.Element.Upload.success(objResult, docFile, arrFileList, this);
        },
        ctrUpload_remove: function (docFile, arrFileList) {            
            return this.$lib.Element.Upload.remove(docFile, arrFileList, this);
        },
    }
}
</script>

<style scoped>
    
</style>
