<template>
    <div style="width:100%; height: 100%;">
        <div style="height:calc(100% - 54px); overflow:auto; margin: 10px 10px 0px 10px;">
            <validation-observer ref="form" tag="div">
            <el-form :model="objData" :rules="objRules" status-icon ref="ctrForm" size="small" label-width="100px">
                <el-form-item label="所属父级">
                    <!-- <el-cascader expand-trigger="hover" :options="ctrCascader.arrDictionary" v-model="objData.LevelPath" :props="{value:'nId',label:'strName',children:'arrChildren'}" clearable :change-on-select="true"></el-cascader> -->
                    <el-cascader expand-trigger="hover" :options="$store.getters['Dictionary/getCascader']" v-model="objData.LevelPath" :props="{value:'Id',label:'Name',children:'Children'}" clearable :change-on-select="true"></el-cascader>
                </el-form-item>
                <el-form-item label="调用Key" prop="CallKey">
                    <el-input v-model="objData.CallKey" clearable style="width:300px;"></el-input>
                </el-form-item>
                <el-form-item label="名称" prop="Name">
                    <el-input v-model="objData.Name" clearable style="width:300px;"></el-input>
                </el-form-item>            
                <el-form-item label="排序">
                    <el-input-number v-model="objData.Sort" :min="1"></el-input-number>
                </el-form-item>
                <el-form-item label="启用">
                    <el-radio-group v-model="objData.Enable">                    
                        <el-radio-button v-for="itmTemp in $store.state.Dictionary.objMapKey.Enable" :label="itmTemp.Value">{{itmTemp.Name}}</el-radio-button>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="备注">
                    <el-input v-model="objData.Remark" clearable></el-input>
                </el-form-item>
                
            </el-form>
            </validation-observer>
        </div>
        <div class="hc-bg_gray" style="height:44px; line-height:44px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>    
</template>

<script>
export default {    
    data: function() {
        return{
            ctrForm: {
                blnSubmit: false
            },
            // ctrCascader: {
            //     arrDictionary: []
            //     //arrDictionaryArray: []
            // },
            objData: {
                Id: this.Id,
                ParentId: this.ParentId,
                LevelPath: [],
                Type: 1,
                CallKey: "",
                Name: "",
                Sort: 1,
                Remark: "",
                Enable: 1
            },
            objRules: {
                //LevelPath: [{ type: 'array', required: true, message: '请选择所属父级。', trigger: 'change' }],
                CallKey: [{ validator: this.$lib.Valid.Async.validUnique("/SYS/Dictionary/ValidUniqueCallKey?Id=" + (this.Id==null?'':this.Id), "您好，调用Key重复，请更换其他Key。"), trigger: 'blur' }],
                Name: [{ required: true, message: '请输入名称。', trigger: 'change' }]
                // Sort: [],
                // Enable: [{ required: true, message: '请选择启用。', trigger: 'change' }]
            }
        }
    },
    props:{
        Id:{
            type: Number,
            default: null
        },
        ParentId:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {},
    watch: {
        "objData.LevelPath": function (arrValue) {
            if (arrValue.length == 0) {
                //this.objData.ParentId = null;
                this.objData.ParentId = -1;
            }
            else {
                this.objData.ParentId = arrValue[arrValue.length - 1];
            }
        }
    },
    created: function() {          
    },
    mounted: function(){   
        this.initPage();
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){      
            if(this.objData.Id==null){   
                this.objData.LevelPath = this.$lib.Element.Cascader.getArrayValue(this.$store.state.Dictionary.arrData, this.objData.ParentId);
            }
            else{
                this.$ajax.get('/SYS/Dictionary/GetById?Id=' + this.objData.Id).then(objResult=> {                                        
                    if (objResult.success == true) {
                        for (var strKey in this.objData) {
                            switch (strKey) {
                                case "LevelPath":         
                                    this.objData[strKey] = this.$lib.Common.split(objResult.data[0][strKey], ",", true);                                    
                                    break;
                                default:
                                    this.objData[strKey] = objResult.data[0][strKey];
                                    break;
                            }
                        }                        
                    }
                    else{
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                    }
                });
            }
                     
        },        
        save: function () {                      
            this.ctrForm.blnSubmit = true;            

            if(this.objData.Id==null){
                this.$lib.CURD.insert(this, "/SYS/Dictionary/Insert?GetId=true", objResult => {
                    this.objData.Id = objResult.data;
                    this.$parent.$refs["treList"].append({ Id: this.objData.Id, Name: objResult.data + "_" + this.objData.Name, ParentId: this.objData.ParentId }, (this.objData.ParentId == -1 ? "" : this.objData.ParentId));                         
                    this.$store.commit('Dictionary/insert', this.objData);

                    this.$parent.search();
                    this.$layer.close(this.layerid);
                });
            }
            else{
                this.$lib.CURD.update(this, "/SYS/Dictionary/Update", objResult => {
                    this.$parent.$refs["treList"].getNode(this.objData.Id).data.Name = this.objData.Id + "_" + this.objData.Name;
                    this.$store.commit('Dictionary/update', this.objData);

                    this.$parent.search();
                    this.$layer.close(this.layerid);
                });
            }
        }
        // ctrTree_formatter: function (arrData) {
        //     for (var i = 0; i < arrData.length; i++) {
        //         arrData[i].strName = arrData[i].strName + (arrData[i].nEnable == 0 ? " [禁用]" : "");
        //         if (arrData[i].arrChildren.length > 0) {
        //             this.ctrTree_formatter(arrData[i].arrChildren);
        //         }
        //     }
        // }
    }
}
</script>

<style scoped>

</style>
