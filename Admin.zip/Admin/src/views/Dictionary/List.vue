<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">
        <div style="float:left; width:210px; height:100%; background:#ffffff;">
            <div style="height:50px; text-align:center; padding:10px;">
                <el-button-group>
                    <el-button type="success" size="small" @click="editParent(null,$refs['treList'].getCurrentNode().Id);">新增</el-button>
                    <el-button type="success" size="small" @click="editParent($refs['treList'].getCurrentNode().Id,null);">编辑</el-button>
                    <el-button type="danger" size="small" @click="deleteParent($refs['treList'].getCurrentNode().Id);">删除</el-button>
                </el-button-group>
            </div>            
            <div style="height:calc(100% - 50px); overflow-y:auto; border-top:1px solid #eeeeee;">
                <el-input placeholder="请输入过滤关键字" size="small" v-model="ctrTree.strFilterName" style="padding:10px 10px;" clearable></el-input>
                <el-tree :data="ctrTree.arrData" ref="treList" :current-node-key="0" node-key="Id" :props="ctrTree.objDefaultProps" :expand-on-click-node="false" default-expand-all :filter-node-method="$lib.Element.Tree.filterNode" @current-change="ctrTree_currentChange"></el-tree>
            </div>
        </div>
        

        <div style="float:left; width:calc(100% - 220px); height:100%; margin-left:10px;">
            <div style="height:50px; padding:10px; background:#ffffff;">
                <div style="float:left;">
                    <el-input v-model="ctrTable.objParam.Where.CallKey.strValue" clearable size="small" placeholder="调用Key关键字" @clear="search();" style="width:150px"></el-input>
                    <el-select multiple v-model="ctrTable.objParam.Where.Type.arrValue" clearable size="small" placeholder="类型" @clear="search();">
                        <el-option v-for="itmTemp in $store.state.Dictionary.objMapKey.Dictionary_Type" :label="itmTemp.Name" :value="itmTemp.Value"></el-option>
                    </el-select>
                    <el-checkbox-group v-model="ctrTable.objParam.Where.Enable.arrValue" size="small" style="display:inline-block;">
                        <el-checkbox-button v-for="itmTemp in $store.state.Dictionary.objMapKey.Enable" :label="itmTemp.Value">{{itmTemp.Name}}</el-checkbox-button>                  
                    </el-checkbox-group>
    
                    <el-button type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
                </div>
                <div style="float:right;">
                    <el-button-group>
                        <el-button type="success" size="small" icon="el-icon-circle-plus-outline" @click="edit(null,$refs['treList'].getCurrentNode().Id);">新增</el-button>
                        <el-button type="success" size="small" icon="el-icon-edit-outline" @click="edit(ctrTable.objCurrentRow.Id,null);">编辑</el-button>
                        <el-button type="danger" size="small" icon="el-icon-circle-close-outline" @click="deleteData(ctrTable.objCurrentRow.Id)">删除</el-button>
                    </el-button-group>
                </div>
                <div style="clear:both;"></div>
            </div>
            <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
                <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">
                    <!-- <el-table-column type="selection" width="55"></el-table-column> -->
                    <el-table-column prop="Id" label="编号" width="70" sortable="custom"></el-table-column>
                    <el-table-column prop="Type" label="类型" width="90" sortable="custom" column-key="Dictionary_Type" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Dictionary_Type')" filter-placement="bottom-end"></el-table-column>
                    <el-table-column prop="CallKey" label="调用Key" width="150" sortable="custom" show-overflow-tooltip></el-table-column>
    
                    <el-table-column prop="Name" label="名称" width="150"></el-table-column>
                    <el-table-column prop="Value" label="值" width="60" sortable="custom"></el-table-column>
                    <el-table-column prop="EncodeValue" label="加密值" width="70"></el-table-column>
                    <el-table-column prop="Image" label="图片" width="100">
                        <template slot-scope="scope">
                            <span v-html="$lib.Format.fmtImage(scope.row.Image,',','height:50px;')"></span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="Attachment" label="附件" width="100">
                        <template slot-scope="scope">
                            <span v-html="$lib.Format.fmtFileName(scope.row.Attachment,',')"></span>
                        </template>
                    </el-table-column>
    
                    <el-table-column prop="Value1" label="附加值1" width="70"></el-table-column>
                    <el-table-column prop="Value2" label="附加值2" width="70"></el-table-column>
                    <el-table-column prop="Value3" label="附加值3" width="70"></el-table-column>
                    <el-table-column prop="Value4" label="附加值4" width="70"></el-table-column>
    
                    <el-table-column prop="Sort" label="排序" width="70" sortable="custom"></el-table-column>                
                    <el-table-column prop="Enable" label="启用" width="60" column-key="Enable" :formatter="$lib.Element.Table.formatter" :filters="$lib.Element.Table.getFilters('Enable')" filter-placement="bottom-end"></el-table-column>
                    <el-table-column prop="Remark" label="备注" min-width="100%" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="UpdateTime" label="更新时间" width="150" sortable="custom" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                    <el-table-column prop="CreateTime" label="创建时间" width="150" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                </el-table>
                <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
            </div>
        </div>

        <div style="clear:both;"></div>
    </div>    
</template>

<script>
import DictionaryEdit from '@/views/Dictionary/Edit.vue';
import DictionaryEditParent from '@/views/Dictionary/EditParent.vue';

export default {
    // name: 'Template',         // 最好不要改属性
    data: function() {
        return{                  
            ctrTree: {
                //blnLoad: false,     // 删除时候的加载提示
                strFilterName: '',
                objDefaultProps: {
                    label: 'Name',
                    children: 'Children'
                },
                arrData: this.$store.getters['Dictionary/getTree']
                //arrDataArray: []
            },
            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Id desc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {
                        "ParentId": { "strField": "ParentId", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "CallKey": { "strField": "CallKey", "strCondition": "like", "strValue": "", "strSingleQuotes": "'" },
                        "Enable": { "strField": "Enable", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] },
                        "Type": { "strField": "Type", "strCondition": "in", "strValue": "", "strSingleQuotes": "", arrValue: [] }
                    },
                    OrderBy: "Sort desc,Id asc"
                },

                //blnLoad: false,         // 删除时候的加载提示
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection: []    // 复选框多选行
            }
        }
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性
            return this.ctrTable.objParam.Where.ParentId.strValue + this.ctrTable.objParam.Where.Enable.arrValue + this.ctrTable.objParam.Where.Type.arrValue;
        }
    },
    watch: {
        "ctrTree.strFilterName": function (strValue) {
            this.$refs.treList.filter(strValue);
        },
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        },
        // "$store.state.Dictionary.arrData":function(strValue){
        //     if(this.ctrTree.arrData==null){
        //         this.ctrTree.arrData = this.$store.getters['Dictionary/getTree'];
        //     }
        // }
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){   
        
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){     
            this.search();            
        },
        search: function (blnIsReload) {

            if (blnIsReload != true) {
                this.ctrTable.objParam.Page = 1;
            }

            this.ctrTable.objParam.Where.Enable.strValue = "" + this.ctrTable.objParam.Where.Enable.arrValue;
            this.ctrTable.objParam.Where.Type.strValue = "" + this.ctrTable.objParam.Where.Type.arrValue;
            
            this.$ajax.get('/SYS/Dictionary/GetPage', this.ctrTable.objParam).then(objResult=> {                   
                if (objResult.success == true) {
                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                    if (this.ctrTable.nTotal > 0) {
                        this.$refs.tblList.setCurrentRow(this.ctrTable.arrData[0]);
                    }
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });            
        },
        edit:function(nId,nParentId){ // 新增或编辑     
            if(nId != null && this.ctrTable.objCurrentRow.Type==1){
                this.$alert('不能用该功能编辑类型为父级的数据。', '错误提示', { type: 'error' });
                return;
            }

            this.$layer.iframe({
                content: {
                    content: DictionaryEdit,
                    parent: this,
                    data:{ Id:nId, ParentId:nParentId} 
                },
                area:['60%','90%'],
                shadeClose: false,
                title: (nId==null?'新增':'编辑')
            });
        },
        deleteData: function (nId) { // 删除,函数不取名为delete是因为vue的@click绑定函数名称不能为关键字,而delete为关键字
            if(this.ctrTable.objCurrentRow.Type==1){
                this.$alert('不能用该功能删除类型为父级的数据。', '错误提示', { type: 'error' });
                return;
            }
            this.$lib.Vue.delete(this, "/SYS/Dictionary/Delete?Id=" + nId);
        },

        

        ctrTable_sortChange: function (objSort) {   // 表格排序
            this.$lib.Element.Table.sortChange(objSort, this);
        },
        ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
            this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
        },
        ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
            this.$lib.Element.Table.selectionChange(selection, this);
        },
        ctrTable_filterChange: function (objFilters) {    // 列过滤
            this.$lib.Element.Table.filterChange(objFilters, this);            
        },

        ctrPage_sizeChange: function (nValue) { // 页码改变
            this.$lib.Element.Page.sizeChange(nValue, this);         
        },
        ctrPage_currentChange: function (nValue) {  // 当前页改变 
            this.$lib.Element.Page.currentChange(nValue, this);
        },


        editParent:function(nId,nParentId){ // 新增或编辑     
            if(nId==0) 
                return;
            
            this.$layer.iframe({
                content: {
                    content: DictionaryEditParent,
                    parent: this,
                    data:{ Id:nId, ParentId:nParentId} 
                },
                // area: ['1000px', '600px'],
                area:['60%','60%'],
                shadeClose: false,
                title: (nId==null?'新增父级':'编辑父级')
            });
        },
        deleteParent: function (nId) { // 删除
            this.$lib.Vue.delete(this, "/SYS/Dictionary/Delete?Id=" + nId, objResult => {
                if (objResult.success == true) {
                    var nodeCurrent = this.$refs['treList'].getCurrentNode();
                    this.$refs['treList'].remove(nodeCurrent.Id);
                    this.$refs['treList'].setCurrentKey(nodeCurrent.ParentId);   
                    this.$store.commit("Dictionary/delete",nId);
                }
                else{
                    this.$alert(objResult.message, '错误提示', { type: 'error' });
                }
            });
        },        
        // ctrTree_formatter: function (arrData) { // 树格式化
        //     for (var i = 0; i < arrData.length; i++) {
        //         arrData[i].strName = arrData[i].nId + "_" + arrData[i].strName + (arrData[i].nEnable == 0 ? " [禁用]" : "");
        //         if (arrData[i].arrChildren.length > 0) {
        //             this.ctrTree_formatter(arrData[i].arrChildren);
        //         }
        //     }
        // },
        ctrTree_currentChange: function (newData, newNode) {    // 树当前项变化事件
            if (newData.Id != this.ctrTable.objParam.Where.ParentId.strValue) {
                this.ctrTable.objParam.Where.ParentId.strValue = (newData.Id == 0 ? "" : newData.Id);
            }
        }

    }
}

</script>

<style scoped>

</style>
