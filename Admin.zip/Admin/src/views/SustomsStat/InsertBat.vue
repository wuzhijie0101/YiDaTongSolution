<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">
                
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航班</div>                    
                    <div class="form-item-bd">
                        <el-select v-model="objData.F_Id" filterable clearable placeholder="所属航班" style="width: 200px;">
                            <el-option v-for="(objItem,i) in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>    
                        </el-select>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{    
        layerid: {
            type: String,
            default: ""
        } 
    },
    data: function() {
        return{         
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },

            arrFlight:[],  
            objData:{
                AL_Id: 1000,               
                F_Id: null
            }
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {        
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){    
            var objWhere = {
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 2, "strSingleQuotes": "" },
                "Date": { "strField": "Date", "strCondition": ">=", "strValue": this.$dayjs().add(-1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date desc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;
                this.objData.F_Id = this.arrFlight[0].Id;
            });
        },

        save: function(){
            if(this.ctrForm.blnSubmit == true){
                return;
            }
            this.ctrForm.blnSubmit = true;

            this.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    this.ctrForm.blnSubmit = false;
                    return;
                }
            
                this.$ajax.post('/Admin/SustomsStat/InsertBat', this.objData).then(objResult=> {                                  
                    this.ctrForm.blnSubmit = false;
                    if(objResult.success == false){                                                            
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                       
                        return;
                    }

                    this.$alert(objResult.message , '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: ()=> {
                            this.$parent.search();
                            this.$layer.close(this.layerid);
                        }
                    });
                });
            });                        
        }
        
    }
}
</script>

<style scoped>

</style>
