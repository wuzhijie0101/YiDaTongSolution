<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid hc_form-pc" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row">
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航班</div>                    
                    <div class="form-item-bd">
                        <el-select v-model="objData.F_Id" filterable clearable placeholder="所属航班" style="width: 200px;" @change="changeF_Id">
                            <el-option v-for="(objItem,i) in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>    
                        </el-select>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                
                <hc-text-item class="col-240" v-model="objData.Number" validate="required|length:8" name="提单号"></hc-text-item>
                <hc-text-item class="col-240" v-model="objData.CustomsNumber" validate="required" name="报关单号"></hc-text-item>
                <hc-text-item class="col-240" v-model="objData.Area" validate="required" name="归属地"></hc-text-item>
                <hc-number-item class="col-240" v-model="objData.Weight" validate="required|numeric" name="货重"></hc-number-item>
                <hc-number-item class="col-240" v-model="objData.ReportMoney" validate="required|dec2|min_value:0" name="申报总价"></hc-number-item>  
                <hc-text-item class="col-240" v-model="objData.ThreeCode" validate="required" name="三字代码"></hc-text-item>
                <hc-text-item class="col-240" v-model="objData.CompanyName" name="公司名"></hc-text-item>
                <hc-text-item class="col-240" v-model="objData.GoodsName" name="品名"></hc-text-item>
                
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{           
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },

            arrFlight:[], 
            objData: {                                
                Id: this.Id,
                AL_Id: 1000,               
                F_Id: null,
                F_Date: "",
                F_Number: "",
                Number: "",
                CustomsNumber: "",
                Area: "",
                Weight: null,
                ReportMoney: null,
                ThreeCode: "",
                CompanyName: "",
                GoodsName: ""
            }   
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {              
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        changeF_Id:function(){
            this.objData.F_Date = this.$store.state.Flight.objMapping[this.objData.F_Id].Date;
            this.objData.F_Number = this.$store.state.Flight.objMapping[this.objData.F_Id].Number;
        },
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){       
            var objWhere = {
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 2, "strSingleQuotes": "" },
                "Date": { "strField": "Date", "strCondition": ">=", "strValue": this.$dayjs().add(-1,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date desc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;
                this.objData.F_Id = this.arrFlight[0].Id;
            });

            if(this.objData.Id == null){
                this.objData.Area = "长沙市";
                this.startWatch(); 
            }
            else{
                this.$ajax.get('/Admin/SustomsStat/GetById?Id=' + this.objData.Id).done(objResult=> {
                    if (objResult.success == false) {
                        this.$alert("您好，数据获取失败，请稍后再进行该项操作。", '错误提示', { type: 'error' });
                        return;                                      
                    }

                    for (var strKey in this.objData) {
                        switch (strKey) {                            
                            default:
                                this.objData[strKey] = objResult.data[0][strKey];
                                break;
                        }
                    }
                    
                    this.startWatch(); 
                });
            }                             
        },
        save: function () {
            if(this.objData.Id==null){
                this.$lib.CURD.insert(this, "/Admin/SustomsStat/Insert");
            }
            else{
                this.$lib.CURD.update(this, "/Admin/SustomsStat/Update");
            }
        },
    }
}
</script>

<style scoped>    
</style>
