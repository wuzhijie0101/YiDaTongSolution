<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">                
                <template v-if="Operate==1">      
                <div class="col-240 form-item">
                    <div class="form-item-hd">所属航班</div>                    
                    <div class="form-item-bd">
                        <el-select v-model="objData.F_Id" filterable clearable placeholder="所属航班" style="width: 200px;">
                            <el-option v-for="(objItem,i) in arrFlight" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>    
                        </el-select>
                        <span class="hc_button-text" @click="batDelete();">删除当前航班数据</span>
                    </div>
                    <div class="form-item-ft"></div>
                </div>                                     
                <div class="col-240 form-item">
                    <div class="form-item-hd">总表导入</div>                    
                    <div class="form-item-bd">
                        <file-pond ref="upZongBiao" @processfile="handleProcessFile" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportSustomsStat?F_Id='+objData.F_Id" label-idle="点击导入总表数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                    </div>
                    <div class="form-item-ft"></div>
                </div>
                </template>
                <template v-else-if="Operate==2">                    
                    <div class="col-240 form-item">
                        <div class="form-item-hd">行业分类导入</div>                    
                        <div class="form-item-bd">                        
                            <file-pond ref="upShengNei" @processfile="handleProcessFileShengNei" :allow-multiple="false" max-files="1" allow-drop="true" max-file-size="5MB" :server="$lib.Config.Url_ApiRequest + '/Admin/ImportData/ImportSustomsStatSN'" label-idle="点击导入行业分类数据" accepted-file-types="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></file-pond>
                        </div>
                        <div class="form-item-ft"></div>
                    </div>
                </template>
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">关 闭</el-button>
        </div>
    </div>
</template>

<script>

export default {
    props:{    
        Operate:{
            type: Number,
            default: null
        },        
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{     
            arrFlight:[],      
            objData:{
                AL_Id: 1000,
                F_Id: null          
            }            
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {              
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){    
            var objWhere = {
                "AL_Id": { "strField": "AL_Id", "strCondition": "=", "strValue": this.objData.AL_Id, "strSingleQuotes": "" },
                "State": { "strField": "State", "strCondition": "=", "strValue": 2, "strSingleQuotes": "" },
                "Date": { "strField": "Date", "strCondition": ">=", "strValue": this.$dayjs().add(-3,'month').format('YYYY-MM-DD'), "strSingleQuotes": "'" },
            }
            this.$ajax.get('/Admin/Flight/Get', { Field: "*", Where:objWhere, OrderBy:"Date desc" }).then(objResult => {
                for(var i = 0; i < objResult.data.length; i++){
                    objResult.data[i].Date = this.$lib.Format.fmtDate(objResult.data[i].Date);
                }
                this.arrFlight = objResult.data;
                this.objData.F_Id = this.arrFlight[0].Id;
            });
        },

        handleProcessFile: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upZongBiao"].removeFile(file.id);                
            }
        },
        handleProcessFileShengNei: function (error, file) {
            var objResult = JSON.parse(file.serverId);

            if (objResult.success == true) {
                this.$alert(objResult.message, '系统提示', { type: 'success' });                
            }
            else {
                this.$alert(objResult.message, '系统提示', { type: 'error' });
                this.$refs["upShengNei"].removeFile(file.id);                
            }
        },
        batDelete: function(){
            this.$confirm("确定全部删除该航班已导入的报关单数据吗？", '系统提示', { type: 'warning' }).then( ()=> {
                this.$ajax.post("/Admin/SustomsStat/BatDelete?F_Id=" + this.objData.F_Id).then(objResult=> {                      
                    if(objResult.success == false){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                      
                        return;
                    }

                    this.$notify({title: '系统提示',message: "批量删除成功",type: 'success'});                                         
                });
            }).catch(function () {
            });
        },
    }
}
</script>

<style scoped>

</style>
