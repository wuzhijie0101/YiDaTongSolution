<template>
    <div class="hc-bg_gray" style="padding:10px; height:100%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                
                <el-select v-model="ctrTable.objParam.Where.F_Id.strValue" filterable clearable placeholder="航班号" style="width: 160px;">
                    <el-option v-for="objItem in $lib.Common.getArrByField($store.state.Flight.arrData,'AL_Id',1000)" :key="objItem.Id" :label="objItem.Date+'_'+objItem.Number" :value="objItem.Id"></el-option>
                </el-select>
                <el-date-picker v-model="ctrTable.objParam.Where.F_Date_Start.strValue" type="date" clearable value-format="yyyy-MM-dd 00:00:00" placeholder="航班开始时间" style="width:120px;"></el-date-picker>
                <el-date-picker v-model="ctrTable.objParam.Where.F_Date_End.strValue" type="date" clearable value-format="yyyy-MM-dd 23:59:59" placeholder="航班结束时间" style="width:120px;"></el-date-picker>            

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-input v-model="ctrTable.objParam.Where.Number.strValue" clearable placeholder="提单号关键字" @change="search();" style="width:125px"></el-input>    
                <el-button-group>
                    


                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,2)" type="success" size="small" icon="el-icon-edit-outline" @click="edit(ctrTable.objCurrentRow.Id, null);">编辑</el-button>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,1)" type="success" size="small" icon="el-icon-circle-plus-outline" @click="openSustomsStatInsertBat();">批量新增</el-button>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,1)" type="success" size="small" icon="el-icon-circle-plus-outline" @click="edit(null);">新增</el-button>                    
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,4)" type="danger" size="small" icon="el-icon-circle-close-outline" @click="deleteData(ctrTable.objCurrentRow.Id)">删除</el-button>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" icon="el-icon-download" @click="exportExcel();">导出Excel</el-button>
                </el-button-group>            
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <el-table ref="tblList" size="mini" :data="ctrTable.arrData" stripe border highlight-current-row @sort-change="ctrTable_sortChange" @current-change="ctrTable_currentChange" @filter-change="ctrTable_filterChange" empty-text="查询无数据，请修改条件再进行查询。" style="width:100%; height:calc(100% - 40px);">
                <el-table-column prop="Id" label="编号" width="60"></el-table-column>
                <el-table-column prop="F_Date" label="航班日期" width="90"></el-table-column>
                <el-table-column prop="F_Number" label="航班号" width="70"></el-table-column>
                <el-table-column prop="Number" label="提单号" width="100"></el-table-column>
                <el-table-column prop="CustomsNumber" label="报关单编号" width="170"></el-table-column>
                <el-table-column prop="Area" label="归属地" width="70"></el-table-column>
                <el-table-column prop="Weight" label="货重" width="70" align="right"></el-table-column>
                <el-table-column prop="ReportMoney" label="申报总价" width="95" align="right"></el-table-column>
                <el-table-column prop="ThreeCode" label="三字代码" width="75"></el-table-column>
                <el-table-column prop="CompanyName" label="公司名" width="200"></el-table-column>
                <el-table-column prop="GoodsName" label="品名" width="200"></el-table-column>
                
                <el-table-column prop="UpdateTime" label="更新时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
                <el-table-column prop="CreateTime" label="创建时间" width="145" :formatter="$lib.Element.Table.fmtTime"></el-table-column>
            </el-table>
            <el-pagination style="text-align:center; margin-top:3px;" background @size-change="ctrPage_sizeChange" @current-change="ctrPage_currentChange" :current-page="ctrTable.objParam.Page" :page-sizes="[10, 20, 30, 50]" :page-size="ctrTable.objParam.Size" :total="ctrTable.nTotal" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
        </div>
    </div>    
</template>

<script>
import SustomsStatEdit from '@/views/SustomsStat/Edit.vue';
import SustomsStatInsertBat from '@/views/SustomsStat/InsertBat.vue';

export default {
    data: function() {
        return{
            PM_Id: 339,

            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Id desc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {        
                        "F_Id": { "strField": "F_Id", "strCondition": "=", "strValue": "", "strSingleQuotes": "" },
                        "Number": { "strField": "Number", "strCondition": "like", "strValue": "", "strSingleQuotes": "'" },
                        "F_Date_Start": { "strField": "F_Date", "strCondition": ">=", "strValue": "", "strSingleQuotes": "'" },                                                
                        "F_Date_End": { "strField": "F_Date", "strCondition": "<", "strValue": "", "strSingleQuotes": "'" },
                    },
                    OrderBy: "Id desc"
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
            return this.ctrTable.objParam.Where.F_Id.strValue + this.ctrTable.objParam.Where.F_Date_Start.strValue + this.ctrTable.objParam.Where.F_Date_End.strValue;          
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){            
            this.search();            
        },

        exportExcel:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportSustomsStat?token="+localStorage.getItem("strToken")+"&Where=" + JSON.stringify(this.ctrTable.objParam.Where);            
        },
        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }
            if (blnIsReload != true) {
                this.ctrTable.objParam.Page = 1;
            }            

            this.$ajax.get('/Admin/SustomsStat/GetPage', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == true) {
                    for(var i = 0; i < objResult.data.length; i++){
                        objResult.data[i].F_Date = this.$lib.Format.fmtDate(objResult.data[i].F_Date);
                    }

                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                    if (this.ctrTable.nTotal > 0) {
                        this.$refs.tblList.setCurrentRow(this.ctrTable.arrData[0]);
                    }
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });
        },
        deleteData: function (nId) { // 删除,函数不取名为delete是因为vue的@click绑定函数名称不能为关键字,而delete为关键字            
            this.$lib.CURD.delete(this, "/Admin/SustomsStat/Delete?Id=" + nId, objResult => {         
                for(var i = 0; i < this.ctrTable.arrData.length; i++){
                    if(nId == this.ctrTable.arrData[i].Id){
                        this.ctrTable.arrData.splice(i, 1);                        
                        break;
                    }
                }
                // this.search(true);
            });
        },

        edit:function(nId){ // 新增或编辑     
            this.$layer.iframe({
                content: {
                    content: SustomsStatEdit,
                    parent: this,
                    data:{ Id:nId } 
                },
                area:['800px','600px'],
                shadeClose: false,
                title: (nId==null?'新增':'编辑')
            });
        },

        openSustomsStatInsertBat:function(){
            this.$layer.iframe({
                content: {
                    content: SustomsStatInsertBat,
                    parent: this,
                    data:{ } 
                },
                area:['800px','500px'],
                shadeClose: false,
                title: '批量新增'
            });
        },

        ctrTable_sortChange: function (objSort) {   // 表格排序
            this.$lib.Element.Table.sortChange(objSort, this);
        },
        ctrTable_currentChange: function (currentRow, oldCurrentRow) {   // 表格当前项改变  
            this.$lib.Element.Table.currentChange(currentRow, oldCurrentRow, this);            
        },
        ctrTable_selectionChange: function (selection) {                 // 表格复选框进行多选            
            this.$lib.Element.Table.selectionChange(selection, this);
        },
        ctrTable_filterChange: function (objFilters) {    // 列过滤
            this.$lib.Element.Table.filterChange(objFilters, this);            
        },

        ctrPage_sizeChange: function (nValue) { // 页码改变
            this.$lib.Element.Page.sizeChange(nValue, this);         
        },
        ctrPage_currentChange: function (nValue) {  // 当前页改变 
            this.$lib.Element.Page.currentChange(nValue, this);
        }
    }
}

</script>

<style scoped>

</style>
