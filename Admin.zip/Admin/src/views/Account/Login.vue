<template>
    <div style="width:100%; height: 100vh; background: url('/static/image/bg_login.png') repeat;">
        <el-row style="display: flex; height: 100%;">
            <el-col :span="2">&nbsp;</el-col>
            <el-col :span="22" style="display: flex; justify-content: center; align-items: center;">                
                <div style="color: #ffffff; font-family: Microsoft YaHei;">
                    <div style="font-size: 28px; text-align: center;">翼 达 通</div>
                    <div style="width: 450px; height: 450px; background: #40598d; border-radius: 5px; margin-top: 30px; ">
                        <div style="height: 50px;"></div>
                        <div style="font-size: 24px; margin-left: 75px;">账号登录</div>
                        <el-form :model="objData" :rules="objRules" ref="ctrForm" status-icon :hide-required-asterisk="true" label-width="75px" style="margin-top: 40px;">
                            <el-form-item label=" " prop="Mobile">
                                <el-input v-model="objData.Mobile" placeholder="手机号" style="width:300px;" prefix-icon="el-icon-user"></el-input>
                            </el-form-item>
                            <el-form-item label=" " prop="Password" style="margin-bottom:50px;">
                                <el-input type="password" v-model="objData.Password" placeholder="密码" style="width:300px;" prefix-icon="el-icon-lock"></el-input>
                            </el-form-item>
                            <el-form-item label=" " style="margin-bottom:0px;">
                                <el-button type="primary" icon="el-icon-check" style="width:300px;" :loading="ctrForm.blnLoad" @click="login()" @keyup.enter="keyDown(e);">登 录</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </div>
            </el-col>
            <el-col :span="2">&nbsp;</el-col>
        </el-row>        
    </div>  
</template>
 
<script>

export default {
    // name: 'Template',         // 最好不要改属性
    data: function() {
        return{
            ctrForm: {
                blnLoad: false,
                blnIsRemember: false
            },
            objData: {
                Mobile: "",
                Password: ""
            },
            objRules: {
                Mobile: [{ required: true, message: '请输入手机号。', trigger: 'change' }],
                Password: [{ required: true, message: '请输入密码。', trigger: 'change' }, { min: 6, message: '最少输入6个字符。', trigger: 'blur' }]
            }
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function(){
        this.initPage();
        window.addEventListener("keydown", this.keyDown);
    },
    destroyed: function() {
        window.removeEventListener("keydown", this.keyDown, false);
    },
    methods:{
        initPage:function(){
        },
        keyDown: function(e){
            if(e.keyCode==13 || e.keyCode==100){
                this.login();
            }  
        },
        login: function(){
            this.ctrForm.blnLoad = true;

            this.$refs["ctrForm"].validate(blnValid => {
                if(blnValid == false){
                    this.ctrForm.blnLoad = false;
                    return;
                }
                
                this.$ajax.get('/Open/Account/LoginByPassword',this.objData).done((objResult,strStatus,objXHR)=>{                                                    
                    if(objResult.success != true){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                    
                        this.ctrForm.blnLoad = false;
                        return;
                    }
                    
                    localStorage.setItem("strToken", objResult.data);             
                    localStorage.setItem("jobjUser", JSON.stringify(objResult.extData));

                    this.$ajax.init();  // 服务器令牌清空时,页面切换到登录页面登录后需要刷新配置数据    
                    this.$store.state.jobjUser = objResult.extData;     

                    this.$ajax.get('/SYS/API/InitData',{},{async:false}).done(objResult => {                        
                        var arrTemp = objResult.data.arrPowerModule.filter((objItem, nIndex, arrSource)=>{
                            return objItem.Client==1;
                        });              
                        this.$store.commit('TabMenu/init', arrTemp);

                        this.$store.commit('Dictionary/init', objResult.data.arrDictionary);
                        this.$store.state.Dictionary.objMapKey = objResult.data.objDictionary;
                        this.$store.commit('Employee/init', objResult.data.arrEmployee);

                        this.$store.commit('AirLine/init', objResult.data.arrAirLine);
                        for(var i = 0; i < objResult.data.arrFlight.length; i++){
                            objResult.data.arrFlight[i].Date = this.$lib.Format.fmtDate(objResult.data.arrFlight[i].Date);
                        }
                        this.$store.commit('Flight/init', objResult.data.arrFlight);
                        this.$store.commit('BasePackage/init', objResult.data.arrBasePackage);
                        this.$store.commit('Company/init', objResult.data.arrCompany);
                        this.$store.commit('CompanyCustomer/init', objResult.data.arrCompanyCustomer);
                        this.$store.commit('BaseLogistics/init', objResult.data.arrBaseLogistics);
                    });
                });
            });
        }
    }
}
</script>

<style scoped>
    /* body{background:#F9F9F9;}
    .hc-layout_header{ height:56px; overflow:hidden; width: 100%; background:#1d2c42; color: #ffffff; }
    .hc-layout_contentLogin{ height:calc(100vh - 60px) !important; width:100%;}
    .el-checkbox__label{color: #ffffff !important;}
    .el-form-item__error{ color: #ffffff;}
    .el-carousel__container{ width: 100%; height: 100% !important;} */
</style>
