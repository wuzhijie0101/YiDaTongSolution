<template>
    <div style="width:100%; height: 100%;">
        <div class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">    
            <div class="row hc_form form-size-small">
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>原密码：</div>
                    <div class="form-item-bd">       
                        <el-input type="password" v-model="objData.OldPassword" clearable style="width:300px;" name="原密码" v-validate="{ required:true, min:6 }"></el-input>
                        <div class="form-error" v-show="errors.has('原密码')">{{errors.first('原密码')}}</div>
                    </div> 
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>新密码：</div>
                    <div class="form-item-bd">       
                        <el-input type="password" v-model="objData.NewPassword" clearable style="width:300px;" name="新密码" v-validate="{ required:true, min:6 }"></el-input>
                        <div class="form-error" v-show="errors.has('新密码')">{{errors.first('新密码')}}</div>
                    </div> 
                </div>
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>确认密码：</div>
                    <div class="form-item-bd">       
                        <el-input type="password" v-model="objData.CheckPassword" clearable style="width:300px;" name="确认密码" v-validate="{ required:true, min:6, is: objData.NewPassword }"></el-input>
                        <div class="form-error" v-show="errors.has('确认密码')">{{errors.first('确认密码')}}</div>
                    </div> 
                </div>
            </div>
        </div>
        <div class="hc-bg_gray" style="height:44px; line-height:44px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">保存</el-button>
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>    
</template>

<script>

export default {    
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false
            },            
            objData: {
                Id: this.Id,
                OldPassword: "",
                NewPassword: "",
                CheckPassword: ""
            }
        }
    },
    props:{
        Id:{
            type: Number,
            default: null
        },       
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {},
    watch: {},
    created: function() {      
    },
    mounted: function(){
        this.initPage();
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){                         
        },
        save: function () {            
            this.ctrForm.blnSubmit = true;
            this.$validator.validate().then(valid => {                        
                if (valid == false) {
                    this.ctrForm.blnSubmit = false;
                    return;
                }

                this.$ajax.post('/SYS/Account/UpdatePassword', this.objData).then(objResult => {                    
                    if(objResult.success != true){
                        this.$alert(objResult.message, '系统提示', { type: 'error' });                    
                        this.ctrForm.blnSubmit = false;
                        return;
                    }

                    this.$alert(objResult.message, '系统提示', { type: 'success',callback: ()=> {
                            this.$layer.close(this.layerid);                                 
                        }
                    });
                });
            });                    
        }
    }
}
</script>

<style scoped>
    
</style>
