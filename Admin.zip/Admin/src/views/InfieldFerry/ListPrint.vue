<template>
    <div class="hc-bg_gray" style="padding:10px; height:99%;">       
        <div style="height:50px; padding:10px; background:#ffffff;">
            <div style="float:left;" class="search_mini">
                <el-select v-model="ctrTable.objParam.Where.AC_Id.strValue" filterable placeholder="所属航司" style="width: 200px;">
                    <el-option v-for="objItem in $store.state.AirCompany.arrData" :key="objItem.Id" :label="objItem.Name" :value="objItem.Id"></el-option>
                </el-select>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_Start.strValue" type="date" clearable value-format="yyyy-MM-dd 00:00:00" placeholder="航班开始时间" style="width:120px;"></el-date-picker>
                <el-date-picker v-model="ctrTable.objParam.Where.Date_End.strValue" type="date" clearable value-format="yyyy-MM-dd 23:59:59" placeholder="航班结束时间" style="width:120px;"></el-date-picker>            

                <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" size="small" icon="el-icon-search" @click="search();">查询</el-button>
            </div>
            <div style="float:right;">
                <el-button-group>
                    <el-button v-once v-show="$lib.Sys.hasPower(PM_Id,3)" type="success" icon="el-icon-download" @click="exportExcel();">导出Excel</el-button>
                    <el-button size="small" type="success" icon="el-icon-printer" onclick="printJS({printable:'divPrint',type:'html',css:'/static/script/hcui.css'})">打 印</el-button>           
                </el-button-group>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div style="height:calc(100% - 60px); margin-top:10px; background:#ffffff;">            
            <div id="divPrint" style="width: 840px;">
                <table class="hc-table_print" style="width: 100%;">
                    <tr>
                        <td style="font-size: 2rem; font-weight: bold; text-align: center; padding: 10px 0px;">{{$lib.Store.getValById($store.state.AirCompany.objMapping, ctrTable.objParam.Where.AC_Id.strValue)}}内场车辆使用记录单</td>
                    </tr>
                </table>
                
                <table class="hc-table_print hc-table_print-big" style="width: 100%; border-top:none; font-size: 1.4rem !important;">
                    <thead>
                        <tr>
                            <th style="width: 60px;">序号</th>
                            <th style="width: 80px;">日期</th>
                            <th style="width: 80px;">时间</th>
                            <th style="width: 100px;">航班号</th>
                            <th style="width: 200px;">行车线路</th>
                            <th style="width: 100px;">操作人员</th>
                            <th style="width: 100px;">飞机号</th>
                            <th style="width: 100px;">航司代表签字</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template v-for="objItem in ctrTable.arrData">
                            <tr>
                                <td style="text-align: center; padding: 0px 5px;">{{objItem.Index}}</td>
                                <td style="text-align: center; padding: 0px 5px;">{{objItem.Date}}</td>
                                <td style="text-align: center; padding: 0px 5px;">{{objItem.OperateTime}}</td>
                                <td style="text-align: center; padding: 0px 5px;">{{objItem.Number}}</td>
                                <td style="padding: 0px 5px;">{{objItem.Line}}</td>
                                <td style="text-align: center; padding: 0px 5px;">{{$store.state.Employee.objMapping[objItem.E_Id].Name}}</td>
                                <td style="text-align: center; padding: 0px 5px;">{{objItem.AircraftNumber}}</td>
                                <td style="text-align: center; padding: 0px 5px;">
                                    <img v-if="objItem.Sign!=''" :src="$lib.Config.Url_ApiUpload + objItem.Sign" class="img-fluid" />
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>    
</template>

<script>

export default {
    data: function() {
        return{
            PM_Id: 345,

            ctrTable: {
                arrData: [],    // 表行数据
                nTotal: 0,
                strPrefix: "",
                OrderByOld: "Date asc",  // 用于排序回到原值
                objParam: {
                    Page: 1,
                    Size: 20,
                    Table: "",
                    Field: "*",
                    Where: {        
                        "AC_Id": { "strField": "AC_Id", "strCondition": "=", "strValue": this.$store.state.AirCompany.arrData[0].Id, "strSingleQuotes": "" },
                        "Date_Start": { "strField": "Date", "strCondition": ">=", "strValue": this.$dayjs(this.$dayjs().format("YYYY-MM-01")).toDate(), "strSingleQuotes": "'" },                                                
                        "Date_End": { "strField": "Date", "strCondition": "<", "strValue": "", "strSingleQuotes": "'" },
                    },
                    OrderBy: "Date asc"
                },
                objCurrentRow: {},      // 当前点击行
                arrMultipleSelection:[]    // 复选框多选行
            }
        }
    },
    props:{
    },
    computed: {
        ctrTable_autoSearch: function () {  // 查询条件设置为计算属性            
            return this.ctrTable.objParam.Where.AC_Id.strValue + this.ctrTable.objParam.Where.Date_Start.strValue + this.ctrTable.objParam.Where.Date_End.strValue;          
        }
    },
    watch: {
        ctrTable_autoSearch: function (strValue) {  // 监控计算属性
            this.search();
        }
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        initPage:function(){            
            this.search();            
        },

        
        search: function (blnIsReload) {            
            if (this.$lib.Sys.hasPower(this.PM_Id,3) == false) {
                return;
            }

            this.$ajax.get('/Admin/InfieldFerry/Get', this.ctrTable.objParam).then(objResult=> {                
                if (objResult.success == true) {
                    for(var i = 0; i < objResult.data.length; i++){
                        objResult.data[i].Index = i+1;
                        objResult.data[i].Date = this.$dayjs(objResult.data[i].Date).format("MM-DD");
                    }

                    this.ctrTable.arrData = objResult.data;
                    this.ctrTable.nTotal = objResult.extData;
                }
                else {
                    this.$notify.error({ title: '错误提示', message: '您好，数据获取失败，请稍后再进行该项操作。', offset: 100, duration: 3000 });
                }
            });
        },
        exportExcel:function(){                      
            window.location.href = this.$lib.Config.Url_ApiRequest + "/Admin/Report/ExportInfieldFerry?token="+localStorage.getItem("strToken")+"&Where=" + JSON.stringify(this.ctrTable.objParam.Where);            
        }
    }
}

</script>

<style scoped>

</style>
