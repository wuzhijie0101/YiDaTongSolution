<template>
    <div style="width:100%; height: 100%;">
        <validation-observer ref="form" tag="div" class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row form-item-hd-left">                
                <div class="col-240 form-item">
                    <div class="form-item-hd"><span class="form-required">*</span>所属快递</div>
                    <div class="form-item-bd">
                        <validation-provider tag="div" name="所属快递" class="form-item-bd" rules="required" v-slot="{ errors }">
                            <hc-popup-radio v-model="objData.BL_Id" name="所属快递" :data="$store.state.BaseLogistics.arrData" position="bottom" :mode="1" :filter="false"></hc-popup-radio>
                            <div class="form-error" v-show="errors[0]" style="margin-top: 2px;">{{errors[0]}}</div>          
                        </validation-provider>
                    </div>
                    <div class="form-item-ft"><i class="el-icon-arrow-right" v-show="objData.Id==null"></i></div>
                </div>
                <hc-text-item class="col-240" type="text" v-model="objData.Number" validate="required" name="快递单号"></hc-text-item>
                <hc-text-item v-if="objData.BL_Id==1000" class="col-240" type="tel" v-model="objData.Mobile" validate="required|mobile:true" name="寄方或收方手机"></hc-text-item>                
            </div>
        </validation-observer>

        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
            <el-button size="small" type="danger" icon="el-icon-close" @click="$layer.close(layerid);">取消</el-button>
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Type:{
            type: Number,
            default: null
        },
        BizId:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }        
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            objData:{
                Id: null,                        
                BL_Id: null,
                Type: this.Type,                        
                BizId: this.BizId,
                Number: "",
                Mobile: ""
            }       
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {                 
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){                                
        },
        save: function(){
            Lib.CURD.update(this, "/Admin/LogisticsOrder/Insert", objResult =>{
                this.$layer.close(this.layerid);
            }, false);
        }
    }
}
</script>

<style scoped>

</style>
