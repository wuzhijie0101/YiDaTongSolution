<template>
    <div style="height:100%; width: 100%; overflow-y: auto; background: #fff; padding: 15px; border-radius: 10px;">
        <div style="color: #000; font-weight: bold; margin-bottom: 10px; padding-left: 20px;">
            <span>{{objExpress.expressCompanyName}}</span><span>{{objExpress.number}}</span>
        </div>

        <div>            
            <template v-for="(objItem,i) in objExpress.logisticsTraceDetails">
                <template v-if="i == 0">
                    <div class="lo-item"><span class="lo-item-dot"></span><span style="font-size: 1.6rem; font-weight: bold; color: #000;"><span>{{fmtExpressState(objItem.logisticsStatus)}}</span></span></div>
                    <div class="lo-item"><span style="color: #000;">{{objItem.desc}}</span><div class="lo-item-time">{{$dayjs(objItem.time).format('YYYY-MM-DD HH:mm:ss')}}</div></div>
                </template>
                <template v-else-if="objItem.logisticsStatus == objExpress.logisticsTraceDetails[i-1].logisticsStatus">
                    <div class="lo-item">{{objItem.desc}}<div class="lo-item-time">{{$dayjs(objItem.time).format('YYYY-MM-DD HH:mm:ss')}}</div></div>
                </template>
                <template v-else>
                    <div class="lo-item"><span class="lo-item-dot"></span><span class="lo-item-state">{{fmtExpressState(objItem.logisticsStatus)}}</span></div>
                    <div class="lo-item">{{objItem.desc}}<div class="lo-item-time">{{$dayjs(objItem.time).format('YYYY-MM-DD HH:mm:ss')}}</div></div>
                </template>                
            </template>
        </div> 

    </div>
</template>

<script>


export default {
    data: function() {
        return{
            objExpress:{
            },         
            objData:{
                Id: this.Id,                        
            }
        }
    },
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    computed: {
    },
    watch: {
    },
    created: function() {
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        
        fmtExpressState:function(strState){
            var strReturn = strState;
            switch(strState){
                case "WAIT_ACCEPT": strReturn = "待揽收"; break;
                case "ACCEPT": strReturn = "已揽收"; break;
                case "TRANSPORT": strReturn = "运输中"; break;
                case "DELIVERING": strReturn = "派件中"; break;
                case "AGENT_SIGN": strReturn = "已代签收"; break;
                case "SIGN": strReturn = "已签收"; break;
                case "FAILED": strReturn = "包裹异常"; break;
            }
            return strReturn;
        },
        initPage: function(){                    
            this.$ajax.get('/Admin/LogisticsOrder/QueryExpress?LO_Id=' + this.objData.Id).then(objResult=> {                  
                if(objResult.success == false){
                    this.$alert(objResult.message, '系统提示', { type: 'error' });                  
                    return;
                }

                this.objData = objResult.extData[0];

                objResult.data.data.logisticsTraceDetails = objResult.data.data.logisticsTraceDetails.reverse();                                
                this.objExpress = objResult.data.data;                          
            });
        }        
    }
}

</script>

<style scoped>
.lo-item{border-left: 1px solid #cccccc; position:relative; padding-left: 20px; padding-bottom: 10px; color: #7d7d7d; line-height: 1.2;}
.lo-item-dot{position:absolute; left: -10px; top: -4px; display: inline-block; width: 18px; height: 18px; border:5px solid #fff; border-radius: 50%; z-index: 100; background-color: #cccccc;}        
.lo-item-state{font-weight: bold; font-size: 1.6rem;}
.lo-item-time{font-size: 1.2rem; margin-top: 5px;}
</style>
