<template>
    <div style="width:100%; height: 100%;">
        <div class="hc_container-fluid" style="height:calc(100% - 45px); overflow:auto; padding: 10px;">
            <div class="row hc_form form-size-small">
                
            </div>
        </div>


        <div class="hc-bg_gray" style="height:45px; line-height:45px; text-align:center;">
            <el-button size="small" type="success" icon="el-icon-check" :loading="ctrForm.blnSubmit" @click="save();">提交保存</el-button>            
        </div>
    </div>  
</template>

<script>

export default {
    props:{
        Id:{
            type: Number,
            default: null
        },
        layerid: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
            ctrForm: {
                blnSubmit: false,
                blnStartWatch: false   // 编辑的时候，加载数据后会马上触发watch监听，从而导致数据有问题，所以要等数据加载完成后再进行watch监听； 
            },
            objData: {                                
                Id: this.Id,
                System: 2,
                Type: null,
                Client: null,
                ParentId: null,
                Name: "",
                Link: "",
                LinkAPP: "",
                Icon: "",
                IconAPP: "",
                Operate: null,
                BizParam: "{}",
                BizParamAPP: "",
                Sort: null,
                Remark: "",
                Enable: null
            }            
        }
    },    
    computed: {
    },
    watch: {
    },
    created: function() {              
        this.initPage();
    },
    mounted: function(){
    },
    destroyed: function() {},
    methods:{    
        startWatch:function(){
            setTimeout(()=>{
                this.ctrForm.blnStartWatch = true;
            },200);
        },
        initPage:function(){       
            if(this.objData.Id == null){
                this.startWatch(); 
            }
            else{
                  
            }                             
        },
        save: function () {
   
        },
    }
}
</script>

<style scoped>
    .form-item-hd{width: 120px;}
    .form-item-bd{ width:calc(100% - 120px);} 
</style>
