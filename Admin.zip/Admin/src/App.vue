<template>
    <div id="app" class="hc-layout">
        <template v-if="$store.state.jobjUser != null">
            <div class="hc-layout_sidebar">
                <div class="hc-layout_sidebar_top" style="font-size: 1.6rem; height: 56px; line-height: 1.2; text-align: center; padding: 10px 15px;">翼达通全链管理平台</div>
                <div class="hc-layout_sidebar_menu">
                    <ul>
                        <li v-for="(objItem1,i) in $store.state.TabMenu.arrType1" v-show="objItem1.HasPower==true" class="sidebar_menu_li">
                            <el-popover placement="right" trigger="hover" v-model="$store.state.TabMenu.arrMenuVisible[i]">
                                <div slot="reference">
                                    <i :class="objItem1.Icon"></i><span style="margin-left: 10px;">{{objItem1.Name}}</span>
                                </div>
                                <div class="row">
                                    <div v-if="objItem1.HasPage" class="hc-layout_sidebar_menu_item">
                                        <dl>
                                            <dd v-for="objItem3 in objItem1.Children" v-if="objItem3.Type==3 && objItem3.HasPower==true" @click="$store.commit('TabMenu/selectMenu', objItem3.Id);$store.state.TabMenu.arrMenuVisible[i]=false;">{{objItem3.Name}}</dd>                                            
                                        </dl>
                                    </div>

                                    <div v-for="objItem2 in objItem1.Children" v-if="objItem2.Type==2 && objItem2.HasPower==true" class="hc-layout_sidebar_menu_item" >
                                        <dl>
                                            <dt>{{objItem2.Name}}</dt>                                            
                                            <dd v-for="objItem3 in objItem2.Children" v-if="objItem3.HasPower==true" @click="$store.commit('TabMenu/selectMenu', objItem3.Id);$store.state.TabMenu.arrMenuVisible[i]=false;">{{objItem3.Name}}</dd>                                                                                        

                                            <!-- <template v-for="objItem3 in objItem2.Children">
                                                <dd v-show="$lib.Sys.hasPower(objItem3.Id)" @click="$store.commit('TabMenu/selectMenu', objItem3.Id);$store.state.TabMenu.arrMenuVisible[i]=false;">{{objItem3.Name}}</dd>                                            
                                            </template> -->
                                        </dl>
                                    </div>
                                </div>
                            </el-popover>
                        </li>

                        <li class="sidebar_menu_li" :style="($store.state.jobjUser.E_Id==1000?'':'display: none;')">
                            <el-popover placement="right" trigger="hover" v-model="arrMenuVisible[0]">
                                <div slot="reference">
                                    <i class="el-icon-document"></i><span style="margin-left: 10px;">临时模块</span>
                                </div>
                                <div class="row">
                                    <div class="hc-layout_sidebar_menu_item">
                                        <dl>
                                            <dt>平台业务处理</dt>
                                            <dd @click="$store.commit('TabMenu/selectMenu', '2001');arrMenuVisible[0]=false;">字典管理</dd>                                            
                                            <dd @click="$store.commit('TabMenu/selectMenu', '2003');arrMenuVisible[0]=false;">权限页面管理</dd>                                                     
                                            <dd @click="$store.commit('TabMenu/selectMenu', '2002');arrMenuVisible[0]=false;">职员账号管理</dd>                                          
                                        </dl>
                                    </div>
                                </div>
                            </el-popover>
                        </li>                        
                    </ul>
                </div>
            </div>
            <div class="hc-layout_header">
                <div class="row">
                    <div class="col-180">&nbsp;</div>
                    <div class="col-60">
                        <el-menu style="float: right;" default-active="100" mode="horizontal" text-color="#333333" active-text-color="#999999">
                            <el-menu-item index="1"><a @click="logout();"><i class="el-icon-news"></i>退 出</a></el-menu-item>
                            <el-menu-item index="2">{{$store.state.jobjUser.Name}}</el-menu-item>
                            <!-- <el-submenu index="2">
                                <template slot="title">{{$store.state.jobjUser.Name}}</template>
                                <el-menu-item index="3"><a @click="openAccountUpdatePwd();">修改密码</a></el-menu-item>
                                <el-menu-item index="4"><a @click="openEmployeeUpdateInfor();">编辑个人信息</a></el-menu-item>                                
                            </el-submenu> -->
                        </el-menu>
                    </div>
                </div>
            </div>
            <div class="hc-layout_content">
                <el-tabs v-model="$store.state.TabMenu.strActiveId" style="height:100%;" type="border-card" @tab-remove="elTab_tabRemove">
                    <el-tab-pane name="100" label="首页" key="100" style="overflow: auto;">            
                        <!-- <div>
                            <hc-popup-radio v-model="AL_Id" name="所属航司" :data="$store.state.AirLine.arrData" position="bottom" :mode="1" :filter="false"></hc-popup-radio>
                        </div> -->
                        <!-- <file-pond></file-pond> -->
                    </el-tab-pane>
                    <el-tab-pane v-for="objItem in $store.state.TabMenu.arrTab" :name="objItem.strId" :label="objItem.strTitle" :key="objItem.strId" v-if="(objItem.strPath!='PowerModuleList' || $store.state.jobjUser.E_Id=='1000')" closable style="overflow: auto;">                        
                        <component v-if="objItem.strPath=='OutOrderEdit'" :is="objItem.strPath" :Id='objItem.jobjBizParam.Id' :TabId='objItem.jobjBizParam.TabId' :C_Id='objItem.jobjBizParam.C_Id'></component>
                        <component v-else :is="objItem.strPath" :BizParam="objItem.jobjBizParam"></component>                      
                    </el-tab-pane>
                </el-tabs>
            </div>
        </template>
        <template v-else>
            <AccountLogin></AccountLogin>
        </template>
    </div>
</template>
<script>
// import AccountUpdatePwd from '@/views/Account/UpdatePwd.vue';
// import EmployeeUpdateInfor from '@/views/Employee/UpdateInfor.vue';

export default {
    name: 'App',         // 最好不要改属性    
    data: function() {
        return{
            arrMenuVisible:[],

            AL_Id: null
        }
    },
    computed: {},
    watch: {
    },
    created: function() { 
        if(this.$lib.Sys.checkLogin(0) == false){            
          this.$store.state.jobjUser = null;
        }
        else{
          this.$store.state.jobjUser = JSON.parse(localStorage.getItem("jobjUser"));
          this.$ajax.get('/SYS/API/InitData',{},{async:false}).done(objResult => {
            //   console.log(objResult.data);
              var arrTemp = objResult.data.arrPowerModule.filter((objItem, nIndex, arrSource)=>{
                return objItem.Client==1;
              });              
              this.$store.commit('TabMenu/init', arrTemp);

              this.$store.commit('Dictionary/init', objResult.data.arrDictionary);
              this.$store.state.Dictionary.objMapKey = objResult.data.objDictionary;
              this.$store.commit('Employee/init', objResult.data.arrEmployee);

              this.$store.commit('AirLine/init', objResult.data.arrAirLine);
              for(var i = 0; i < objResult.data.arrFlight.length; i++){
                objResult.data.arrFlight[i].Date = this.$lib.Format.fmtDate(objResult.data.arrFlight[i].Date);
              }
              this.$store.commit('Flight/init', objResult.data.arrFlight);
              this.$store.commit('BasePackage/init', objResult.data.arrBasePackage);
              this.$store.commit('Company/init', objResult.data.arrCompany);
              this.$store.commit('CompanyCustomer/init', objResult.data.arrCompanyCustomer);
              this.$store.commit('BaseLogistics/init', objResult.data.arrBaseLogistics);
              this.$store.commit('CompanyTruck/init', objResult.data.arrCompanyTruck);
              this.$store.commit('AirCompany/init', objResult.data.arrAirCompany);
              
          });          
        }
    },
    mounted: function(){           
        this.initPage();
    },
    destroyed: function() {},
    methods:{            
        initPage:function(){

        },


        elTab_tabRemove: function (strId) {
            this.$store.commit('TabMenu/closeTab', strId);            
        },
        logout: function () {
            localStorage.removeItem("strToken");
            localStorage.removeItem("jobjUser");
            this.$store.state.jobjUser = null;
        },
        // openAccountUpdatePwd:function(){ 
        //     this.$layer.iframe({
        //         content: {
        //             content: AccountUpdatePwd,
        //             parent: this,
        //             data:{ Id:this.$store.state.jobjUser.A_Id } 
        //         },
        //         area:['60%','60%'],
        //         shadeClose: false,
        //         title: "修改密码"
        //     });
        // }
        // openEmployeeUpdateInfor:function(){ 
        //     this.$layer.iframe({
        //         content: {
        //             content: EmployeeUpdateInfor,
        //             parent: this,
        //             data:{ Id:this.$store.state.jobjUser.E_Id } 
        //         },
        //         area:['60%','60%'],
        //         shadeClose: false,
        //         title: "编辑个人信息"
        //     });
        // }
    }
}
</script>

<style>
    .hc-layout{ height:100vh; width:100%; }
    .hc-layout_sidebar{ float:left; width: 120px; height:100%; overflow-y:auto; overflow-x:hidden;}
    .hc-layout_sidebar_top{ height: 56px; color: #ffffff; background:#3c3c3c; }    
    .hc-layout_sidebar_menu{ height: calc(100% - 56px); background:#3c3c3c; }
    .hc-layout_sidebar_menu .sidebar_menu_li{ height: 52px; line-height: 52px; padding: 0px 0px 0px 15px; font-size: 16px; color: #cccccc; cursor: pointer; }
    .hc-layout_sidebar_menu .sidebar_menu_li:hover{ background: #47b986; color: #ffffff; }
    .hc-layout_sidebar_menu_item{ text-align: center; border-right: 1px solid #cccccc;}
    .hc-layout_sidebar_menu_item:last-child{border-right:none}
    .hc-layout_sidebar_menu_item dt{ font-weight: bold; color: #999999;}
    .hc-layout_sidebar_menu_item dd{ padding: 5px 10px; cursor: pointer; }
    .hc-layout_sidebar_menu_item dd:hover{ background: #eeeeee; }
    /* .hc-layout_sidebar_menu li span{ margin-left: 12px; } */

    .hc-layout_header{ float: left; width: calc(100% - 120px); height:56px; overflow:hidden; }    
    .hc-layout_content{ float: left; width: calc(100% - 120px); height:calc(100vh - 56px); }
    



    .el-tabs--border-card>.el-tabs__content{ padding:0px; height:calc(100% - 40px); }
    .el-tab-pane{ height:100%; }
    .el-tab-pane iframe{width:100%; height:100%; overflow-y:auto;}
</style>
  