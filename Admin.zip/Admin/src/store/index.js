import Vue from 'vue'
import Vuex from  'vuex'
import Dictionary from '@/store/modules/Dictionary.js';
import Employee from '@/store/modules/Employee.js';
import AirLine from '@/store/modules/AirLine.js';
import Flight from '@/store/modules/Flight.js';
import BasePackage from '@/store/modules/BasePackage.js';
import Company from '@/store/modules/Company.js';
import CompanyCustomer from '@/store/modules/CompanyCustomer.js';
import BaseLogistics from '@/store/modules/BaseLogistics.js';
import CompanyTruck from '@/store/modules/CompanyTruck.js';
import AirCompany from '@/store/modules/AirCompany.js';

import TabMenu from '@/router/tabMenu.js';

Vue.use(Vuex);

// var state = {
//     count : 0,
//     name : "何少华",
//     age : 18
// };
// var getters = {
//     getterText(state){
//         return (state.name + state.age);
//     }
// };
// var mutations = {
//     mutationsAddCount(state,n=0){
//         state.count+=n;
//     },
//     mutationsReduceCount(state,n=0){
//         state.count-=n;
//     }
// };
// var actions = {
//     actionsAddCount(context, n=0){
//         return context.commit('mutationsAddCount',n);
//     },
//     actionsReduceCount(context, n=0){
//         return context.commit('mutationsReduceCount',n);
//     }
// }

export default new Vuex.Store({
    state:{
        jobjUser: null
    },
    modules: {
        TabMenu: TabMenu,
        Dictionary: Dictionary,
        Employee: Employee,
        AirLine: AirLine,
        Flight: Flight,
        BasePackage: BasePackage,
        Company: Company,
        CompanyCustomer: CompanyCustomer,
        BaseLogistics: BaseLogistics,
        CompanyTruck: CompanyTruck,
        AirCompany: AirCompany
    }
});