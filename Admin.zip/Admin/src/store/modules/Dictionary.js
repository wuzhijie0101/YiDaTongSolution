import Vue from 'vue';

export default {
    namespaced: true,
    state:{
        // blnLoad: false,     // 是否已初始化数据
        arrData: [],        
        objMapKey: null
    },
    getters:{
        getTree:function(state){            
            var arrTemp = Vue.prototype.$lib.Common.getTreeData(state.arrData.filter(function(objItem, nIndex, arrSource){
                return objItem.Type==1;
            }));

            arrTemp.unshift({ Id: 0, Name: "所有数据" });
            return arrTemp;
        },
        getCascader:function(state){            
            return Vue.prototype.$lib.Common.getTreeData(state.arrData.filter(function(objItem, nIndex, arrSource){
                return objItem.Type==1 && objItem.Enable==1;
            }));
        }
    },
    mutations:{
        insert:function(state,objData){
            state.arrData.push(objData);
        },
        update:function(state, objData){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == objData.Id){
                    state.arrData.splice(i,1,objData);
                    break;
                }
            }
        },
        delete:function(state, nId){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == nId){
                    state.arrData.splice(i,1);
                    break;
                }
            }
        },
        init:function(state, arrData){
            state.arrData = arrData;           
        }
    },
    actions:{
        init:function(context){
            // // if(context.state.blnLoad==true){
            // //     return;
            // // }

            // var objWhere = {
            //     // "Enable": { "strField": "Enable", "strCondition": "=", "strValue": "1", "strSingleQuotes": "" },
            //     // "Type": { "strField": "Type", "strCondition": "in", "strValue": "1,2,4,5,6,7,8", "strSingleQuotes": "" }
            // }
            // Vue.prototype.$ajax.get('/Admin/Dictionary/Get', { Field: "*", Where:objWhere, OrderBy:"ParentId asc,Sort desc,Id asc" }).then(objResult => {                    
            //     context.state.arrData = objResult.arrData;
            // });
            // // this.$ajax.get('/Admin/Dictionary/Get', { Field: "Id,ParentId,Deep,Type,CallKey,Name,Value,EncodeValue,Image,Attachment,Value1,Value2,Value3,Value4,Sort", Where:objWhere, OrderBy:"ParentId asc,Sort desc,Id asc" }).then(objResult => {                    
            // //     console.log(objResult);
            // // });
        }
    }
  }