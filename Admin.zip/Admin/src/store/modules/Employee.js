import Vue from 'vue';

export default {
    namespaced: true,
    state:{
        // blnLoad: false,     // 是否已初始化数据
        arrData: [],
        objMapping: {},
        // fmtById: function(nId, strFieldName="Name"){ 
        //     return Lib.Store.fmtById(this.objMapping, nId, strFieldName);
        // },
        // fmtByIds: function(strIds, strFieldName="Name"){ 
        //     return Lib.Store.fmtByIds(this.objMapping, strIds, strFieldName);
        // }
        getByState:function(nState){
            return this.arrData.filter(function(objItem){
                return objItem.State==nState;
            });
        }
    },
    getters:{
        // getState:function(state){   // 获得所有在职员工数组
        //     return state.arrData.filter(function(objItem, nIndex, arrSource){
        //         return objItem.State==1;
        //     });
        //     // 调用方式：this.$store.getters['Employee/getState']
        // }
        // getEnable:function(state){
        //     var arrTemp = Vue.prototype.$lib.Common.getTreeData(state.arrData.filter(function(objItem, nIndex, arrSource){
        //         return objItem.Enable==1;
        //     }));

        //     arrTemp.unshift({ Id: 0, Name: "所有数据" });
        //     return arrTemp;
        // }
    },
    mutations:{    
        insert:function(state,objData){
            state.arrData.push(objData);
            state.objMapping[objData.Id] = objData;
        },
        update:function(state, objData){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == objData.Id){                    
                    state.arrData.splice(i,1,objData);
                    break;
                }
            }
            state.objMapping[objData.Id] = objData;
        },
        delete:function(state, nId){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == nId){
                    state.arrData.splice(i,1);
                    break;
                }
            }
            delete state.objMapping[nId];
        },
        init:function(state, arrData){
            state.arrData = arrData;
            for(var i = 0; i < arrData.length; i++){
                state.objMapping[arrData[i].Id] = arrData[i];
            }
        }
    },
    actions:{
        init:function(context){
            // // if(context.state.blnLoad==true){
            // //     return;
            // // }

            // var objWhere = {
            //     // "Enable": { "strField": "Enable", "strCondition": "=", "strValue": "1", "strSingleQuotes": "" }
            //     // "Type": { "strField": "Type", "strCondition": "in", "strValue": "1,2,4,5,6,7,8", "strSingleQuotes": "" }
            // }
            // Vue.prototype.$ajax.get('/API/SpecValue/Get', { Field: "*", Where:objWhere, OrderBy:"Sort desc,Id asc" }).then(objResult => {                    
            //     context.state.arrData.splice(0,context.state.arrData.length-1);
            //     context.state.arrData = objResult.arrData;
            //     for(var i = 0; i < objResult.arrData.length; i++){
            //         context.state.objMapping[objResult.arrData[i].Id] = objResult.arrData[i];
            //     }
            // });
        }
    }
  }