import Vue from 'vue';

export default {
    namespaced: true,
    state:{
        // blnLoad: false,     // 是否已初始化数据
        arrData: [],
        objMapping: {},   
        getByC_Id:function(nC_Id){
            return this.arrData.filter(function(objItem){
                return objItem.C_Id==nC_Id;
            });
        }
    },
    getters:{       
    },
    mutations:{    
        insert:function(state,objData){
            state.arrData.push(objData);
            state.objMapping[objData.Id] = objData;
        },
        update:function(state, objData){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == objData.Id){                    
                    state.arrData.splice(i,1,objData);
                    break;
                }
            }
            state.objMapping[objData.Id] = objData;
        },
        delete:function(state, nId){
            for(var i = 0; i < state.arrData.length; i++){
                if(state.arrData[i].Id == nId){
                    state.arrData.splice(i,1);
                    break;
                }
            }
            delete state.objMapping[nId];
        },
        init:function(state, arrData){
            state.arrData = arrData;
            for(var i = 0; i < arrData.length; i++){
                state.objMapping[arrData[i].Id] = arrData[i];
            }
        }
    },
    actions:{
        init:function(context){
        }
    }
  }