// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import tabRoute from '@/router/tabRoute';
import store from '@/store/index';
import { ValidationObserver, ValidationProvider, extend, localize  } from 'vee-validate';
import * as rules from 'vee-validate/dist/rules';
import zh_CN from 'vee-validate/dist/locale/zh_CN.json';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import dayjs from 'dayjs';
import layer from 'vue-layer';
import 'vue-layer/lib/vue-layer.css';
import VueUeditorWrap from 'vue-ueditor-wrap';
import currency from 'currency.js';

import vueFilePond from "vue-filepond";
import FilePondPluginFileValidateSize from "filepond-plugin-file-validate-size";
import FilePondPluginFileValidateType from "filepond-plugin-file-validate-type";
// import FilePondPluginImagePreview from "filepond-plugin-image-preview";
// import 'filepond/dist/filepond.min.css';
// import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css';

Vue.component('file-pond', vueFilePond(FilePondPluginFileValidateSize, FilePondPluginFileValidateType));

import Item from '@/components/HuaChu/Form/Item.vue';
import TextItem from '@/components/HuaChu/Form/TextItem.vue';
import TextareaItem from '@/components/HuaChu/Form/TextareaItem.vue';
import RadioItem from '@/components/HuaChu/Form/RadioItem.vue';
import CheckboxItem from '@/components/HuaChu/Form/CheckboxItem.vue';
import NumberItem from '@/components/HuaChu/Form/NumberItem.vue';
import DateTimeItem from '@/components/HuaChu/Form/DateTimeItem.vue';

import PopupRadio from '@/components/HuaChu/Form/PopupRadio.vue';
import NumberCPN from '@/components/HuaChu/Form/Number.vue';

Vue.prototype.window = window;
Vue.prototype.$lib = Lib;
Vue.prototype.$ajax = Lib.Ajax;
Vue.prototype.$ajax.init();   
Lib.Global.vueRoot = Vue;
Vue.prototype.$layer = layer(Vue);
Vue.prototype.$dayjs = dayjs;
Vue.prototype.$cur = currency;
Vue.prototype.$store = store;
// Vue.prototype.$MeScroll = MeScroll;

Vue.use(tabRoute);
Vue.use(ElementUI, { size: 'small' });

localize('zh_CN', zh_CN);
Object.keys(rules).forEach(rule => {
  extend(rule, rules[rule]);
});
extend('mobile',{
  validate: function(value) {
      return Lib.Valid.Regular.regMobile.test(value);
  },
  message: "{_field_}格式无效"
});
extend('dec2',{
  validate: function(value) {
      return Lib.Valid.Regular.regDec2.test(value);
  },
  message: "{_field_}保留2位小数"
});
Vue.component('ValidationObserver', ValidationObserver);
Vue.component('ValidationProvider', ValidationProvider);

Vue.component('vue-ueditor-wrap', VueUeditorWrap);

Vue.component('hc-form-item', Item);
Vue.component('hc-text-item', TextItem);
Vue.component('hc-textarea-item', TextareaItem);
Vue.component('hc-radio-item', RadioItem);
Vue.component('hc-checkbox-item', CheckboxItem);
Vue.component('hc-number-item', NumberItem);
Vue.component('hc-datetime-item', DateTimeItem);

Vue.component('hc-popup-radio', PopupRadio);
Vue.component('hc-number', NumberCPN);

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  render: v => v(App)
})
