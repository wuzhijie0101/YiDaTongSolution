<template>
    <div class="form-item">
        <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>
        <!-- <div class="form-item-bd">
            <label class="hc_checkbox" v-for="objItem in data">
                <input type="checkbox" @change="valueChange($event)" :value="parseInt(objItem.Value)" :name="name" :disabled="disabled" /> <span>{{objItem.Name}}</span>                
            </label>
            <div class="form-error"></div>
        </div>  -->
        <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }">            
            <label class="hc_checkbox" v-for="objItem in data">
                <input type="checkbox" v-model="model" :value="parseInt(objItem[idKey])" :name="name" :disabled="disabled" /> <span>{{objItem[nameKey]}}</span>                
                <!-- <input type="checkbox" v-model="arrChoose" @change="$emit('change', arrChoose);" :value="parseInt(objItem.Value)" :name="name" :disabled="disabled" /> <span>{{objItem.Name}}</span>                 -->
            </label>
            <div class="form-error" v-show="errors[0]" style="margin-top: 0px;">{{errors[0]}}</div>          
        </validation-provider>
        <div class="form-item-ft">
            <slot name="footer"></slot>      
            <i :class="rightIcon"></i>
        </div>
    </div>
</template>

<script>

export default {
    name: 'CheckboxItem',
    model:{
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: Array,
            default(){return []}
        },
        data: {     // [{Value:'',Name:''}]
            type: Array,
            default(){return []}
        },
        idKey:{
            type: String,
            default: "Value"
        },
        nameKey:{
            type: String,
            default: "Name"
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        disabled:{
            type: Boolean,
            default: false
        }
    },
    data: function() {
        return{       
            arrChoose: this.value    
        }
    },
    computed: {
        model:{
            get:function(){
                return this.value;
            },
            set:function(value){
                this.$emit('change', value);
            }
        }
    },
    watch: {},
    created: function() {
    },
    mounted: function() {              
        // var arrCheckbox = document.getElementsByName(this.name);            
        // for(var i = 0; i < this.value.length; i++){
        //     for(var j = 0; j < arrCheckbox.length; j++){                
        //         if(this.value[i] == arrCheckbox[j]._value){                    
        //             arrCheckbox[j].checked = true;
        //             break;
        //         }
        //     }
        // }
    },
    destroyed: function() {},
    methods: {
        // valueChange:function(event){
        //     this.$emit('change', this.arrChoose);

        //     // if(event.target.checked==true){
        //     //     this.value.push(event.target._value);
        //     // }
        //     // else{
        //     //     for(var i = 0; i < this.value.length; i++){
        //     //         if(this.value[i]==event.target._value){
        //     //             this.value.splice(i,1);
        //     //             break;
        //     //         }
        //     //     }
        //     // }            
        //     // this.$emit('change', this.value);                       
        // }
    }
};
</script>

<style scoped>

</style>
    
    