<template>
    <div>
        <div @click="blnShow=(!disabled);" :style="(disabled?'color:#999;':'')">
            <!-- <span v-if="model==null" style="color: #757575;">{{placeholder}}</span>
            <span v-else>{{(objCurrent==null?model:objCurrent[nameKey])}}</span> -->
            <span>{{objCurrent==null?placeholder:objCurrent[nameKey]}}</span>
            <!-- <i class="fa-solid fa-chevron-right" style="color:#969799; float: right;"></i> -->
        </div>
    
        <div v-show="blnShow" @click="blnShow=false;" style="position:fixed; left: 0px; top: 0px; width: 100%; height: 100%; z-index: 1000; background-color: rgba(0,0,0,0.7);">
            <div onclick="event.stopPropagation();" :style="'position: absolute; left: 0px; '+(position=='top'?'top:30px;':'bottom:0px;')+' width: 100%; height:50%; background: #fff; max-height: 50%; transition:height 0.5s;'">
                <div v-if="filter" style="height: 40px; margin-top: 10px; display: flex; justify-content: center; align-items: center; align-self: center;">
                    <!-- <div style="float: left; width: 10%;">&nbsp;</div>
                    <div style="float: left; width: 60%; text-align: center;">
                        <input type="text" class="hc_text" style="width: 200px;" v-model="strFilter" placeholder="关键字" />
                        <span v-show="mode==2" class="hc_button hc_button-small" @click="model=strFilter;strFilter='';blnShow=false;">创建</span>
                    </div>
                    <div style="float: left; width: 10%;">&nbsp;</div> -->                
                    <input :type="type" class="hc_text" style="width: 50%; border-bottom: 1px solid #cdcdcd;" @click="$event.currentTarget.select();" v-model="strFilter" placeholder="关键字" />
                    <!-- <button v-show="mode==2" class="hc_button hc_button-small" @click="model=null;strFilter='';blnShow=false;" style="margin-left: 10px;">创建</button> -->
                    <button v-show="mode==2" class="hc_button hc_button-small" @click="change(2,null);" style="margin-left: 10px;">创建</button>
                    <!-- <button v-show="mode==2" class="hc_button hc_button-small" @click="model=-1;objCurrent={Id:-1,Number:strFilter};blnShow=false;" style="margin-left: 10px;">创建</button> -->
                </div>
                <div style="height:calc(100% - 50px); overflow: auto;">
                    <ul>
                        <!-- <li v-for="objItem in data" v-show="strFilter==''?true:(objItem[nameKey].indexOf(strFilter)>-1)" @click="change(1,objItem);" style="display: flex; height: 40px; align-items: center; border-bottom: 1px solid #cdcdcd;"> -->
                        <li v-for="objItem in arrData" @click="change(1,objItem);" style="display: flex; height: 40px; align-items: center; border-bottom: 1px solid #cdcdcd;">
                            <div style="flex-grow: 1; padding:0px 20px;">{{objItem[nameKey]}}</div>
                            <div style="width: 40px;"><label class="hc_radio"><input type="radio" v-model="model" :value="parseInt(objItem[idKey])" /></label></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        name: "PopubRadio",
        mixins: [],
        components: {},
        model:{
            prop: "value",
            event: "input"
        },
        props: {
            value: {
                type: Number
                // default: ""
            },
            mode:{  // 1:选择 2:创建
                type: Number,
                default: 2
            },
            data: {     // [{Id:'',Name:''}]
                type: Array,
                default(){return []}
            },
            type: { // text,tel
                type: String,
                default: "text"
            },
            idKey:{
                type: String,
                default: "Id"
            },
            nameKey:{
                type: String,
                default: "Name"
            },
            position:{  // top, bottom
                type: String,
                default: "bottom"
            },
            filter:{
                type: Boolean,
                default: false
            },
    
            placeholder:{
                type: String,
                default: "请选择"
            },
            disabled:{
                type: Boolean,
                default: false
            },
        },
        data: function() {
            return{
                blnShow: false,
                strFilter: "",
                // nCurrent: this.value,
                objCurrent: null,
                arrData:[]
            }
        },
        computed: {
            model:{
                get:function(){
                    // console.log('a2');
                    if(this.value != null){                                        
                        for(var i = 0; i < this.data.length; i++){
                            if(this.value == this.data[i][this.idKey]){
                                this.objCurrent = this.data[i];
                                break;
                            }
                        }                  
                    }
                    else{
                        if(this.mode==2){
                            this.objCurrent = null;
                        }
                    }
                    // if(this.value != null){
                    //     if(this.mode==2){
                    //         this.objCurrent = null;
                    //     }
    
                    //     for(var i = 0; i < this.data.length; i++){
                    //         if(this.value == this.data[i][this.idKey]){
                    //             this.objCurrent = this.data[i];
                    //             break;
                    //         }
                    //     }
                    // }
                    return this.value;
                },
                set:function(value){
                    // console.log('a1');
                    this.$emit('input', value);
                }
            }
            // text:function(){
            //     if(this.nCurrent==null){
            //         return "请选择";
            //     }
            //     else{
            //         return this.objCurrent.Name;
            //     }
            // }
        },
        watch: {
            strFilter:function(newValue, oldValue){
                var arrTemp = [];
                if(this.strFilter==""){
                    for(var i = 0; i < (this.data.length>50?50:this.data.length); i++){
                        arrTemp.push(this.data[i]);
                    }
                }
                else{
                    for(var i = 0; i < this.data.length; i++){
                        if(this.data[i][this.nameKey].indexOf(this.strFilter)>-1){
                            arrTemp.push(this.data[i]);
                        }
                        if(arrTemp.length>50){
                            break;
                        }
                    }
                }
                this.arrData = arrTemp;
            }
            // value:function(newValue, oldValue){
            //     console.log('a3');
            //     // this.nCurrent = this.value;
            // }
        },
        created: function() {
            // if(this.value != null){     
            //     console.log(this.value);               
            //     console.log(this.data.length);
            //     for(var i = 0; i < this.data.length; i++){
            //         if(this.value == this.data[i][this.idKey]){
            //             this.objCurrent = this.data[i];
            //             break;
            //         }
            //     }
            //     console.log('c1',this.objCurrent)
            // }
        },
        mounted: function() {},
        destroyed: function() {},
        methods: {
            change: function(nType, objItem){
                if(nType==1){   // choose
                    this.objCurrent=objItem;
                    this.model=parseInt(objItem[this.idKey]);
                }
                else if(nType==2){  // Create
                    this.objCurrent={};
                    this.objCurrent[this.idKey]=-1;
                    this.objCurrent[this.nameKey]=this.strFilter;
                    this.model=-1;
                }
                else{   // Cancel
                }
                this.blnShow=false;
                this.$emit('change', this.objCurrent);
            }
        }
    };
    </script>
    
    <style scoped>
    
    </style>
    
    