<template>

    <!-- <input type="text" class="hc_text" :value="value" @input="$emit('input', $event.target.value)" data-vv-as="名称" /><button @click="save">提交</button> -->
<div class="form-item">
    <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>
    <!-- <div class="form-item-bd">
        <input type="text" :value="value" class="hc_text" @input="$emit('input', $event.target.value)" :name="name" :v-validate="validate" :placeholder="placeholder" :disabled="disabled" autocomplete="off" />
        <div class="form-error" v-show="errors.has(name)">{{errors.first(name)}}</div>        
    </div> -->
    <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }" :vid="vid">
        <input :type="type" class="hc_text" :value="value" @input="$emit('input', $event.target.value)" :name="name" :placeholder="placeholder" :disabled="disabled" autocomplete="off" />
        <div class="form-error" v-show="errors[0]">{{errors[0]}}</div>          
    </validation-provider>
    <div class="form-item-ft">
        <slot name="footer"></slot>      
        <i :class="rightIcon"></i>
    </div>
</div>

</template>

<script>

export default {
    name: "TextItem",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        type: { // text,tel,password
            type: String,
            default: "text"
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        // required:{
        //     type: Boolean,
        //     default: false
        // },
        validate:{
            type: String,
            default: ""
        },
        vid:{
            type: String,
            default: ""
        },

        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {},
    destroyed: function() {},
    methods: {}
};
</script>

<style scoped>

</style>

