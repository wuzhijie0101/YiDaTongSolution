<template>    
<div class="form-item">
    <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>
    <!-- <div class="form-item-bd">
        <input type="number" :value="value" class="hc_text" @input="valueChange($event)" :name="name" v-validate="validate" :placeholder="placeholder" :disabled="disabled" autocomplete="off" />
        <div class="form-error" v-show="errors.has(name)">{{errors.first(name)}}</div>    
    </div> -->

    <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }">
        <input :type="type" class="hc_text" :value="value" @input="valueChange($event)" :name="name" :placeholder="placeholder" :disabled="disabled" autocomplete="off" />
        <div class="form-error" v-show="errors[0]">{{errors[0]}}</div>          
    </validation-provider>
    <div class="form-item-ft">
        <slot name="footer"></slot>      
        <i :class="rightIcon"></i>
    </div>
</div>
</template>

<script>

export default {
    name: "NumberItem",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: Number,
            default: ""
        },

        type: { // text,number
            type: String,
            default: "number"
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        // required:{
        //     type: Boolean,
        //     default: false
        // },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {
        console.log(this.validate);
    },
    destroyed: function() {},
    methods: {
        valueChange:function(event){
            // if(!isNaN(parseFloat(event.target.value)) && isFinite(event.target.value)){                     
            //     // this.$emit('input', parseFloat(event.target.value));
            //     this.$emit('input', event.target.value);
            // }
            // else{                
            //     this.$emit('input', null);
            // }

            if(event.target.value == ""){
                this.$emit('input', null);    
            }
            else{
                this.$emit('input', parseFloat(event.target.value));
            }
        }
    }
};
</script>

<style scoped>

</style>

