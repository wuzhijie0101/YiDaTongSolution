<template>    
<div class="form-item">
    <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>    
    <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }">
        <!-- <input type="text" class="hc_text" :value="value" @input="$emit('input', $event.target.value)" :name="name" :placeholder="placeholder" :disabled="disabled" autocomplete="off" /> -->
        <textarea class="hc_textarea" :value="value" @input="$emit('input', $event.target.value)" :name="name" :rows="rows" :placeholder="placeholder" :disabled="disabled"></textarea>
        <div class="form-error" v-show="errors[0]">{{errors[0]}}</div>          
    </validation-provider>
    <div class="form-item-ft">
        <slot name="footer"></slot>      
        <i :class="rightIcon"></i>
    </div>
</div>

</template>

<script>

export default {
    name: "TextareaItem",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },        
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },
        disabled:{
            type: Boolean,
            default: false
        },

        rows: {
            type: Number,
            default: 3
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {},
    destroyed: function() {},
    methods: {}
};
</script>

<style scoped>

</style>

