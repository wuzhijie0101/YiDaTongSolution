<template>
    <!-- <label class="hc_radio">
        <input type="radio" @change="$emit('change', $event)" /><span>{{label}}</span>
    </label> -->
    <div class="form-item">
        <div class="form-item-hd"><i :class="leftIcon"></i>{{name}}</div>
        <div class="form-item-bd">
            <label class="hc_radio" v-for="objItem in data">                
                <input type="radio" v-model="model" :value="parseInt(objItem[idKey])" :name="name" :disabled="disabled" /><span>{{objItem[nameKey]}}</span>
                <!-- <input type="radio" @change="$emit('change', $event.target._value)" :value="parseInt(objItem.Value)" :name="name" :disabled="disabled" /><span>{{objItem.Name}}</span> -->
            </label>            
        </div> 
        <div class="form-item-ft">
            <slot name="footer"></slot>      
            <i :class="rightIcon"></i>
        </div>
    </div>
</template>

<script>

export default {
    name: 'RadioItem',
    model:{
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: Number,
            default: null
        },
        data: {     // [{Value:'',Name:''}]
            type: Array,
            default(){return []}            
        },
        idKey:{
            type: String,
            default: "Value"
        },
        nameKey:{
            type: String,
            default: "Name"
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        disabled:{
            type: Boolean,
            default: false
        }
    },
    data: function() {
        return{            
        }
    },
    computed: {
        model:{
            get:function(){
                return this.value;
            },
            set:function(value){
                this.$emit('change', value);
            }
        }
    },
    watch: {},
    created: function() {},
    mounted: function() {
        // var arrRadio = document.getElementsByName(this.name);      
        // for(var i = 0; i < arrRadio.length; i++){                
        //     if(this.value == arrRadio[i]._value){                    
        //         arrRadio[i].checked = true;
        //         break;
        //     }
        // }
    },
    destroyed: function() {},
    methods: {        
    }
};
</script>

<style scoped>

</style>
    
    