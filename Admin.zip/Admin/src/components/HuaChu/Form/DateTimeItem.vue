<template>    
<div class="form-item">
    <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>
    
    <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }">
        <input :type="type" :class="'hc_text' + (value==''?'':' hasContent')" :value="value" @input="$emit('input', $event.target.value)" :name="name" :placeholder="placeholder" :disabled="disabled" />
        <div class="form-error" v-show="errors[0]">{{errors[0]}}</div>
    </validation-provider>
    <div class="form-item-ft">
        <slot name="footer"></slot>      
        <i :class="rightIcon"></i>
    </div>
</div>

</template>

<script>

export default {
    name: "DateTimeItem",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        type: { // date,time,datetime-local
            type: String,
            default: "date"
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {},
    destroyed: function() {},
    methods: {}
};
</script>

<style scoped>

</style>

