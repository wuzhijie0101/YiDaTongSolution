<template>
<div class="form-item">
    <div class="form-item-hd"><span v-if="validate.indexOf('required')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div>

    <validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }">
        <slot name="body"></slot>
        <div class="form-error" v-show="errors[0]">{{errors[0]}}</div>          
    </validation-provider>
    <div class="form-item-ft">
        <slot name="footer"></slot>      
        <i :class="rightIcon"></i>
    </div>
</div>

</template>

<script>

export default {
    name: "Item",
    mixins: [],
    components: {},
    props: {
        value: {
            type: String,
            default: ""
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        }
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {},
    destroyed: function() {},
    methods: {}
};
</script>

<style scoped>

</style>

