<template>
    <input type="text" :value="value" @input="valueChange($event)" @focus="$emit('focus', parseFloat($event.target.value));" @change="$emit('change', parseFloat($event.target.value));" @click="$event.currentTarget.select();" />
</template>
    
<script>

export default {
    name: "Number",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: Number,
            default: ""
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {            
    },
    destroyed: function() {},
    methods: {
        valueChange:function(event){      
            // !isNaN(parseFloat(value)) && isFinite(value);                   
            // console.log('a1', event.target.value);
            // console.log(parseFloat(event.target.value));
            // console.log(isNaN(parseFloat(event.target.value)));
            // console.log(isFinite(event.target.value));
            // console.log(isNaN(parseFloat(event.target.value)) && isFinite(event.target.value));

            // this.$emit('input', parseFloat(event.target.value));
            // // if(!isNaN(parseFloat(event.target.value))){                     
            // //     this.$emit('input', parseFloat(event.target.value));
            // // }
            // // else{                
            // //     this.$emit('input', null);
            // // }
            if(!isNaN(parseFloat(event.target.value)) && isFinite(event.target.value)){                     
                this.$emit('input', parseFloat(event.target.value));
            }
            else{                
                this.$emit('input', null);
            }
        }
    }
};
</script>

<style scoped>

</style>

    