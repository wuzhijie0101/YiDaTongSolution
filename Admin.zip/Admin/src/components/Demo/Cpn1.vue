<template>

    <!-- <input type="text" class="hc_text" :value="value" @input="$emit('input', $event.target.value)" data-vv-as="名称" /><button @click="save">提交</button> -->
<div class="form-item">
    <div class="form-item-hd"><span v-if="required" class="form-required">*</span>{{name}}：</div>
    <div class="form-item-bd">
        <input type="text" :value="value" class="hc_text" @input="$emit('input', $event.target.value)" :name="name" :v-validate="validate" :placeholder="placeholder" :disabled="disabled" autocomplete="off" />
        <div class="form-error" v-show="errors.has(name)">{{errors.first(name)}}</div>
    </div> 
</div>

</template>

<script>

export default {
    name: "HuaChuFormInput",
    mixins: [],
    components: {},
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        name: {
            type: String,
            default: ""
        },
        required:{
            type: Boolean,
            default: false
        },
        validate:{
            type: String,
            default: "{}"
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{                
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {},
    destroyed: function() {},
    methods: {
        save: function(){
            this.$emit("btnsave",{name: this.name, age:15, address:"shenzhen"});
        },
        calltest:function(strName){
            console.log(strName);
        }
    }
};
</script>

<style scoped>

</style>

