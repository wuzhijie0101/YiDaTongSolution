// import Vue from "vue";

const route = Object.create(null)
route.install = function (Vue) {
    // 第一个字符串是 组件名，第二个是组件路径，第三个是包名(如果不指定则已1.js,2.js....n.js命名)    
    Vue.component('AccountLogin', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Account/Login.vue')))});
        
    // 翼达通
    Vue.component('SustomsStatList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/SustomsStat/List.vue')))});

    // 空港航服
    Vue.component('InfieldFerryListPrint', (resolve) => {require.ensure([], ()=>resolve(require('@/views/InfieldFerry/ListPrint.vue')))});

    // 系统设置
    Vue.component('EmployeeList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Employee/List.vue')))});      
    Vue.component('DictionaryList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Dictionary/List.vue')))});    
    Vue.component('PowerModuleList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/PowerModule/List.vue')))});
    Vue.component('AirLineList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/AirLine/List.vue')))});
    Vue.component('PageList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Page/List.vue')))});
    Vue.component('PowerRoleList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/PowerRole/List.vue')))});


    Vue.component('OutOrderList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/OutOrder/List.vue')))});
    Vue.component('OutOrderEdit', (resolve) => {require.ensure([], ()=>resolve(require('@/views/OutOrder/Edit.vue')))});    

    // 客服
    Vue.component('GroundDispatchService', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Ground/DispatchService.vue')))});  
    Vue.component('OutOrderListKF', (resolve) => {require.ensure([], ()=>resolve(require('@/views/OutOrder/ListKF.vue')))});

    // 地面
    Vue.component('GroundDispatch', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Ground/Dispatch.vue')))});    
    Vue.component('ReportListDMFin', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListDMFin.vue')))});
    Vue.component('GroundDispatchScene', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Ground/DispatchScene.vue')))});  

    // 跨境电商
    Vue.component('ReportListKJOutOrder', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListKJOutOrder.vue')))});
    Vue.component('ReportListKJSelf', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListKJSelf.vue')))});
    Vue.component('OutOrderListKJ', (resolve) => {require.ensure([], ()=>resolve(require('@/views/OutOrder/ListKJ.vue')))});

    // 前置仓
    Vue.component('ReportListQZCOutOrder', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListQZCOutOrder.vue')))});
    
    // 地面
    Vue.component('BoardDispatch', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Board/Dispatch.vue')))});
    
    // 组板
    Vue.component('ReportListZBExport', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListZBExport.vue')))});
    Vue.component('ReportListZBVolume', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListZBVolume.vue')))});
    Vue.component('ReportListZBWork', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Report/ListZBWork.vue')))});

    // Vue.component('SupplierList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Supplier/List.vue')))});  
    // Vue.component('LedgerList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Ledger/List.vue')))});  
    // Vue.component('BillList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/Bill/List.vue')))});  
    // Vue.component('BillItemList', (resolve) => {require.ensure([], ()=>resolve(require('@/views/BillItem/List.vue')))});
}


export default route