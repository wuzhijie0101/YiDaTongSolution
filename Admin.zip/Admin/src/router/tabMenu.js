import Vue from 'vue';

export default {
    namespaced: true,
    state:{
        // blnLoad: false,     // 是否已初始化数据
        arrData: [],
        objMapping: {},
        arrType1:[],
        // arrType2:[],
        arrType3:[
            { Id: '2001', Name: "字典管理", Link: "DictionaryList", BizParam:'{}' },
            { Id: '2003', Name: "权限页面管理", Link: "PowerModuleList", BizParam:'{}' },
            // { Id: '2004', Name: "权限角色管理", Link: "PowerRoleList", BizParam:'{}' },
            { Id: '2002', Name: "职员账号管理", Link: "EmployeeList", BizParam:'{}' },   
            // // o系统设置
            // { Id: '2005', Name: "店铺管理", Link: "ShopList", BizParam:'{}' },
            // { Id: '2002', Name: "职员账号管理", Link: "EmployeeList", BizParam:'{}' },            
            // { Id: '2003', Name: "我的收款账户", Link: "SettleAccountList", BizParam:'{}' },
            // { Id: '2013', Name: "权限角色管理", Link: "PowerRoleList", BizParam:'{}' },

            // { Id: '2006', Name: "第一步：提成档次设置", Link: "ProductPercentageGradeSetGrade", BizParam:'{}' },
            // { Id: '2007', Name: "第二步：分类提成比例设置", Link: "ProductPercentageGradeSetProductCategory", BizParam:'{}' },
            // { Id: '2008', Name: "第三步：产品提成比例设置", Link: "ProductPercentageGradeSetProductItem", BizParam:'{}' },
            // { Id: '2009', Name: "第四步：销售提成分配设置", Link: "ProductPercentageGradeSetEmployee", BizParam:'{}' },
            
            // { Id: '2010', Name: "打印设置", Link: "PrintSetList", BizParam:'{}' },
            // { Id: '2004', Name: "合作物流网点运费管理", Link: "LogisticsSupplierList", BizParam:'{}' },                        
            // { Id: '2011', Name: "电子面单设置", Link: "ElectronOrderSetList", BizParam:'{}' },

            // // o客户
            // { Id: '1001', Name: "公有库客户管理", Link: "CustomerList", BizParam:'{"DataType":1}' },
            // { Id: '1011', Name: "私有库客户管理", Link: "CustomerList", BizParam:'{"DataType":2}' },
            // { Id: '1002', Name: "客户公司管理", Link: "CustomerCompanyList", BizParam:'{}' },
            // { Id: '1003', Name: "客户地址管理", Link: "CustomerAddressList", BizParam:'{}' },
            // { Id: '1004', Name: "客户黑名单管理", Link: "CustomerBlacklistList", BizParam:'{}' },
            // { Id: '1005', Name: "修改记录管理", Link: "OperationRecordCustomerList", BizParam:'{}' },  
            // { Id: '1006', Name: "客户付款明细", Link: "CustomerPayDetailList", BizParam:'{}' },            
            // { Id: '1008', Name: "销售单收款", Link: "CustomerPayDetailCreateForPO", BizParam:'{}' },
            // { Id: '1009', Name: "客户月结对账", Link: "CustomerVerifyList", BizParam:'{}' },
            // { Id: '1010', Name: "客户付款核对", Link: "CustomerPayDetailListFinCheck", BizParam:'{}' },

            // // o仓库
            // { Id: '3007', Name: "仓库管理", Link: "WarehouseList", BizParam:'{}' },       
            // { Id: '3001', Name: "单位管理", Link: "BaseUnitList", BizParam:'{}' },          
            // { Id: '3002', Name: "产品分类管理", Link: "ProductCategoryList", BizParam:'{}' },
            // { Id: '3003', Name: "规格管理", Link: "SpecNameList", BizParam:'{}' },
            // { Id: '3005', Name: "产品管理", Link: "ProductList", BizParam:'{}' },
            // { Id: '3006', Name: "品牌管理", Link: "BaseBrandList", BizParam:'{}' },
            // { Id: '3008', Name: "原材料分类管理", Link: "ProductCategoryList2", BizParam:'{}' },
            // { Id: '3009', Name: "原材料管理", Link: "ProductList2", BizParam:'{}' },

            // // o采购
            // { Id: '4001', Name: "供应商管理", Link: "SupplierList", BizParam:'{}' },
            // { Id: '4002', Name: "供应商收款账户", Link: "SettleAccountListSupplier", BizParam:'{}' },
            // { Id: '4003', Name: "采购单管理", Link: "PurchaseOrderList", BizParam:'{}' },
            // { Id: '4004', Name: "入库管理", Link: "InputOrderList", BizParam:'{}' },
            // { Id: '4005', Name: "供应商月结对账", Link: "SupplierVerifyList", BizParam:'{}' },
            // { Id: '4006', Name: "供应商付款明细", Link: "SupplierPayDetailList", BizParam:'{}' },


            // // o销售
            // { Id: '5001', Name: "销售单管理", Link: "ProductOrderList", BizParam:'{}' },
            // { Id: '5002', Name: "出库管理", Link: "OutputOrderList", BizParam:'{}' },            

            // // o财务
            // { Id: '6001', Name: "客户开票信息管理", Link: "CustomerInvoiceInforList", BizParam:'{}' },
            // { Id: '6002', Name: "自开发票管理", Link: "InvoiceOrderList", BizParam:'{}' },
            // { Id: '6003', Name: "供应商代开发票管理", Link: "InvoiceOrderListSupplier", BizParam:'{}' },

            // // o报表
            // { Id: '7001', Name: "职员提成明细", Link: "EmployeeBonusDetailList", BizParam:'{}' },
            // { Id: '7002', Name: "职员提成结算", Link: "EmployeeBonusList", BizParam:'{}' },

            // { Id: '7003', Name: "客户待发货统计", Link: "ReportListCustomerPO", BizParam:'{}' },
            // { Id: '7004', Name: "商品待发货统计", Link: "ReportListProductPO", BizParam:'{}' },
            // { Id: '7005', Name: "销售单总额统计", Link: "ReportListMoneyPO", BizParam:'{}' },
            // { Id: '7006', Name: "商品销量统计", Link: "ReportListAmountPO", BizParam:'{}' },
            // { Id: '7007', Name: "出库单运费统计", Link: "ReportListFreight", BizParam:'{}' },            
        ],
        // arrType4:[],
        arrMenuVisible:[],  // 菜单导航是否弹出显示


        blnIsCollapse: false,
        arrOne:[
            // { strId: '2001', strTitle: "字典管理" }
        ],
        arrMenu:[
            // { strId: '2001', strTitle: "登录", strPath: "AccountLogin" }     

            // 系统设置
            { strId: '2001', strTitle: "字典管理", strPath: "DictionaryList" },
            { strId: '2002', strTitle: "职员管理", strPath: "EmployeeList" },            
            { strId: '2003', strTitle: "权限页面管理", strPath: "PowerModuleList" },   
        ],
        strHomeId: "100",       // 首页Name
        strActiveId: "100",     // 激活Name
        arrTab:[    // 当前Tab列表
            // { strId: '2001', strTitle: "字典管理", strPath: "DictionaryList" }                   
        ],
        
        nIdentityId: 0, // 自增长Id
    },
    getters:{        
    },
    mutations:{
        selectMenu:function(state, strId){
            strId = '' + strId; // 将数字型转换成字符串型
            if (state.strActiveId == strId) {  // 点击当前项
                return;
            }

            if (strId == state.strHomeId) {
                state.strActiveId = strId;
                return;
            }

            var blnIsHave = false;
            for (var i = 0; i < state.arrTab.length; i++) {
                if (state.arrTab[i].strId == strId) {
                    blnIsHave = true;
                    state.strActiveId = strId;
                    break;
                }
            }

            if (blnIsHave == false) {                                
                for (var i = 0; i < state.arrType3.length; i++) {                    
                    if (state.arrType3[i].Id == strId) {
                        state.arrTab.push({ strId: ''+state.arrType3[i].Id, strTitle: state.arrType3[i].Name, strPath: state.arrType3[i].Link, jobjBizParam: JSON.parse(state.arrType3[i].BizParam) });
                        // state.arrTab.push({ strId: ''+state.arrType3[i].strId, strTitle: state.arrType3[i].strTitle, strPath: state.arrType3[i].strPath, jobjBizParam: state.arrType3[i].BizParam });
                        state.strActiveId = strId;
                        break;
                    }
                }

                // for (var i = 0; i < state.arrMenu.length; i++) {
                //     if (state.arrMenu[i].strId == strId) {
                //         state.arrTab.push({ strId: state.arrMenu[i].strId, strTitle: state.arrMenu[i].strTitle, strPath: state.arrMenu[i].strPath, jobjBizParam: state.arrMenu[i].BizParam });
                //         state.strActiveId = strId;
                //         break;
                //     }
                // }
            }
        },
        closeTab:function(state,strId){
            strId = ''+strId;
            for (var i = 0; i < state.arrTab.length; i++) {
                if (state.arrTab[i].strId == strId) {
                    if (state.strActiveId == strId) {
                        state.strActiveId = (i == 0 ? state.strHomeId : state.arrTab[i - 1].strId);
                    }
                    state.arrTab.splice(i, 1);
                    break;
                }
            }
        },
        addTabIdentity:function(state,objItem){ 
            state.nIdentityId += 1;
            objItem.jobjBizParam.TabId = ''+state.nIdentityId;
            state.arrTab.push({ strId: ''+state.nIdentityId, strTitle: objItem.strTitle + state.nIdentityId, strPath: objItem.strPath, jobjBizParam: objItem.jobjBizParam });
            state.strActiveId = ''+state.nIdentityId;
        },
        addTab:function(state,objItem){
            for(var i = 0; i < state.arrTab.length; i++){
                if(state.arrTab[i].strId == objItem.strId){
                    state.strActiveId = ''+objItem.strId;
                    return;
                }
            }

            objItem.jobjBizParam.TabId = ''+objItem.jobjBizParam.TabId;
            state.arrTab.push({ strId: ''+objItem.strId, strTitle: objItem.strTitle, strPath: objItem.strPath, jobjBizParam: objItem.jobjBizParam });
            state.strActiveId = ''+objItem.strId;
        },

        init:function(state, arrData){     
            /* 初始化操作权限 */      
            for(var i = 0; i < arrData.length; i++){
                arrData[i].HasPower = false;
            }

            state.arrData = arrData;
            for(var i = 0; i < arrData.length; i++){
                state.objMapping[arrData[i].Id] = arrData[i];
            }

            /* 初始化操作权限 */
            var jobjUser = Lib.Global.vueRoot.prototype.$store.state.jobjUser;            
            if(jobjUser.OperatePower == 1){
                for(var i = 0; i < state.arrData.length; i++){
                    state.arrData[i].HasPower = true;
                }
            }
            else{
                for(var i = 0; i < state.arrData.length; i++){
                    if(state.arrData[i].Type==3){   // 初始化页面、层级和模块的权限
                        if (jobjUser.PM_IdList.indexOf("," + state.arrData[i].Id + ",") > -1) {            
                            state.arrData[i].HasPower = true;
                            state.objMapping[state.arrData[i].ParentId].HasPower = true;    // 层级或者模块
                            if(state.objMapping[state.arrData[i].ParentId].Type==2){        // 当父级为层级时
                                state.objMapping[state.objMapping[state.arrData[i].ParentId].ParentId].HasPower = true; // 模块
                            }
                        }
                    }
                    else if(state.arrData[i].Type==4){  // 初始化操作权限
                        if (jobjUser.PM_IdList.indexOf("," + state.arrData[i].Id + ",") > -1) {            
                            state.arrData[i].HasPower = true;                                                    
                        }
                    } 
                }
            }

            var arrTemp = Vue.prototype.$lib.Common.getTreeData(arrData);
            for(var i = 0; i < arrTemp.length; i++){
                arrTemp[i].HasPage = false;    // 是否有页面类型的子级
                for(var j = 0; j < arrData.length; j++){
                    if(arrTemp[i].Id == arrData[j].ParentId && arrData[j].Type == 3){
                        arrTemp[i].HasPage = true;
                        break;
                    }
                }
            }            
            state.arrType1 = arrTemp;
            
            arrTemp = arrData.filter(function(objItem){
                return objItem.Type == 3;
            });
            // for(var i = 0; i < arrTemp.length; i++){
            //     arrTemp[i].Children = new Array();    // 子级类型是层级                
            //     for(var j = 0; j < arrData.length; j++){
            //         if(arrTemp[i].Id == arrData[j].ParentId){
            //             arrTemp[i].Children.push(arrData[j]);        
            //         }
            //     }
            // }            
            for(var i = 0; i < arrTemp.length; i++){
                state.arrType3.push(arrTemp[i]);
            }
            // console.log(state.arrType3);

            // var arrTemp = arrData.filter(function(objItem){
            //     return objItem.Type == 1;
            // });
            // for(var i = 0; i < arrTemp.length; i++){
            //     arrTemp.Children2 = new Array();    // 子级类型是层级
            //     arrTemp.Children3 = new Array();    // 子级类型是页面
            //     for(var j = 0; j < arrData.length; j++){
            //         if(arrTemp[i].Id == arrData[j].ParentId){
            //             if(arrData[j].Type==2){                            
            //                 arrTemp.Children2.push(arrData[j]);                            
            //             }
            //             else if(arrData[j].Type==3){
            //                 arrTemp.Children3.push(arrData[j]);
            //             }        
            //         }
            //     }
            // }
            // state.arrType1 = arrTemp;
        }
    },
    actions:{
        init:function(context){
            // if(context.state.blnLoad==true){
            //     return;
            // }
            return;
            var objWhere = {
                "Type": { "strField": "Type", "strCondition": "in", "strValue": "1,2,3", "strSingleQuotes": "" },
                "Enable": { "strField": "Enable", "strCondition": "=", "strValue": "1", "strSingleQuotes": "" }
            }
            Vue.prototype.$ajax.get('/JDY/PowerModule/Get', { Field: "*", Where:objWhere, OrderBy:"Sort desc,Id asc" }).then(objResult => {
                var arrTemp = new Array();
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].Type==1){
                        arrTemp.push({ strId: ''+ objResult.data[i].Id, strTitle: objResult.data[i].Name });
                    }
                }
                context.state.arrOne = arrTemp;
            
                arrTemp = new Array();
                for(var i = 0; i < objResult.data.length; i++){
                    if(objResult.data[i].Type==3){          
                        arrTemp.push({ strId: ''+objResult.data[i].Id, strTitle: objResult.data[i].Name, strPath: objResult.data[i].Link, ParentId:''+objResult.data[i].ParentId, BizParam:JSON.parse(objResult.data[i].BizParam) });
                    }
                }
                context.state.arrMenu = arrTemp;      
            });
        }
    }
  }