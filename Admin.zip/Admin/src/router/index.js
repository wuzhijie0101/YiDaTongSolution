import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/Account/Login', component: function() { return import('@/views/Account/Login.vue'); }, meta: { title: "登录 - 翼达通" } },
    { 
      path: '/Page/Download', 
      component: function() { return import('@/views/Download/index.vue'); }, 
      meta: { 
        title: "APP下载 - 翼达通",
        requireAuth: true  // 需要登录才能访问
      } 
    }
  ]
})
