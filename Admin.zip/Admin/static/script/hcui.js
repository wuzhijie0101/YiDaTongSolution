var i18n = {};      // 国际化
i18n.cn = {
};
i18n.en ={
};
i18n.zh_tw = {
};

var Lib = {};

Lib.Config = {  // 配置文件
    Environment: "_dev",        // 系统环境 _dev:开发; _test:测试; 空:生产prod;
    Url_ApiRequest: "",
    Url_ApiUpload: "",
    Url_WebSite: "",
    Url_WeChat: "",

    // FWH_AppId: "wx5d7ba47d0e63819c",  // 应用Id

    CURD: "",   // 增改查删插件设置
    Ajax: "jquery", // ajax请求插件设置
    EndDev: "Vue",        // 多端开发 Vue、YonYou、Browser、Bra
    Init: function () {
        switch (this.Environment) {
            case "":    // 生产
                // this.Url_ApiRequest = "http://106.53.108.224:8010";
                // this.Url_ApiUpload = "http://106.53.108.224:8010";
                // this.Url_WebSite = "http://106.53.108.224:8010";
                // this.Url_WeChat = "http://106.53.108.224:8012/#";
                this.Url_ApiRequest = "http://api.xinchen168.cn";
                this.Url_ApiUpload = "http://api.xinchen168.cn";
                this.Url_WebSite = "http://www.xinchen168.cn";
                this.Url_WeChat = "http://wechat.xinchen168.cn/#";
                break;
            case "_dev":    // 开发
                this.Url_ApiRequest = "http://a.xinchen168.cn";
                this.Url_ApiUpload = "http://a.xinchen168.cn";
                this.Url_WebSite = "http://m.xinchen168.cn";
                this.Url_WebSite = "http://m.xinchen168.cn";
                this.Url_WeChat = "http://wechat.xinchen168.cn/#";
                break;
            case "_test":   // 测试
                this.Url_ApiRequest = "http://192.168.4.108:44302";
                this.Url_ApiUpload = "http://192.168.4.108:44302";
                this.Url_WebSite = "http://192.168.4.108:44302";
                this.Url_WeChat = "http://106.53.108.224:8012/#";
                // this.Url_ApiRequest = "http://192.168.3.177:1227";
                // this.Url_ApiUpload = "http://192.168.3.177:1227";
                // this.Url_WebSite = "http://192.168.3.177:1227";
                break;
        }

        switch (this.Ajax) {
            case "Axios":
                Lib.Ajax = AjaxAxios;
                break;
            default:
                Lib.Ajax = AjaxJQuery;
                break;
        }
        switch (this.CURD) {
            case "Vant":
                Lib.CURD = Lib.Vant.CURD;
                break;
            default:
                Lib.CURD = Lib.Element.CURD;
                break;
        }
        switch(this.EndDev){
            case "YonYou":
                Lib.EndDev = EndDev.YonYou;
                break;
            case "Vue":
                Lib.EndDev = EndDev.Vue;
                break;
            case "Braba":
                Lib.EndDev = EndDev.Braba;
                break;
            default:
                Lib.EndDev = EndDev.Browser;
                break;
        }
    }
};

Lib.CURD = null;    // 增改查删
Lib.Ajax = null;    // ajax请求
Lib.EndDev = null;  // 多端开发

Lib.Global = {  // 全局变量
    vueRoot: null,      // Vue根节点
    vueThis: null,      // Vue当前节点
    jobjUser: null,     // 登录用户信息

    nStatusHeight: 0,   // APP手机状态栏高度,不同的手机会不同.
};

function Hashtable(){
    this.arrKeys = [];
    this.objValues = {};
    
    this.isHas = function(objKey){  // true存在;fasle不存在
        return this.objValues.hasOwnProperty(objKey);
    };
    this.add = function(objKey, objValue, blnForce = false){ // objKey可以为int或者string; objValue可以为int、string或者对象; 
        if(blnForce == false && this.objValues.hasOwnProperty(objKey) == true){
            throw "该"+objKey+"已存在";
        }
        this.objValues[objKey] = objValue;
    };
    this.remove = function(objKey, blnRemoveValue = true){  // blnRemoveValue:true表示删除值；false表示不删除值，只删除键
        for(var i = 0; i < arrKeys.length; i++){
            if(objKey == arrKeys[i]){
                arrKeys.splice(i,1);
                break;
            }
        }

        if(blnRemoveValue == true){
            delete objValues[objKey];
        }        
    };
}

Lib.Store = {   // 状态管理
    Dictionary: {
        arrData: [],
        objMapKey: null
    },
    Employee:{
        arrData: [],
        objMapping: {}
    },
    AirLine:{
        arrData: [],
        objMapping: {}
    },
    BasePackage:{
        arrData: [],
        objMapping: {}
    },
    Company:{
        arrData: [],
        objMapping: {}
    },
    PowerRole:{
        arrData: [],
        objMapping: {}
    },
    CompanyCustomer:{
        arrData: [],
        objMapping: {}
    },
    // Ledger:{
    //     arrData: [],
    //     objMapping: {}
    // },
    
    init: function(){        
        Lib.EndDev.Store.init();
    },
    insert: function(strKey, objData){        
        Lib.EndDev.Store.insert(strKey, objData);
    },
    update: function(strKey, objData){
        Lib.EndDev.Store.update(strKey, objData);
    },
    delete: function(strKey, nId){
        Lib.EndDev.Store.delete(strKey, nId);            
    },

    getValById: function (objMapping, nId, strField = "Name") {
        if (nId == null || nId == "" || objMapping.hasOwnProperty(nId) == false) {
            return (nId == null ? "" : nId);
        }
        return objMapping[nId][strField];
    },
    getValByIds: function (objMapping, strIds, strField = "Name") {
    //    if (strIds == null) {
    //        return "";
    //    }
       var arrIds = Lib.Common.split(strIds, ',', true);
       var strReturn = "";
       for (var i = 0; i < arrIds.length; i++) {
           if (objMapping.hasOwnProperty(arrIds[i]) == true) {
               strReturn += objMapping[arrIds[i]][strField] + ",";
           }
           else {
               strReturn += arrIds[i] + ",";
           }
       }
       
       if (strReturn.length > 0) {
           strReturn = strReturn.substr(0, strReturn.length - 1);
       }
       return strReturn;
    },
    getValFromDic: function(strDicKey, strValue, strField="Name"){
        if(strValue==null) return "";
        return Lib.EndDev.Store.getValFromDic(strDicKey, strValue, strField);
        // var objTemp = Lib.Common.getObjByField(this.Dictionary.objMapKey[strDicKey], "Value", strValue);
        // return (objTemp == null ? strValue : objTemp[strField]);
    }
};


EndDev = { // Browser、YonYou、Vue、Braba
Browser:{
    init: function(){

    },
    Store:{
        
    }
},
YonYou:{
    //================================多端通用方法=========================================//
    init: function(){      
        Lib.EndDev.batCloseWin();

        Vue.prototype.$lib = Lib;
        Vue.prototype.$ajax = Lib.Ajax;
        Vue.prototype.$ajax.init();        
        if(typeof(currency)!='undefined'){
            Vue.prototype.$cur = currency;
        }
        if(typeof(MeScroll)!='undefined'){
            Vue.prototype.$MeScroll = MeScroll;
        }
        // if(typeof(MeScroll)!='undefined'){
        //     Vue.prototype.$MeScroll = MeScroll;
        // }
        if(typeof(dayjs)!='undefined'){
            Vue.prototype.$dayjs = dayjs;
        }

        if(typeof(VeeValidate)!='undefined'){
            VeeValidate.localize('zh_CN', {
                "code": "zh_CN",
                "messages": {
                    "alpha": "{_field_}只能包含字母字符",
                    "alpha_dash": "{_field_}能够包含字母数字字符、破折号和下划线",
                    "alpha_num": "{_field_}只能包含字母数字字符",
                    "alpha_spaces": "{_field_}只能包含字母字符和空格",
                    "between": "{_field_}必须在{min}与{max}之间",
                    "confirmed": "{_field_}不能和{target}匹配",
                    "digits": "{_field_}必须是数字，且精确到{length}位数",
                    "dimensions": "{_field_}必须在{width}像素与{height}像素之间",
                    "email": "{_field_}不是一个有效的邮箱",
                    "excluded": "{_field_}不是一个有效值",
                    "ext": "{_field_}不是一个有效的文件",
                    "image": "{_field_}不是一张有效的图片",
                    "oneOf": "{_field_}不是一个有效值",
                    "integer": "{_field_}必须是整数",
                    "length": "{_field_}长度必须为{length}",
                    "max": "{_field_}不能超过{length}个字符",
                    "max_value": "{_field_}必须小于或等于{max}",
                    "mimes": "{_field_}不是一个有效的文件类型",
                    "min": "{_field_}必须至少有{length}个字符",
                    "min_value": "{_field_}必须大于或等于{min}",
                    "numeric": "{_field_}只能包含数字字符",
                    "regex": "{_field_}格式无效",
                    "required": "{_field_}是必须的",
                    "required_if": "{_field_}是必须的",
                    "size": "{_field_}必须小于{size}KB",
                    "double": "{_field_}字段必须为有效的小数"
                }
            });
            Object.keys(VeeValidate.Rules).forEach(rule => {
                VeeValidate.extend(rule, VeeValidate.Rules[rule]);
            });
            VeeValidate.extend('mobile',{
                validate: function(value) {
                    return Lib.Valid.Regular.regMobile.test(value);
                },
                message: "{_field_}格式无效"
            });
            VeeValidate.extend('dec2',{
                validate: function(value) {
                    return Lib.Valid.Regular.regDec2.test(value);
                },
                message: "{_field_}保留2位小数"
            });
            Vue.component('ValidationObserver', VeeValidate.ValidationObserver);
            Vue.component('ValidationProvider', VeeValidate.ValidationProvider);
        }

        if (Lib.Sys.checkLogin(0) == true) {    // 初始化登录状态
            Lib.Global.jobjUser = JSON.parse(localStorage.getItem("jobjUser"));
        }
        else {
            Lib.Global.jobjUser = null;
        }

        Lib.Global.nStatusHeight = ($api.getStorage('nStatusHeight')||0);
    },
    Store:{
        init: function(){   // 需根据系统自定义
            Lib.Store.Dictionary.arrData = ($api.getStorage('arrDictionary')||[]);
            Lib.Store.Dictionary.objMapKey = ($api.getStorage('objDictionary')||{});
            
            Lib.Store.Employee.arrData = ($api.getStorage('arrEmployee')||[]);
            for(var i = 0; i < Lib.Store.Employee.arrData.length; i++){
                Lib.Store.Employee.objMapping[Lib.Store.Employee.arrData[i].Id] = Lib.Store.Employee.arrData[i];
            }

            Lib.Store.AirLine.arrData = ($api.getStorage('arrAirLine')||[]);
            for(var i = 0; i < Lib.Store.AirLine.arrData.length; i++){
                Lib.Store.AirLine.objMapping[Lib.Store.AirLine.arrData[i].Id] = Lib.Store.AirLine.arrData[i];
            }

            Lib.Store.BasePackage.arrData = ($api.getStorage('arrBasePackage')||[]);
            for(var i = 0; i < Lib.Store.BasePackage.arrData.length; i++){
                Lib.Store.BasePackage.objMapping[Lib.Store.BasePackage.arrData[i].Id] = Lib.Store.BasePackage.arrData[i];
            }

            Lib.Store.Company.arrData = ($api.getStorage('arrCompany')||[]);
            for(var i = 0; i < Lib.Store.Company.arrData.length; i++){
                Lib.Store.Company.objMapping[Lib.Store.Company.arrData[i].Id] = Lib.Store.Company.arrData[i];
            }

            Lib.Store.PowerRole.arrData = ($api.getStorage('arrPowerRole')||[]);
            for(var i = 0; i < Lib.Store.PowerRole.arrData.length; i++){
                Lib.Store.PowerRole.objMapping[Lib.Store.PowerRole.arrData[i].Id] = Lib.Store.PowerRole.arrData[i];
            }

            Lib.Store.CompanyCustomer.arrData = ($api.getStorage('arrCompanyCustomer')||[]);
            for(var i = 0; i < Lib.Store.CompanyCustomer.arrData.length; i++){
                Lib.Store.CompanyCustomer.objMapping[Lib.Store.CompanyCustomer.arrData[i].Id] = Lib.Store.CompanyCustomer.arrData[i];
            }

            
    
            // Lib.Store.Supplier.arrData = ($api.getStorage('arrSupplier')||{});
            // for(var i = 0; i < Lib.Store.Supplier.arrData.length; i++){
            //     Lib.Store.Supplier.objMapping[Lib.Store.Supplier.arrData[i].Id] = Lib.Store.Supplier.arrData[i];
            // }
    
            // var arrTemp = ($api.getStorage('arrLedger')||{});
            // var arrLedgerEmp = ($api.getStorage('arrLedgerEmp')||{});
            // for(var i = 0; i < arrTemp.length; i++){
            //     arrTemp[i].LedgerEmp = [];
            //     for(var j = 0; j < arrLedgerEmp.length; j++){
            //         if(arrTemp[i].Id == arrLedgerEmp[j].L_Id){
            //             arrTemp[i].LedgerEmp.push(arrLedgerEmp[j]);
            //         }
            //     }
            // }
    
            // Lib.Store.Ledger.arrData = arrTemp;
            // for(var i = 0; i < Lib.Store.Ledger.arrData.length; i++){
            //     Lib.Store.Ledger.objMapping[Lib.Store.Ledger.arrData[i].Id] = Lib.Store.Ledger.arrData[i];
            // }
        },
        insert: function(strKey, objData){
            Lib.Store[strKey].arrData.push(objData);
            $api.setStorage('arr' + strKey, Lib.Store[strKey].arrData);
        },
        update: function(strKey, objData){
            for(var i = 0; i < Lib.Store[strKey].arrData.length; i++){
                if(Lib.Store[strKey].arrData[i].Id == objData.Id){                    
                    Lib.Store[strKey].arrData.splice(i,1,objData);
                    break;
                }
            }
            $api.setStorage('arr' + strKey, Lib.Store[strKey].arrData);
        },
        delete: function(strKey, nId){
            for(var i = 0; i < Lib.Store[strKey].arrData.length; i++){
                if(Lib.Store[strKey].arrData[i].Id == nId){
                    Lib.Store[strKey].arrData.splice(i,1);
                    break;
                }
            }
            $api.setStorage('arr' + strKey, Lib.Store[strKey].arrData);        
        },

        getValFromDic: function(strDicKey, strValue, strField="Name"){            
            var objTemp = Lib.Common.getObjByField(Lib.Store.Dictionary.objMapKey[strDicKey], "Value", strValue);
            return (objTemp == null ? strValue : objTemp[strField]);
        }
    },


    //================================该端专有方法=========================================//
    
    openWin:function (strUrl,objPageParam,blnIsReload) {
        //var strName = strUrl.replace(/\S+\//g, '').replace(/(\.html)/g, '');
        //var strName = strUrl.substr((strUrl.indexOf("/")>-1?strUrl.indexOf("/"):0)).replace("/html","");
        var strName = strUrl.substr((strUrl.lastIndexOf("./")>-1?strUrl.lastIndexOf("./")+1:0)).replace("/html","");
        if(strName.indexOf("?")>-1){
            strName = strName.substring(0,strName.indexOf("?"));
        }
        console.log(strName);
        api.openWin({
            name: strName,
            url: strUrl,
            reload: blnIsReload || false,
            //delay: (api.systemType != 'ios'?300:0),
            //slidBackEnabled:true,
            vScrollBarEnabled:true,
            pageParam: objPageParam || {}
            //animation:{type:"none"}
        });
    },
    openFrame:function (strUrl, nY, objPageParam, blnIsReload) {
    //   var nY = 0;
    //   for (var i = 0; i < arrIds.length; i++) {
    //     nY += $api.offset($api.byId(arrIds[i])).h
    //   }
        //var strName = strUrl.replace(/\S*\//g, '').replace(/(\.html)/g, '');
        var strName = strUrl.substr((strUrl.lastIndexOf("./")>-1?strUrl.lastIndexOf("./")+1:0)).replace("/html","");
        if(strName.indexOf("?")>-1){
            strName = strName.substring(0,strName.indexOf("?"));
        }
        console.log(strName);
        api.openFrame({
            name: strName,
            url: strUrl,
            reload: blnIsReload || false,
            bounces: false,  // 为false时则不能向下拖动
            rect: {
                // marginLeft:0,
                // marginTop: nY || 0,
                // marginBottom: 50,
                // marginRight:0
                x: 0,
                y: nY || 0,
                w: 'auto',
                h: 'auto'
            },
            pageParam: objPageParam || {}
        });
    },
    closeWin:function(strName){    
        console.log(strName);
        if(strName){
            console.log('a111');
            api.closeWin({name:strName,animation:{type:"none"}});
        }
        else{
            api.closeWin();
        }
    },
    batCloseWin:function(nDelay){
        nDelay = nDelay||400;
        setTimeout(function(){
            var arrName = $api.getStorage('arrCloseWinName')||[];
            for (var i = 0; i < arrName.length; i++) {                
                api.closeWin({name:arrName[i],animation:{type:"none"}});
            }
            $api.setStorage('arrCloseWinName',[]);
        },nDelay);
    },
    closeFrame:function(){
        api.closeFrame();
    },
},
Vue:{
    init: function(){

    },
    Store:{
        getValFromDic: function(strDicKey, strValue, strField="Name"){
            var objTemp = Lib.Common.getObjByField(Lib.Global.vueRoot.prototype.$store.state.Dictionary.objMapKey[strDicKey], "Value", strValue);
            return (objTemp == null ? strValue : objTemp[strField]);
        }        
    },    
},
Braba:{
    init: function(){

    },
    Store:{
        
    }
}
};

Lib.Sys = { // 对应当前系统通用方法
    // initVue: function(){
    //     Vue.prototype.$lib = Lib;
    //     Vue.prototype.$ajax = Lib.Ajax;
    //     Vue.prototype.$ajax.init();        
    //     if(typeof(currency)!='undefined'){
    //         Vue.prototype.$cur = currency;
    //     }
    //     if(typeof(MeScroll)!='undefined'){
    //         Vue.prototype.$MeScroll = MeScroll;
    //     }
    //     if(typeof(MeScroll)!='undefined'){
    //         Vue.prototype.$MeScroll = MeScroll;
    //     }
    //     if(typeof(dayjs)!='undefined'){
    //         Vue.prototype.$dayjs = dayjs;
    //     }

    //     if (Lib.Sys.checkLogin(0) == true) {    // 初始化登录状态
    //         Lib.Global.jobjUser = JSON.parse(localStorage.getItem("jobjUser"));
    //     }
    //     else {
    //         Lib.Global.jobjUser = null;
    //     }




    //     // if(typeof(VeeValidate)=='undefined'){
    //     //     return;
    //     // }
    //     // Vue.use(VeeValidate, {fieldsBagName:"fieldBags", locale: 'zh_CN', dictionary:{
    //     //     zh_CN: {
    //     //         messages: {
    //     //             required: function (n) { return "请输入" + n; }
    //     //         }
    //     //     }
    //     // }
    //     // });
    //     // VeeValidate.Validator.extend('mobile', {
    //     //     getMessage(field, args) {
    //     //         return Lib.Valid.Regular.strMobileMsg;
    //     //     },
    //     //     validate(value, args) {
    //     //         return Lib.Valid.Regular.regMobile.test(value);
    //     //     }
    //     // });
    // },
    initPage: function () {
        
    },
    hasPower: function(nPM_Id,nOperate){           
        if(Lib.Global.vueRoot.prototype.$store.state.jobjUser.OperatePower==1){
            return true;
        }
        
        var arrData = Lib.Global.vueRoot.prototype.$store.state.TabMenu.arrData;
        for(var i = 0; i < arrData.length; i++){
            if(arrData[i].ParentId == nPM_Id && arrData[i].Operate == nOperate){
                return arrData[i].HasPower;
            }
        }
        return false; 
    },

    // initLogin: function () {        
    //     if (Lib.Sys.checkLogin(0) == true) {    // 初始化登录状态
    //         Lib.Global.jobjUser = JSON.parse(localStorage.getItem("jobjUser"));            

    //         $(".noLogin").hide();
    //         $(".hasLogin").show();
    //         $(".loginName").text(Lib.Global.jobjUser.Name);
    //     }
    //     else {
    //         Lib.Global.jobjUser = null;
    //     }
    // },
    // logout: function () {
    //     localStorage.removeItem("strToken");
    //     localStorage.removeItem("jobjUser");
    //     Lib.Global.jobjUser = null;
    //     barba.go("/");

    //     $(".hasLogin").hide();
    //     $(".noLogin").show();        
    //     $(".loginName").text("");
    // },

    checkLogin: function (nType) {  // nType:0 返回结果 1:跳转到登录
        var blnIsLogin = false;

        if (localStorage.getItem("jobjUser") != null) {
            var jobjUser = JSON.parse(localStorage.getItem("jobjUser"));
            if (new Date(jobjUser.Expire) < new Date()) { // 过期
                jobjUser = null;
                localStorage.removeItem("strToken");
                localStorage.removeItem("jobjUser");
            }
            else {
                blnIsLogin = true;                    
            }
        }

        if (nType == 1 && blnIsLogin == false) {
            // Lib.YonYou.openWin("./html/Account/Login.html")
            // var strReturn = window.location.href;
            // if (strReturn.indexOf("//") > -1) {
            //     strReturn = strReturn.substr(strReturn.indexOf("//") + 2);
            // }
            // if (strReturn.indexOf("/") > -1) {
            //     strReturn = strReturn.substr(strReturn.indexOf("/"));
            // }
            // else {
            //     strReturn = "/";
            // }

            // try {
            //     barba.go("/Account/Login?Return=" + strReturn);
            // }
            // catch {
            //     window.location.href = "/Account/Login?Return=" + strReturn;
            // }                        
        }
        return blnIsLogin;
    },

    SMS: function (vueThis, strField, strUrl) {
        this.blnDisabled = false;
        this.nHeart = 0;
        this.strText = "获取验证码";

        this.vueThis = vueThis;
        this.strField = strField;
        this.strUrl = strUrl;

        this.send = function (strMobile) {            
            this.vueThis.$validator.validate().then(valid => {
                if (valid == false) {
                    return;
                }

                this.blnDisabled = true;
                this.vueThis.$ajax.get(this.strUrl + '?Mobile=' + strMobile).then(objResult => {
                    if (objResult.success == false) {
                        this.blnDisabled = false;
                        this.vueThis.$dialog.alert({ title: '系统提示', message: objResult.message });
                        return;
                    }

                    this.nHeart = 5;
                    var nInterval = setInterval(() => {
                        //console.log(this.nHeart);
                        if (this.nHeart > 0) {
                            this.nHeart -= 1;
                        }
                        else {
                            this.blnDisabled = false;
                            clearInterval(nInterval);
                        }
                    }, 1000);                    
                });
            });
        }
    }   
};

Lib.Common = {
    toggleHeight: function (jqThis, strToggleHeight) {  // 点击切换高度显示; jqThis: 切换节点; strToggleHeight: 切换高度;
        if (jqThis.css("height") == "0px") {
            jqThis.css("height", strToggleHeight);
        }
        else {
            jqThis.css("height", "0px");
        }
    },
    toggleClass: function (jqThis, strInitClass, strToggleClass) {  // 点击切换类; jqThis: 切换节点; strInitClass: 初始类名; strToggleClass: 切换类名
        jqThis.toggleClass(strInitClass);
        jqThis.toggleClass(strToggleClass);
    },

    nTimeHeart: null,
    hoverToggle: function (strHoverClass, strToggleClass) { // hover切换显示内容; strHoverClass: hover节点类名; strToggleClass: 切换节点类名         
        $("." + strHoverClass).on("mouseover", function () {
            var jqChild = $(this).children("." + strToggleClass);
            clearTimeout(this.nTimeHeart);
            if (jqChild.is(":hidden") == false) {
                return;
            }
            $("." + strToggleClass).hide();
            jqChild.show();
            
            if (jqChild.attr("_height") != undefined) {
                anime({
                    targets: jqChild[0], duration: 300, easing: 'linear', opacity: [0, 1], height: [0, jqChild.attr("_height")]
                    //targets: jqChild[0], duration: 300, easing: 'linear', opacity: [0, 1], translateY: ['-20px', '0px']
                });
            }
            else {
                anime({
                    targets: jqChild[0], duration: 300, easing: 'linear', opacity: [0, 1]
                });
            }
        }).on("mouseout", function () {
            var jqChild = $(this).children("." + strToggleClass);
            this.nTimeHeart = setTimeout(function () {
                jqChild.hide();
                //anime({
                //    targets: jqChild[0], duration: 300, easing: 'linear', opacity: [1, 0], complete: function () {
                //        jqChild.hide();
                //    }
                //});
            }, 10);
        });
    },
    getDateDiff: function (dtmStart, dtmEnd, strDiffType) { // 日期相减
        strDiffType = strDiffType.toLowerCase();

        var dReturn = 0.0;
        switch (strDiffType) {
            //case "second":
            //    dReturn = this.$cur(dtmEnd.getTime() - dtmStart.getTime()).divide(1000).value;
            //    break;
            //case "minute":
            //    dReturn = this.$cur(dtmEnd.getTime() - dtmStart.getTime()).divide(1000 * 60).value;
            //    break;
            //case "hour":
            //    dReturn = this.$cur(dtmEnd.getTime() - dtmStart.getTime()).divide(1000 * 3600).value;
            //    break;
            //case "day":
            //    dReturn = this.$cur(dtmEnd.getTime() - dtmStart.getTime()).divide(1000 * 3600 * 24).value;
            //    break;
            case "second":
                dReturn = (dtmEnd.getTime() - dtmStart.getTime()) / 1000;
                break;
            case "minute":
                dReturn = (dtmEnd.getTime() - dtmStart.getTime()) / (1000 * 60);
                break;
            case "hour":
                dReturn = (dtmEnd.getTime() - dtmStart.getTime()) / (1000 * 3600);
                break;
            case "day":
                dReturn = (dtmEnd.getTime() - dtmStart.getTime()) / (1000 * 3600 * 24);
                break;
        }
        return dReturn;
    },
    


    isNullOrWhiteSpace:function(objValue){
        if(typeof (objValue) == "undefined" || objValue == null || objValue == "") {　　 　 　 　
            return true;
        }

        return false;
    },
    split: function (strValue, strSplitWord, blnToInt) {  // 分割字符串    strValue：字符串    strSplitWord：分割符  blnToInt:true值转换为int
        strSplitWord = Lib.Common.isNullOrWhiteSpace(strSplitWord) ? "," : strSplitWord;        
        if(Lib.Common.isNullOrWhiteSpace(strValue)) return "";
        
        strValue = "" + strValue;   // 数值转字符串
        
        var arrTemps = strValue.split(strSplitWord);        
        var arrValues = new Array();
        for (var i = 0; i < arrTemps.length; i++) {
            if (arrTemps[i] != "") {
                if (blnToInt == true) {
                    arrValues.push(parseInt(arrTemps[i]));
                }
                else {
                    arrValues.push(arrTemps[i]);
                }
            }
        }
        return arrValues;
    },
    getUrlParam: function (param) {     // 获得url参数
        //var reg = new RegExp("(^|&)" + param.toLowerCase() + "=([^&]*)(&|$)");
        //var r = decodeURI(window.location.search.toLowerCase()).substr(1).match(reg);
        var reg = new RegExp("(^|&)" + param + "=([^&]*)(&|$)");
        var r = decodeURI(window.location.search).substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        else {
            return null;
        }
    },
    // deleteSpaceArray: function (arrData, strArrayName) { // 删除对象中的空数组, arrData:对象数组  strArrayName:数组名称
    //     for (var i = 0; i < arrData.length; i++) {
    //         if (arrData[i][strArrayName].length == 0) {
    //             delete arrData[i][strArrayName];
    //         }
    //         else {
    //             this.deleteSpaceArray(arrData[i][strArrayName], strArrayName);
    //         }
    //     }
    // },

    copyDepth:function(arrData){    // 深拷贝
        return arrData.map((objItem)=>{
            return Object.assign({},objItem);
            // if(typeof objItem === 'object'){
            //     return Object.assign({},objItem);
            // }else{
            //     return objItem;
            // }
        });
    },
    copyShallow:function(arrData){  // 浅拷贝
        return JSON.parse(JSON.stringify(arrData));
    },
    


    getArrByField: function(arrData, strField, objValue){
        return arrData.filter(function(objItem){
            return objItem[strField]==objValue;
        });
    },
    getObjByField: function (arrData, strField, objValue) {        
        for (var i = 0; i < arrData.length; i++) {
            if (arrData[i][strField] == objValue) {
                return arrData[i];
            }
        }
        return null;
    },
    getValByField: function (arrData, strField, objValue, strFieldValue) {
        var objTemp = this.getObjByField(arrData, strField, objValue);
        if (objTemp == null) {
            return (objValue == -1 ? "" : objValue);
        }
        else {
            return objTemp[strFieldValue];
        }
    },

    getTreeData:function (arrSource) {        
        var arrTree = new Array();
        var arrData = JSON.parse(JSON.stringify(arrSource));

        /* 删除子数组，确保不存在 */
        for (var i = 0; i < arrData.length; i++) {
            delete arrData[i].Children;
        }
        
        var objMap = new Object();
        /* 将每个对象映射到map中 */
        for (var i = 0; i < arrData.length; i++) {
            if (arrData[i].blnNotMap != true) {
                objMap[arrData[i].Id] = arrData[i];
            }
        }
        
        var objParent;
        /* 组织层级结构 */
        for (var i = 0; i < arrData.length; i++) {
            objParent = objMap[arrData[i].ParentId];
            if (objParent) {
                if (!objParent.Children) {
                    objParent.Children = new Array();
                }
                objParent.Children.push(arrData[i]);
                //(objParent.arrChildren || (objParent.arrChildren = [])).push(arrData[i]);                
            }
            else {
                arrTree.push(arrData[i]);
            }
        }
        return arrTree;
    },
};

Lib.Format = {  // 格式化
    fmtTime: function (strValue) {
        if (typeof (strValue) == "undefined" || strValue == "" || strValue == null)
            return "";

        if (strValue.indexOf(".") > -1) {
            return strValue.substr(0, strValue.indexOf('.')).replace("T", " ");
        }
        else {
            return strValue.replace("T", " ");
        }            
    },    
    fmtDate: function (strValue) {        
        if (typeof (strValue) == "undefined" || strValue == "" || strValue == null)
            return "";
        
        return strValue.substr(0, strValue.lastIndexOf('T'));
    },
    fmtDateExt :function(dtmDate, strFormat)   { 
        var o = {   
            "M+" : dtmDate.getMonth()+1,                 //月份   
            "d+" : dtmDate.getDate(),                    //日   
            "h+" : dtmDate.getHours()%12 == 0 ? 12 : dtmDate.getHours()%12, //小时           
            "H+" : dtmDate.getHours(), //小时 
            "m+" : dtmDate.getMinutes(),                 //分   
            "s+" : dtmDate.getSeconds(),                 //秒   
            "q+" : Math.floor((dtmDate.getMonth()+3)/3), //季度   
            "S"  : dtmDate.getMilliseconds()             //毫秒   
        };   
        if(/(y+)/.test(strFormat)){
            strFormat=strFormat.replace(RegExp.$1, (dtmDate.getFullYear()+"").substr(4 - RegExp.$1.length));   
        }
            
        for(var k in o){
            if(new RegExp("("+ k +")").test(strFormat)){
                strFormat = strFormat.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
            }
        }             
        return strFormat;   
    },
    
    fmtImageName: function (strValue, strSplitWord) {        
        if (typeof (strValue) == "undefined" || strValue == "" || strValue == null)
            return "";
        
        var arrImages = Lib.Common.split(strValue, strSplitWord);        
        var strTemp;
        var strReturn = "";
        for (var i = 0; i < arrImages.length; i++) {
            strTemp = arrImages[i].substring(arrImages[i].lastIndexOf("/") + 1);
            strReturn += "<a href='" + Lib.Config.Url_ApiUpload + arrImages[i] + "' target='_blank'>" + strTemp + "</a> | ";
        }

        if (arrImages.length > 0) {
            strReturn = strReturn.substring(0, strReturn.length - 2);
        }
                
        return strReturn;
    },         
    fmtImage: function (strValue, strSplitWord, strStyle) {       
        if (typeof (strValue) == "undefined" || strValue == "" || strValue == null)
            return "";
        
        var arrImages = Lib.Common.split(strValue, strSplitWord);
        var strTemp;
        var strReturn = "";
        for (var i = 0; i < arrImages.length; i++) {
            strTemp = arrImages[i].substring(arrImages[i].lastIndexOf("/") + 1);
            strReturn += "<a href='" + Lib.Config.Url_ApiUpload + arrImages[i] + "' target='_blank'><img src='" + Lib.Config.Url_ApiUpload + arrImages[i] + "' style='" + strStyle + "' /></a> ";
        }
        return strReturn;
    },
    fmtFileName: function (strValue, strSplitWord) {    
        if (typeof (strValue) == "undefined" || strValue == "" || strValue == null)
            return "";

        var arrImages = Lib.Common.split(strValue, strSplitWord);
        var strTemp;
        var strReturn = "";
        for (var i = 0; i < arrImages.length; i++) {
            strTemp = arrImages[i].substring(arrImages[i].lastIndexOf("/") + 1);
            strReturn += "<a href='" + Lib.Config.Url_ApiUpload + arrImages[i] + "' target='_blank'>" + strTemp + "</a> | ";
        }

        if (arrImages.length > 0) {
            strReturn = strReturn.substring(0, strReturn.length - 2);
        }
        return strReturn;
    }
};

Lib.Element = { // ElementUI, Vue
    CURD: {
        delete: function (vueMain, strUrl, fnCallback) {
            vueMain.$confirm("您好，请问确认删除该数据吗？", '系统提示', { type: 'warning' }).then(function () {
                vueMain.$ajax.post(strUrl).then(function (objResult) {
                    if (objResult.success == false) {
                        vueMain.$alert(objResult.message, '错误提示', { type: 'error' });
                        return;
                    }

                    var objTime = setTimeout(function () {
                        document.getElementsByClassName("myAlert")[0].getElementsByClassName("el-button")[0].click();
                    }, 1500);

                    vueMain.$alert('您好，数据已成功删除。', '系统提示', {
                        type: 'success', customClass: 'myAlert', callback: function () {
                            window.clearTimeout(objTime);

                            if (typeof (fnCallback) == "function") {
                                fnCallback(objResult);
                            }
                            else {
                                vueMain.search(true);
                            }
                        }
                    });
                });
            }).catch(function () {
            });
        },
        insert: function (vueMain, strUrl, fnCallback, blnConfirm = false) {
            if (vueMain.ctrForm.blnSubmit == false)
                vueMain.ctrForm.blnSubmit = true;

            vueMain.$refs.form.validate().then(blnValid => {
            // vueMain.$validator.validateAll().then((blnValid) => {
                if (blnValid == false) {
                    vueMain.ctrForm.blnSubmit = false;
                    return;
                }

                if (blnConfirm == true) {
                    vueMain.$confirm("您好，请问提交该数据吗？", '系统提示', { type: 'warning' }).then(function () {
                        vueMain.$ajax.post(strUrl, vueMain.objData).then(function (objResult) {
                            if (objResult.success == false) {
                                vueMain.$alert(objResult.message, '错误提示', { type: 'error' });
                                vueMain.ctrForm.blnSubmit = false;
                                return;
                            }

                            var objTime = setTimeout(function () {
                                document.getElementsByClassName("myAlert")[0].getElementsByClassName("el-button")[0].click();
                            }, 1500);

                            vueMain.$alert('您好，数据已保存成功。', '系统提示', {
                                type: 'success', customClass: 'myAlert', callback: function () {
                                    window.clearTimeout(objTime);                                    
                                    if (typeof (fnCallback) == "function") {
                                        fnCallback(objResult);
                                    }
                                    else {
                                        
                                        vueMain.$parent.search();
                                        vueMain.$layer.close(vueMain.layerid);
                                    }
                                }
                            });
                        });
                    }, function () {
                        vueMain.ctrForm.blnSubmit = false;
                    }).catch(function () {
                    });
                }
                else {
                    vueMain.$ajax.post(strUrl, vueMain.objData).then(function (objResult) {
                        if (objResult.success == false) {
                            vueMain.$alert(objResult.message, '错误提示', { type: 'error' });
                            vueMain.ctrForm.blnSubmit = false;
                            return;
                        }

                        var objTime = setTimeout(function () {
                            document.getElementsByClassName("myAlert")[0].getElementsByClassName("el-button")[0].click();
                        }, 1500);

                        vueMain.$alert('您好，数据已保存成功。', '系统提示', {
                            type: 'success', customClass: 'myAlert', callback: function () {
                                window.clearTimeout(objTime);

                                if (typeof (fnCallback) == "function") {
                                    fnCallback(objResult);
                                }
                                else {
                                    vueMain.$parent.search();
                                    vueMain.$layer.close(vueMain.layerid);
                                }
                            }
                        });
                    });
                }
            });
        },
        update: function (vueMain, strUrl, fnCallback, blnConfirm = false) {
            if (vueMain.ctrForm.blnSubmit == false)
                vueMain.ctrForm.blnSubmit = true;

            vueMain.$refs.form.validate().then(blnValid => {
            // vueMain.$validator.validateAll().then((blnValid) => {
                if (blnValid == false) {
                    vueMain.ctrForm.blnSubmit = false;
                    return;
                }
                
                if (blnConfirm == true) {                    
                    vueMain.$confirm("您好，确定更新该该数据吗？", '系统提示', { type: 'warning' }).then(function () {                        
                        vueMain.$ajax.post(strUrl, vueMain.objData).then(function (objResult) {                            
                            if (objResult.success == false) {
                                vueMain.$alert(objResult.message, '错误提示', { type: 'error' });
                                vueMain.ctrForm.blnSubmit = false;
                                return;
                            }

                            var objTime = setTimeout(function () {
                                document.getElementsByClassName("myAlert")[0].getElementsByClassName("el-button")[0].click();
                            }, 1500);

                            vueMain.$alert('您好，数据已保存成功。', '系统提示', {
                                type: 'success', customClass: 'myAlert', callback: function () {
                                    window.clearTimeout(objTime);

                                    if (typeof (fnCallback) == "function") {
                                        fnCallback(objResult);
                                    }
                                    else {
                                        vueMain.$parent.search(true);
                                        vueMain.$layer.close(vueMain.layerid);
                                    }
                                }
                            });
                        });
                    }, function () {
                        vueMain.ctrForm.blnSubmit = false;
                    }).catch(function () {
                    });
                }
                else {
                    vueMain.$ajax.post(strUrl, vueMain.objData).then(function (objResult) {
                        if (objResult.success == false) {
                            vueMain.$alert(objResult.message, '错误提示', { type: 'error' });
                            vueMain.ctrForm.blnSubmit = false;
                            return;
                        }

                        var objTime = setTimeout(function () {
                            document.getElementsByClassName("myAlert")[0].getElementsByClassName("el-button")[0].click();
                        }, 1500);

                        vueMain.$alert('您好，数据已保存成功。', '系统提示', {
                            type: 'success', customClass: 'myAlert', callback: function () {
                                window.clearTimeout(objTime);

                                if (typeof (fnCallback) == "function") {
                                    fnCallback(objResult);
                                }
                                else {
                                    vueMain.$parent.search(true);
                                    vueMain.$layer.close(vueMain.layerid);
                                }
                            }
                        });
                    });
                }
            });
        }
    },

    Upload: {
        strAcceptImage: "image/jpeg,image/gif,image/png,image/bmp",
        strAcceptFile: "txt,pdf,doc,docx,ppt,pptx,xls,xlsx,jpeg,gif,png,bmp,rar",

        beforeUpload: function (docFile, nMaxMB, vueMain) {
            var blnIsLess = docFile.size / 1024 / 1024 < nMaxMB;
            if (!blnIsLess) {
                vueMain.$message.error('上传图片大小不能超过' + nMaxMB + 'MB!');
            }
            return blnIsLess;
        },


        success: function (objResult, docFile, arrFileList, vueMain) {
            vueMain.$refs[objResult.extData.strRef].fileList.push({ name: objResult.extData.strSaveName + objResult.extData.strFileType, url: Lib.Config.Url_ApiUpload + objResult.data, ref: objResult.extData.strRef });
        },
        preview: function (docFile, vueMain) {
            vueMain.ctrUpload.blnDialogVisible = true;
            vueMain.ctrUpload.strDialogImageUrl = docFile.url;
        },
        previewFile: function (docFile) {
            window.open(docFile.url);            
        },
        remove: function (docFile, arrFileList, vueMain) {
            for (var i = 0; i < vueMain.$refs[docFile.ref].fileList.length; i++) {
                if (docFile.uid == vueMain.$refs[docFile.ref].fileList[i].uid) {
                    vueMain.$refs[docFile.ref].fileList.splice(i, 1);
                    break;
                }
            }
        },
        loadMuit: function (strKey, strData, vueMain) {   // 多个文件时数据加载
            var arrTemp = vueMain.$lib.Common.split(strData);
            for (var i = 0; i < arrTemp.length; i++) {
                vueMain.ctrUpload["arr" + strKey].push({ name: arrTemp[i].substr(arrTemp[i].lastIndexOf("/") + 1), url: Lib.Config.Url_ApiUpload + arrTemp[i], ref: "ctr" + strKey });
            }
        },
        getUrl: function (arrFileList, strSplitWord) {
            var strReturn = "";
            strSplitWord = (strSplitWord == null ? "," : strSplitWord);
            for (var i = 0; i < arrFileList.length; i++) {
                strReturn += arrFileList[i].url.replace(Lib.Config.Url_ApiUpload, "") + strSplitWord;
            }
            return (strReturn.length > 0 ? strReturn.substr(0, strReturn.length - 1) : strReturn);
        }        
    },
    Table: {
        formatter: function (objRow, objColumn, objCellValue, nIndex) {            
            return Lib.Store.getValFromDic(objColumn["columnKey"], objCellValue);
        },
        fmtPct: function (row, column, cellValue, index) {
            return cellValue == null ? "" : (cellValue.toFixed(1) + "%");
        },
        fmtPct2: function (row, column, cellValue, index) {
            return cellValue == null ? "" : (cellValue.toFixed(2) + "%");
        },
        fmtFixed2: function (row, column, cellValue, index) {
            return cellValue == null ? "" : cellValue.toFixed(2);
        },                
        fmtTime: function (row, column, cellValue, index) {
            return Lib.Format.fmtTime(cellValue);
        },
        fmtTimeSimple: function (row, column, cellValue, index) {
            var strTemp = Lib.Format.fmtTime(cellValue);
            return strTemp.substr(0, strTemp.lastIndexOf(':'));
        },        
        fmtDate: function (row, column, cellValue, index) {
            return Lib.Format.fmtDate(cellValue);
        },

        sortChange: function (objSort, vueMain) {
            if (objSort.order != null) {
                vueMain.ctrTable.objParam.OrderBy = (typeof (vueMain.ctrTable.strPrefix) != "undefined" ? vueMain.ctrTable.strPrefix : "") + objSort.prop + (objSort.order == "ascending" ? " asc" : " desc");
            }
            else {
                vueMain.ctrTable.objParam.OrderBy = vueMain.ctrTable.OrderByOld;
            }
            vueMain.search();
        },
        currentChange: function (currentRow, oldCurrentRow, vueMain) {   // 表格当前项改变  
            vueMain.ctrTable.objCurrentRow = currentRow;
        },
        selectionChange: function (selection, vueMain) {                 // 表格复选框进行多选
            vueMain.ctrTable.arrMultipleSelection = selection;
        },

        filter: function (value, row, column) { // 列过滤,本地数据过滤方式            
            return row[column["property"]] == value;
        },
        filterChange: function (objFilters, vueMain) {    // 列过滤,ajax数据过滤方式            
            for (var strKey in objFilters) {
                if (typeof (vueMain.ctrTable.objParam.Where[strKey]) == 'undefined') {
                    vueMain.ctrTable.objParam.Where[strKey.substr(strKey.lastIndexOf("_") + 1)].arrValue = objFilters[strKey];
                }
                else {
                    vueMain.ctrTable.objParam.Where[strKey].arrValue = objFilters[strKey];
                }                
            }
        },
        getFilters: function (strCallKey) {     // 列过滤值数组
            var arrResult = new Array();
            
            for (var i = 0; i < Lib.Global.vueRoot.prototype.$store.state.Dictionary.objMapKey[strCallKey].length; i++) {
                arrResult.push({ "text": Lib.Global.vueRoot.prototype.$store.state.Dictionary.objMapKey[strCallKey][i]["Name"], value: Lib.Global.vueRoot.prototype.$store.state.Dictionary.objMapKey[strCallKey][i]["Value"] });
            }
            return arrResult;
        },

        fmtPowerModuleName: function (objRow, objColumn, objCellValue, nIndex) {
            return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.TabMenu.objMapping, objCellValue);        
        },
        fmtEmployeeName: function (objRow, objColumn, objCellValue, nIndex) {
           return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.Employee.objMapping, objCellValue);
        },
        fmtCompanyCustomerName: function (objRow, objColumn, objCellValue, nIndex) {
            return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.CompanyCustomer.objMapping, objCellValue);
        },
        fmtAirLineName: function (objRow, objColumn, objCellValue, nIndex) {
            return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.AirLine.objMapping, objCellValue);
        },  
        fmtFlightName: function (objRow, objColumn, objCellValue, nIndex) {
            return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.Flight.objMapping, objCellValue, "Date") + '_' + Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.Flight.objMapping, objCellValue, "Number");
        },
        fmtBasePackageName: function (objRow, objColumn, objCellValue, nIndex) {
            return Lib.Store.getValById(Lib.Global.vueRoot.prototype.$store.state.BasePackage.objMapping, objCellValue);
        },          
    },
    Page: {
        sizeChange: function (nValue, vueMain) { // 页码改变
            vueMain.ctrTable.objParam.Size = nValue;
            vueMain.search();
        },
        currentChange: function (nValue, vueMain) {  // 当前页改变            
            vueMain.ctrTable.objParam.Page = nValue;
            vueMain.search(true);
        }
    },
    Tree: {
        filterNode: function (strValue, objData) {  // 树过滤
            if (!strValue) return true;
            return objData.Name.indexOf(strValue) !== -1;
        }
    },
    Cascader: {
        getArrayValue: function (arrData, ParentId) {
            if (ParentId == null) return new Array();

            var arrTemp = new Array();
            var blnTemp = false;
            while (ParentId > -1 && ParentId != null) {
                arrTemp.push(ParentId);
                blnTemp = false;
                for (var j = 0; j < arrData.length; j++) {
                    if (arrData[j].Id == ParentId) {
                        ParentId = arrData[j].ParentId;
                        blnTemp = true;
                        break;
                    }
                }
                if (blnTemp == false)
                    break;
            }
            return arrTemp.reverse();
        }
    }
};

Lib.Vant = {    // 有赞UI, Vue
    CURD:{
        delete: function (vueMain, strUrl, fnCallback, objOptions) {    // objOptions:{strListName:"", nId: null}
            vueMain.$dialog.confirm({ title:"系统提示", message: "确定删除该数据吗？" }).then(()=> {
                vueMain.$ajax.post(strUrl).then(objResult=> {                      
                    if(objResult.success == false){                        
                        vueMain.$dialog.alert({ title: '系统提示', message: objResult.message });                            
                        return;
                    }

                    vueMain.$toast("删除成功");
                    if (typeof (fnCallback) == "function") {
                        fnCallback(objResult);
                    }
                    else {
                        for(var i = 0; i < vueMain[objOptions.strListName].arrData.length; i++){
                            if(vueMain[objOptions.strListName].arrData[i].Id == objOptions.nId){
                                vueMain[objOptions.strListName].arrData.splice(i,1);
                                break;
                            }
                        }
                    }
                });
            });
        },
        insert: function (vueMain, strUrl, fnCallback, blnConfirm = false, objOptions) {    // objOptions:{strWinName:"",strScript:""}
            if(vueMain.ctrForm.blnSubmit == true){
                return;
            }
            vueMain.ctrForm.blnSubmit = true;

            vueMain.$refs.form.validate().then(blnValid => {
                if(blnValid==false){
                    vueMain.ctrForm.blnSubmit = false;
                    return;
                }

                if(blnConfirm == true){
                    vueMain.$dialog.confirm({ title:"系统提示", message: "确定提交保存该数据吗？" }).then(()=> {
                        vueMain.$ajax.post(strUrl, vueMain.objData).then(objResult=> {                                
                            vueMain.ctrForm.blnSubmit = false;
                            if(objResult.success == false){
                                vueMain.$dialog.alert({ title: '系统提示', message: objResult.message });                            
                                return;
                            }
                            
                            vueMain.$dialog.alert({ title: '系统提示', message: objResult.message }).then(() => { 
                                if (typeof (fnCallback) == "function") {
                                    fnCallback(objResult);
                                }
                                else {
                                    api.execScript({ name: objOptions.strWinName, script: objOptions.strScript});
                                    api.closeWin();
                                }                            
                            });
                        });
                    }).catch(() => {
                        vueMain.ctrForm.blnSubmit = false;
                    });
                }
                else{
                    vueMain.$ajax.post(strUrl, vueMain.objData).then(objResult=> {                                
                        vueMain.ctrForm.blnSubmit = false;
                        if(objResult.success == false){
                            vueMain.$dialog.alert({ title: '系统提示', message: objResult.message });                            
                            return;
                        }
                        
                        vueMain.$dialog.alert({ title: '系统提示', message: objResult.message }).then(() => { 
                            if (typeof (fnCallback) == "function") {
                                fnCallback(objResult);
                            }
                            else {
                                api.execScript({ name: objOptions.strWinName, script: objOptions.strScript});
                                api.closeWin();
                            }                            
                        });
                    });
                }                
            });            
        },
        update: function (vueMain, strUrl, fnCallback, blnConfirm = false, objOptions) {    // objOptions:{strWinName:"",strScript:""}            
            if(vueMain.ctrForm.blnSubmit == true){
                return;
            }            
            vueMain.ctrForm.blnSubmit = true;

            vueMain.$refs.form.validate().then(blnValid => {                
                if(blnValid==false){
                    vueMain.ctrForm.blnSubmit = false;
                    return;
                }

                if(blnConfirm == true){                    
                    vueMain.$dialog.confirm({ title:"系统提示", message: "确定提交更新该数据吗？" }).then(()=> {                        
                        vueMain.$ajax.post(strUrl, vueMain.objData).then(objResult=> {                                                            
                            vueMain.ctrForm.blnSubmit = false;
                            if(objResult.success == false){
                                vueMain.$dialog.alert({ title: '系统提示', message: objResult.message });                            
                                return;
                            }
                            
                            vueMain.$dialog.alert({ title: '系统提示', message: objResult.message }).then(() => { 
                                if (typeof (fnCallback) == "function") {
                                    fnCallback(objResult);
                                }
                                else {
                                    api.execScript({ name: objOptions.strWinName, script: objOptions.strScript});
                                    api.closeWin();
                                }                            
                            });
                        });
                    }).catch(() => {
                        vueMain.ctrForm.blnSubmit = false;
                    });
                }
                else{
                    vueMain.$ajax.post(strUrl, vueMain.objData).then(objResult=> {                                
                        vueMain.ctrForm.blnSubmit = false;
                        if(objResult.success == false){
                            vueMain.$dialog.alert({ title: '系统提示', message: objResult.message });                            
                            return;
                        }
                        
                        vueMain.$dialog.alert({ title: '系统提示', message: objResult.message }).then(() => { 
                            if (typeof (fnCallback) == "function") {
                                fnCallback(objResult);
                            }
                            else {
                                api.execScript({ name: objOptions.strWinName, script: objOptions.strScript});
                                api.closeWin();
                            }                            
                        });
                    });
                }                
            });            
        }
    }
};

Lib.Plugin = {  // 其他小插件
    Cursor: {
        init: function () {
            var cursor = $(".hc_cursor");
            var cWidth = 16;
            var mouseX = 0;
            var mouseY = 0;
            cursor.removeClass("on-link").removeClass('on-click').removeClass('on-link-out');

            $(document).on('mousemove', function (e) {
                mouseX = e.clientX;
                mouseY = e.clientY;
                cursor.css({
                    left: mouseX - (cWidth / 2),
                    top: mouseY - (cWidth / 2)
                })
            });

            // iframe上的时候,用于内部a链接,用于span按钮,用于自定义元素
            //$("iframe,a,span.hc_button,.cur-link").on({
            $("iframe,a,.hc_button,.cur-link").on({
                "mouseenter": function () {                    
                    cursor.addClass('on-link');
                },
                "mouseleave": function () {
                    cursor.removeClass('on-link');
                }
            });

            // 用于点击操作功能
            $(".hc_button,.cur-click").on({
                "mouseenter": function () {
                    cursor.addClass('on-click');
                },
                "mouseleave": function () {
                    cursor.removeClass('on-click');
                }
            });

            // 用于外部链接
            $(".cur-link-out").on({
                "mouseenter": function () {
                    cursor.addClass('on-link-out');
                },
                "mouseleave": function () {
                    cursor.removeClass('on-link-out');
                }
            });

            var agent = window.navigator.userAgent.toLowerCase();
            // 代理判定：ipad时不显示指针
            if ((agent.indexOf('ipad') > -1 || agent.indexOf('macintosh') > -1 && 'ontouchend' in document)) {
                cursor.hide();
            }
        }
    },
    UEditor:{
        arrMini: ['source', 'bold', 'italic', 'underline', 'fontborder', 'backcolor', 'fontsize', 'fontfamily',
    'justifyleft', 'justifyright', 'justifycenter', 'justifyjustify', 'strikethrough', 'superscript', 'subscript', 'removeformat', '|',
    'forecolor', 'backcolor', 'simpleupload', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', 'link', 'unlink', 'fontsize', 'fontfamily', 'justifyleft', 'justifyright', 'justifycenter', 'justifyjustify', 'strikethrough', 'simpleupload', 'superscript', 'subscript', 'removeformat', '|', 'insertorderedlist', 'insertunorderedlist', 'inserttable', 'deletetable', 'selectall', 'cleardoc'],               
        arrSimple: ['source', 'bold', 'italic', 'underline', 'fontborder', 'forecolor', 'backcolor', 'link', 'unlink', 'fontsize', 'fontfamily', 'justifyleft', 'justifyright', 'justifycenter', 'justifyjustify', 'strikethrough', 'simpleupload', 'superscript', 'subscript', 'removeformat', '|', 'insertorderedlist', 'insertunorderedlist', 'inserttable', 'deletetable', 'selectall', 'cleardoc'],               
        objConfig:{
            // autoHeightEnabled: false,   // 编辑器不自动被内容撑高,默认true
            // autoFloatEnabled: false,    // 是否保持toolbar的位置不动,默认true
            // initialStyle: 'p{line-height:1.5em;font-family:微软雅黑;font-size:14px;}',  // 如果自定义，最好给p标签如下的行高，要不输入中文时，会有跳动感        
            // initialFrameHeight: 240,    // 初始容器高度        
            // initialFrameWidth: '95%',   // 初始容器宽度

            // toolbars: [['source', 'bold', 'italic', 'underline', 'fontborder', 'backcolor', 'fontsize', 'fontfamily',
            // 'justifyleft', 'justifyright', 'justifycenter', 'justifyjustify', 'strikethrough', 'superscript', 'subscript', 'removeformat', '|',
            // 'forecolor', 'backcolor', 'simpleupload', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', 'link', 'unlink', 'emotion']],
            // lang: "en",
            enableAutoSave: false,  
            // serverUrl: Config.Url_ApiUpload + '/net/controller.ashx',   // 上传文件接口        
            serverUrl: Lib.Config.Url_ApiUpload + '/Open/FileUpload/Upload?Directory=UEditor&NameMode=Random&Compress=false',   // 上传文件接口 
            // serverUrl: '',   // 上传文件接口 
            UEDITOR_HOME_URL: '/static/script/plugin/vue-ueditor-wrap/public/UEditor/'    // UEditor 资源文件的存放路径
        }
    },
    MeScroll:{
        // objOptions={strUrl:"必填",nDelay:0,nSize,blnLoad}
        init:function(strId,vueMain,objOptions,fnSearch){
            objOptions.nDelay = objOptions.nDelay||400;
            objOptions.nSize = objOptions.nSize||10;
            objOptions.blnLoad = typeof(objOptions.blnLoad)=="undefined"?true:objOptions.blnLoad;
            objOptions.blnDownIsLock = typeof(objOptions.blnDownIsLock)=="undefined"?false:objOptions.blnDownIsLock;
            // fnSearch();
            // if (typeof (fnCallback) == "function") {
            //     fnCallback(objResult);
            // }

            vueMain[strId].objMeScroll = new vueMain.$MeScroll(strId, {// 在mounted生命周期初始化mescroll,以确保您配置的dom元素能够被找到.
                down: {
                    isLock: objOptions.blnDownIsLock
                    // auto: false, // 是否在初始化完毕之后自动执行下拉回调callback; 默认true
                    // callback: this.downCallback // 下拉刷新的回调
                },
                strId: strId,    // 自定义扩充参数,对象名称
                vueApp: vueMain,
                strUrl: objOptions.strUrl,    // 自定义扩充参数,请求地址
                up: {
                    auto: objOptions.blnLoad, // 是否在初始化时以上拉加载的方式自动加载第一页数据; 默认false
                    // callback: Lib.Plugin.MeScroll.search, // 上拉回调,此处可简写; 相当于 callback: function (page) { upCallback(page); }
                    callback: (typeof (fnSearch) == "function" ? fnSearch : Lib.Plugin.MeScroll.search),
                    page: {
                        num: 0, // 当前页码,默认0,回调之前会加1,即callback(page)会从1开始
                        size: objOptions.nSize // 每页数据的数量
                    },
                    htmlNodata:'<p class="upwarp-nodata">-- 数据已全部显示完 --</p>',
                    noMoreSize: 0, // 如果列表已无数据,可设置列表的总数量要大于等于5条才显示无更多数据;避免列表数据过少(比如只有一条数据),显示无更多数据会不好看
                    // toTop: { // 配置回到顶部按钮
                    //     //offset: -1,
                    //     src: '/static/images/totop.png'
                    // }
                }
            });

        },
        search:function (objPage, objMeScroll) {    // 上拉加载的回调; 回调 ( page对象, mescroll实例 ), page = {num:1, size:10}; num:当前页 ,默认从1开始; size:每页数据条数,默认10
            var strId = objMeScroll.options.strId;
            var vueMain = objMeScroll.options.vueApp;
            vueMain[strId].objParam.Page = objPage.num;
            vueMain[strId].objParam.Size = objPage.size;
            //console.log(JSON.stringify(vueApp[strId].objParam));
            
            vueMain.$ajax.get(objMeScroll.options.strUrl, vueMain[strId].objParam).then(objResult => {
                // console.log(objResult.data.length);
                if(objResult.success == false){
                    objMeScroll.endErr();    // 联网失败的回调,隐藏下拉刷新的状态 
                    return;
                }
                // console.log(JSON.stringify(objResult.data));
                if(objPage.num == 1) {    // 下拉加载最新数据
                    vueMain[strId].arrData = objResult.data;
                    vueMain[strId].nTotal = objResult.nTotal;
                }
                else {    // 上拉加载第二页数据
                    vueMain[strId].arrData = vueMain[strId].arrData.concat(objResult.data);
                }

                // vueApp.$nextTick(() => {    // 数据渲染成功后,隐藏下拉刷新的状态,根据总数来判断是否还有下一页
                vueMain.$nextTick(() => {    // 数据渲染成功后,隐藏下拉刷新的状态,根据总数来判断是否还有下一页
                    objMeScroll.endBySize(objResult.data.length,objResult.nTotal);
                });                
            });
        }  
    }
};

Lib.Valid = {   // 验证规则
    Regular: {
        regMobile: /^(((1[0-9][0-9]{1})|(1[0-9][0-9]{1}))+\d{8})$/,
        strMobileMsg: "请输入正确的手机号码",
        regZipCode: /^[0-9]{6}$/,
        strZipCodeMsg: "请输入正确的邮政编码",

        regDec2: /^-?\d+\.?\d{0,2}$/,
        strDec2: "请保留2位小数",

        // // 验证自然数
        // regNaturalNumber: /^(([0-9]*[1-9][0-9]*)|(0+))$/,
        // strNaturalNumberMsg: '请输入自然数。',
        // // 座机        
        // regPhone: /^(\d{3,4}-){0,1}\d{7,8}$/,
        // strPhoneMsg: '请输入正确的座机号。',
        regTelephone: /^(\d{3,4}-){0,1}\d{7,8}$|(((1[0-9][0-9]{1})|(1[0-9][0-9]{1}))+\d{8})$/,
        strTelephoneMsg: "请输入正确的电话号码",
        // // 身份证号码,包括15位和18位的
        // regIdCard: /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{7}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}$)/,
        // strIdCardMsg: '请输入正确的身份证号码。',
        // regEmail: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
        // strEmailMsg: "请输入正确的邮箱。",

        // // 英文
        // english: /^.[A-Za-z]+$/,
        // englishMsg: '请输入英文字符',

        // // 银行卡号码
        // bankCard: /^[1-9]\d{9,19}$/,
        // bankCardMsg: '请输入正确的银行卡号码',
        // // 证件号码
        // IDNumber: /^[a-z0-9A-Z]{0,50}$/,
        // IDNumberMsg: '请输入正确的证件号码',

        // // QQ号码
        // qq: /^[1-9]\d{4,11}$/,
        // qqMsg: '请输入正确的QQ号码',
        // // 网址, 仅支持http和https开头的
        // url: /^(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-.,@?^=%&:/~+#]*[\w\-@?^=%&/~+#])?$/,
        // urlMsg: '请输入以http和https开头的网址',
        // // 0到20位的英文字符和数字
        // enNum0to20: /^[a-z0-9A-Z]{0,20}$/,
        // enNum0to20Msg: '请输入20位以内的英文字符和数字',
        // // 2到100位的中英文字符和空格
        // cnEnSpace2to100: /^[a-zA-Z\u4E00-\u9FA5\s*]{2,100}$/,
        // cnEnSpace2to100Msg: '请输入2到100位的中英文字符和空格',
        // // 数字和换行符
        // numLinefeed: /^[0-9\n*]+$/,
        // numLinefeedMsg: '请输入数字和换行符',
        // // 255位以内的字符
        // char0to255: /^.{0,255}$/,
        // char0to255Msg: '请输入255位以内的字符'
    },
    Async: {    // async-validator插件https://github.com/yiminghe/async-validator
        validUnique: function (strUrl, strMsg) {
            return function (objRule, strValue, fnCallback) {
                if (strValue == "") {
                    fnCallback();
                }
                else {
                    AjaxJQuery.get(strUrl, { ValidValue: strValue }).done((objResult,strStatus,objXHR)=>{                                                                                
                        if (objResult == true) {                            
                            fnCallback();
                        }
                        else {
                            fnCallback(strMsg);
                        }
                    });
                }
            }
        }
    }
};

var AjaxJQuery = {
    baseURL: "",
    init: function () {        
        // alert(Lib.Config.Url_ApiRequest);
        this.baseURL = Lib.Config.Url_ApiRequest;
        $.ajaxSetup({
            type: "get",
            dataType: "json",
             //contentType:"application/json;charset=utf-8",
            contentType:"application/x-www-form-urlencoded;charset=utf-8",
            // headers : {"test": "abc"},   // IOS手机不能前端设置head，设置的话请求就发送不出去，IOS自身安全限制
            // timeout: 3000,   
            async: true,   // 默认为异步
            headers : {"token": localStorage.getItem("strToken") == null ? "" : localStorage.getItem("strToken")},
            beforeSend: function (jqXHR) {    // 可以设置headers                
                //jqXHR.setRequestHeader("token", localStorage.getItem("strToken") == null ? "" : localStorage.getItem("strToken"));
                // jqXHR.overrideMimeType( "text/plain; charset=x-user-defined" );
                return true;
            },
            cache: false,   // 默认为浏览器不缓存请求
            xhrFields: { withCredentials: false },   // 请求带cookie,true for cross-domain requests if needed.
            complete:function(jqXHR,textStatus){   // 拦截处理always响应                
                // console.log(jqXHR.responseText); // 通过XMLHttpRequest取得响应结果
                var objData = JSON.parse(jqXHR.responseText);
                if (objData.code == 403) {    // 返回-403表示访问的接口需要身份认证
                    localStorage.removeItem("strToken");
                    localStorage.removeItem("jobjUser");
                    var strReturn = window.location.href;
                    if (strReturn.indexOf("//") > -1) {
                        strReturn = strReturn.substr(strReturn.indexOf("//") + 2);
                    }
                    if (strReturn.indexOf("/") > -1) {
                        strReturn = strReturn.substr(strReturn.indexOf("/"));
                    }
                    else {
                        strReturn = "/";
                    }

                    try {
                        barba.go("/Account/Login?Return=" + strReturn);
                    }
                    catch {
                        window.location.href = "/Account/Login?Return=" + strReturn;
                    }                        
                }
            },
            error:function(jqXHR,textStatus,errorThrown){   // 拦截处理错误        
                alert("System error, please try again later. Error prompt:" + jqXHR.status + errorThrown);
                /* switch(jqXHR.status) {
                    case(500):alert("服务器系统内部错误");break;
                    case(401):alert("未登录");break;
                    case(403):alert("无权限执行此操作");break;
                    case(408):alert("请求超时");break;
                    default:alert("未知错误");
                }*/
            },
            statusCode: {
                // 404: function() {
                //     alert('There is no such service. 404');
                // },
                // 504: function() {
                //     alert('The server is not responding. 504');
                // },
                // 500: function() {
                //     alert('Server error. 500');
                // }
            }
        });
        // axios.defaults.baseURL = Config.Url_ApiRequest;
        // axios.defaults.headers.common['token'] = localStorage.getItem("strToken") == null ? "" : localStorage.getItem("strToken");  
    
        // axios.interceptors.request.use(function (config) {  // 在发送请求之前做些什么
        //     // if(config.params!=null){ // IOS手机不能前端设置head，设置的话请求就发送不出去，IOS自身安全限制
        //     //     config.params.token=localStorage.getItem("strToken");
        //     // }
        //     // else{
        //     //     config.params = {"token":localStorage.getItem("strToken")};
        //     // }
        //     return config;
        // }, function (error) {   // 对请求错误做些什么
        //     return Promise.reject(error);
        // });
        // axios.interceptors.response.use(function (response) { // Do something with response data    
        //     if (response.data.nCode == -403) {        
        //         localStorage.removeItem("strToken");
        //         localStorage.removeItem("jobjUser");
        //         window.location.href="/static/login.html?return=#/";   
        //     }
        //     return response;
        // }, function (error) {   // axios全局错误处理    
        //     alert("系统错误，请稍后再进行该操作或者联系管理员。错误提示：" + error);
        //     return Promise.reject(error);
        // });
    },    
    get: function (strUrl, objParams, objOptions){   // async: false             
        var strUrl = (strUrl.indexOf("http")>-1?strUrl:this.baseURL + strUrl);        
        // objOptions = objOptions || {};        
        objOptions = $.extend({}, {type:"get", url: strUrl, data: this.getQueryString(objParams || {})}, (objOptions || {}));        
        //objOptions = $.extend({}, { type: "get", url: strUrl, data: strSerialize }, (objOptions || {}));
        return $.ajax(objOptions);
        // return new Promise(function(resolve,reject){            
        //     $.ajax(options).done((objResult, textStatus, jqXHR)=>{
        //         resolve(objResult,textStatus);
        //     }).fail((jqXHR, textStatus, errorThrown)=>{
        //         reject(jqXHR);
        //     });
        // });

        // jqXHR.then(function( data, textStatus, jqXHR ) {}, function( jqXHR, textStatus, errorThrown ) {});  // Incorporates the functionality of the .done() and .fail() methods, allowing (as of jQuery 1.8) the underlying Promise to be manipulated

        // $.ajax(options).done(function(objData, textStatus, jqXHR){   // 同步
        //     console.log(objData);
        // }).fail(function(jqXHR, textStatus, errorThrown) {
        //     alert("error");
        // }).always(function(data, jqXHR, textStatus, errorThrown) {
        //     alert("finished");
        // });

        // $.ajax(options).then((objResult,textStatus)=>{   // 异步，可以执行
        // });

        // return new Promise(function(resolve,reject){            
        //     axios.get(strUrl,{ params : objParams}).then(objResponse=>{
        //         resolve(objResponse.data);
        //     }).catch(objResponse=>{
        //         reject(objResponse.data);
        //     });
        // });
    },    
    post: function (strUrl, objParams, objOptions){
        var strUrl = (strUrl.indexOf("http")>-1?strUrl:this.baseURL + strUrl);
        // var strQueryString = this.getQueryString(objParams || {});
        // console.log(strQueryString);

        // objOptions = $.extend({}, {type:"post", url: strUrl, data: JSON.stringify(objParams || {})}, (objOptions || {}));        
        objOptions = $.extend({}, { type: "post", url: strUrl, data: this.getQueryString(objParams || {}) }, (objOptions || {}));
        //objOptions = $.extend({}, { type: "post", url: strUrl, data: strSerialize }, (objOptions || {}));
        return $.ajax(objOptions);

        // var strQueryString = this.getQueryString(objParams);

        // return new Promise(function(resolve,reject){            
        //     axios.post(strUrl, strQueryString).then(objResponse=>{
        //         resolve(objResponse.data);
        //     }).catch(objResponse=>{
        //         reject(objResponse.data);
        //     });
        // });

        // $.ajax({
        //     url: Lib.strAPIUrl + "/API/Line/Post?IsGetId=0",
        //     type: "post",
        //     data: $("#frmList").serialize(),
        //     dataType: "json",
        //     xhrFields: { withCredentials: true },
        //     beforeSend: function (xhr) {
        //         if ($("#frmList").validate().form() == true) {
        //             $.showLoading("正在处理中，请等待...");
        //             return true;
        //         }
        //         else {
        //             return false;
        //         }
        //     },
        //     success: function (objResult) {
        //         if (objResult.Code == "0") {
        //             $.toast(objResult.Msg, function () {
        //                 window.history.go(-1);
        //             });
        //         }
        //         else {
        //             $.hideLoading();
        //             $.alert(objResult.Msg, "系统提示");
        //         }
        //     }
        // });
    },
    delete: function (strUrl, objParams, objOptions) { // IOS有限制，最好不用
        var strUrl = (strUrl.indexOf("http") > -1 ? strUrl : this.baseURL + strUrl);

        objOptions = $.extend({}, { type: "delete", url: strUrl, data: (objParams || {}) }, (objOptions || {}));
        return $.ajax(objOptions);
    },
    put: function(strUrl, objParams, objOptions){   // IOS有限制，最好不用
        var strUrl = (strUrl.indexOf("http")>-1?strUrl:this.baseURL + strUrl);

        objOptions = $.extend({}, {type:"put", url: strUrl, data: JSON.stringify(objParams || {})}, (objOptions || {}));
        return $.ajax(objOptions);
    },


    getQueryString: function (objData, strSplitWord) {  // 将对象和数组属性转换成url字符串,主要用于axios请求数据传送中.
        var strTemp = "";
        var strQueryString = "";
        strSplitWord = (strSplitWord == null ? "," : strSplitWord);
        for (var key in objData) {
            if (Array.isArray(objData[key])) {
                strTemp = "";
                for (var i = 0; i < objData[key].length; i++) {
                    strTemp += objData[key][i] + strSplitWord;
                }
                if (strTemp.length > 0) {
                    strTemp = strTemp.substr(0, strTemp.length - 1);
                    strTemp = "," + strTemp + ",";
                }
                strQueryString += key + "=" + encodeURIComponent(strTemp) + "&";
            }
            else if(typeof(objData[key]) == "object"){
                strQueryString += key + "=" + encodeURIComponent(JSON.stringify(objData[key])) + "&";
            }
            else {  // 不是数组
                strQueryString += key + "=" + encodeURIComponent(objData[key]) + "&";
            }
        }
        if (strQueryString.length > 0) {
            strQueryString = strQueryString.substr(0, strQueryString.length - 1);
        }
        return strQueryString;
    }
};
 //Ajax.init;

var AjaxAxios = {
    init: function () {
        axios.defaults.baseURL = Lib.Config.Url_ApiRequest;
        axios.defaults.headers.common['token'] = localStorage.getItem("strToken") == null ? "" : localStorage.getItem("strToken");

        axios.interceptors.request.use(function (config) {  // 在发送请求之前做些什么
            // if(config.params!=null){ // IOS手机不能前端设置head，设置的话请求就发送不出去，IOS自身安全限制
            //     config.params.token=localStorage.getItem("strToken");
            // }
            // else{
            //     config.params = {"token":localStorage.getItem("strToken")};
            // }
            return config;
        }, function (error) {   // 对请求错误做些什么
            return Promise.reject(error);
        });
        axios.interceptors.response.use(function (response) { // Do something with response data    
            if (response.data.code == 403) {
                localStorage.removeItem("strToken");
                localStorage.removeItem("jobjUser");

                var strReturn = window.location.href;
                if (strReturn.indexOf("//") > -1) {
                    strReturn = strReturn.substr(strReturn.indexOf("//") + 2);
                }
                if (strReturn.indexOf("/") > -1) {
                    strReturn = strReturn.substr(strReturn.indexOf("/"));
                }
                else {
                    strReturn = "/";
                }

                try {
                    barba.go("/Account/Login?Return=" + strReturn);
                }
                catch {
                    window.location.href = "/Account/Login?Return=" + strReturn;
                }                        
            }
            return response;
        }, function (error) {   // axios全局错误处理    
            alert("系统错误，请稍后再进行该操作或者联系管理员。错误提示：" + error);
            return Promise.reject(error);
        });
    },
    get: function (strUrl, objParams) {
        return new Promise(function (resolve, reject) {
            axios.get(strUrl, { params: objParams }).then(objResponse => {
                resolve(objResponse.data);
            }).catch(objResponse => {
                reject(objResponse.data);
            });
        });
    },
    post: function (strUrl, objParams) {
        var strQueryString = this.getQueryString(objParams);

        return new Promise(function (resolve, reject) {
            axios.post(strUrl, strQueryString).then(objResponse => {
                resolve(objResponse.data);
            }).catch(objResponse => {
                reject(objResponse.data);
            });
        });
    },
    // getExt:function(strUrl, objParams){
    //     var strQueryString = this.getQueryString(objParams);

    //     return new Promise(function(resolve,reject){            
    //         axios.post(strUrl, strQueryString).then(objResponse=>{
    //             resolve(objResponse.data);
    //         }).catch(objResponse=>{
    //             reject(objResponse.data);
    //         });
    //     });
    // },    
    delete: function (strUrl, objParams) { // IOS有限制，最好不用
        return new Promise(function (resolve, reject) {
            axios.delete(strUrl, { params: objParams }).then(objResponse => {
                resolve(objResponse.data);
            }).catch(objResponse => {
                reject(objResponse.data);
            });
        });
    },
    put: function (strUrl, objParams) {   // IOS有限制，最好不用
        var strQueryString = this.getQueryString(objParams);

        return new Promise(function (resolve, reject) {
            axios.put(strUrl, strQueryString).then(objResponse => {
                resolve(objResponse.data);
            }).catch(objResponse => {
                reject(objResponse.data);
            });
        });
    },


    getQueryString: function (objData, strSplitWord) {  // 将对象和数组属性转换成url字符串,主要用于axios请求数据传送中.
        var strTemp = "";
        var strQueryString = "";
        strSplitWord = (strSplitWord == null ? "," : strSplitWord);
        for (var key in objData) {
            if (Array.isArray(objData[key])) {
                strTemp = "";
                for (var i = 0; i < objData[key].length; i++) {
                    strTemp += objData[key][i] + strSplitWord;
                }
                if (strTemp.length > 0) {
                    strTemp = strTemp.substr(0, strTemp.length - 1);
                    strTemp = "," + strTemp + ",";
                }
                strQueryString += key + "=" + encodeURIComponent(strTemp) + "&";
            }
            else if (typeof (objData[key]) == "object") {
                strQueryString += key + "=" + encodeURIComponent(JSON.stringify(objData[key])) + "&";
            }
            else {  // 不是数组
                strQueryString += key + "=" + encodeURIComponent(objData[key]) + "&";
            }
        }
        if (strQueryString.length > 0) {
            strQueryString = strQueryString.substr(0, strQueryString.length - 1);
        }
        return strQueryString;
    }
};

//Ajax.init;
Lib.Config.Init();