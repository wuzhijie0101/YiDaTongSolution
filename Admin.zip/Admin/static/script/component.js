Vue.component('hc-text-item',{
    name: "TextItem",
    template:'<div class="form-item"><div class="form-item-hd"><span v-if="validate.indexOf(\'required\')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div><validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }"><input :type="type" class="hc_text" :value="value" @input="$emit(\'input\', $event.target.value)" :name="name" :placeholder="placeholder" :disabled="disabled" autocomplete="off" /><div class="form-error" v-show="errors[0]">{{errors[0]}}</div></validation-provider><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',

    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        type: { // text,tel,password
            type: String,
            default: "text"
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    }
});


Vue.component('hc-number-item',{
    name: "NumberItem",
    template:'<div class="form-item"><div class="form-item-hd"><span v-if="validate.indexOf(\'required\')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div><validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }"><input type="number" class="hc_text" :value="value" @input="valueChange($event)" :name="name" :placeholder="placeholder" :disabled="disabled" autocomplete="off" /><div class="form-error" v-show="errors[0]">{{errors[0]}}</div></validation-provider><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',

    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: Number,
            default: ""
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {        
    },
    destroyed: function() {},
    methods: {
        valueChange:function(event){
            if(event.target.value == ""){
                this.$emit('input', null);    
            }
            else{
                this.$emit('input', parseFloat(event.target.value));
            }
        }
    }
});

Vue.component('hc-datetime-item',{
    name: "DateTimeItem",
    template:'<div class="form-item"><div class="form-item-hd"><span v-if="validate.indexOf(\'required\')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div><validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }"><input :type="type" :class="\'hc_text\' + (value==\'\'?\'\':\' hasContent\')" :value="value" @input="$emit(\'input\', $event.target.value)" :name="name" :placeholder="placeholder" :disabled="disabled" /><div class="form-error" v-show="errors[0]">{{errors[0]}}</div></validation-provider><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',

    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        type: { // date,time,datetime-local
            type: String,
            default: "date"
        },
        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },  
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{            
        }
    },
    computed: {},
    watch: {},
    created: function() {},
    mounted: function() {        
    },
    destroyed: function() {},
    methods: {}
});

Vue.component('hc-textarea-item',{
    name: "TextareaItem",
    template:'<div class="form-item"><div class="form-item-hd"><span v-if="validate.indexOf(\'required\')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div><validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }"><textarea class="hc_textarea" :value="value" @input="$emit(\'input\', $event.target.value)" :name="name" :rows="rows" :placeholder="placeholder" :disabled="disabled"></textarea><div class="form-error" v-show="errors[0]">{{errors[0]}}</div></validation-provider><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',
       
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: String,
            default: ""
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        placeholder:{
            type: String,
            default: "请输入"
        },
        disabled:{
            type: Boolean,
            default: false
        },

        rows: {
            type: Number,
            default: 3
        },
    },
    data: function() {
        return{            
        }
    }
});

Vue.component('hc-radio-item',{
    name: "RadioItem",
    template:'<div class="form-item"><div class="form-item-hd"><i :class="leftIcon"></i>{{name}}</div><div class="form-item-bd"><label class="hc_radio" v-for="objItem in data"><input type="radio" v-model="model" :value="parseInt(objItem[idKey])" :name="name" :disabled="disabled" /><span>{{objItem[nameKey]}}</span></label></div><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',
       
    model:{
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: Number,
            default: null
        },
        data: {     // [{Value:'',Name:''}]
            type: Array,
            default(){return []}            
        },
        idKey:{
            type: String,
            default: "Value"
        },
        nameKey:{
            type: String,
            default: "Name"
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        disabled:{
            type: Boolean,
            default: false
        }
    },
    data: function() {
        return{            
        }
    },
    computed: {
        model:{
            get:function(){
                return this.value;
            },
            set:function(value){
                this.$emit('change', value);
            }
        }
    }
});

Vue.component('hc-checkbox-item',{
    name: "CheckboxItem",
    template:'<div class="form-item"><div class="form-item-hd"><span v-if="validate.indexOf(\'required\')>-1" class="form-required">*</span><i :class="leftIcon"></i>{{name}}</div><validation-provider tag="div" class="form-item-bd" :rules="validate" v-slot="{ errors }"><label class="hc_checkbox" v-for="objItem in data"><input type="checkbox" v-model="model" :value="parseInt(objItem[idKey])" :name="name" :disabled="disabled" /> <span>{{objItem[nameKey]}}</span></label><div class="form-error" v-show="errors[0]" style="margin-top: 0px;">{{errors[0]}}</div></validation-provider><div class="form-item-ft"><slot name="footer"></slot><i :class="rightIcon"></i></div></div>',
    
    model:{
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: Array,
            default(){return []}
        },
        data: {     // [{Value:'',Name:''}]
            type: Array,
            default(){return []}
        },
        idKey:{
            type: String,
            default: "Value"
        },
        nameKey:{
            type: String,
            default: "Name"
        },

        name: {
            type: String,
            default: ""
        },
        leftIcon: {
            type: String,
            default: ""
        },
        rightIcon: {
            type: String,
            default: ""
        },
        validate:{
            type: String,
            default: ""
        },
        disabled:{
            type: Boolean,
            default: false
        }
    },
    data: function() {
        return{       
            arrChoose: this.value    
        }
    },
    computed: {
        model:{
            get:function(){
                return this.value;
            },
            set:function(value){
                this.$emit('change', value);
            }
        }
    }
});

Vue.component('hc-popup-radio',{
    name: "PopupRadio",
    template:'<div><div @click="blnShow=(!disabled);" :style="(disabled?\'color:#999;\':\'\')"><span v-if="model==null" style="color: #757575;">{{placeholder}}</span><span v-else>{{(objCurrent==null?model:objCurrent.Name)}}</span></div><div v-show="blnShow" @click="blnShow=false;" style="position:fixed; left: 0px; top: 0px; width: 100%; height: 100%; z-index: 1000; background-color: rgba(0,0,0,0.7);"><div onclick="event.stopPropagation();" :style="\'position: absolute; left: 0px; \'+(position==\'top\'?\'top:30px;\':\'bottom:0px;\')+\' width: 100%; height:50%; background: #fff; max-height: 50%; transition:height 0.5s;\'"><div v-if="filter" style="height: 40px; margin-top: 10px; display: flex; justify-content: center; align-items: center; align-self: center;"><input type="text" class="hc_text" style="width: 50%; border-bottom: 1px solid #cdcdcd;" v-model="strFilter" placeholder="关键字" /><button v-show="mode==2" class="hc_button hc_button-small" @click="model=strFilter;strFilter=\'\';blnShow=false;" style="margin-left: 10px;">创建</button></div><div style="height:calc(100% - 50px); overflow: auto;"><ul><li v-for="objItem in data" v-show="strFilter==\'\'?true:(objItem[nameKey].indexOf(strFilter)>-1)" @click="model=parseInt(objItem[idKey]);blnShow=false;" style="display: flex; height: 40px; align-items: center; border-bottom: 1px solid #cdcdcd;"><div style="flex-grow: 1; padding:0px 20px;">{{objItem[nameKey]}}</div><div style="width: 40px;"><label class="hc_radio"><input type="radio" v-model="model" :value="parseInt(objItem[idKey])" /></label></div></li></ul></div></div></div></div>',
       
    model:{
        prop: "value",
        event: "input"
    },
    props: {
        value: {
            type: [Number,String]
            // default: ""
        },
        mode:{  // 1:选择 2:创建
            type: Number,
            default: 1
        },
        data: {     // [{Id:'',Name:''}]
            type: Array,
            default(){return []}
        },
        idKey:{
            type: String,
            default: "Id"
        },
        nameKey:{
            type: String,
            default: "Name"
        },
        position:{  // top, bottom
            type: String,
            default: "bottom"
        },
        filter:{
            type: Boolean,
            default: false
        },

        placeholder:{
            type: String,
            default: "请选择"
        },
        disabled:{
            type: Boolean,
            default: false
        },
    },
    data: function() {
        return{
            blnShow: false,
            strFilter: "",
            objCurrent: null,
        }
    },
    computed: {
        model:{
            get:function(){
                if(this.value != null){
                    if(this.mode==2){
                        this.objCurrent = null;
                    }

                    for(var i = 0; i < this.data.length; i++){
                        if(this.value == this.data[i][this.idKey]){
                            this.objCurrent = this.data[i];
                            break;
                        }
                    }
                }
                return this.value;
            },
            set:function(value){
                this.$emit('input', value);
            }
        }
    }
});